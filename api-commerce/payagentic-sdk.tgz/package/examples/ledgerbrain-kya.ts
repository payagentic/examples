/**
 * Live demo: a PayAgentic agent buys a LedgerBrain KYA (Know Your Address)
 * risk report over x402 v2 on Base mainnet (1.00 USDC), governed by org
 * spend policies.
 *
 * The script drives the full x402 v2 flow:
 *   1. Fetch the LedgerBrain catalog to discover the endpoint + listed price.
 *   2. Call client.fetch() which transparently handles the 402 PAYMENT-REQUIRED
 *      challenge, proposes via the PayAgentic API, retries the seller with the
 *      PAYMENT-SIGNATURE credential, and posts the PAYMENT-RESPONSE receipt.
 *   3. Poll the payment status until the transaction settles on-chain and print
 *      the Base transaction hash.
 *
 * Secondary form — KYT report (transaction risk):
 *   pnpm exec tsx examples/ledgerbrain-kya.ts --report kyt --txid <tx_hash>
 *
 * Prerequisites:
 *   - Local PayAgentic stack running with Base mainnet config (see runbook).
 *   - API key bound to an agent wallet funded with USDC on Base.
 *   - Payments service configured with APP_CHAIN_ID=8453 and mainnet USDC.
 *
 * Usage:
 *   PAYAGENTIC_API_KEY=rp_... PAYAGENTIC_WALLET_ID=<uuid> \
 *   PAYAGENTIC_BASE_URL=http://localhost:4080 \
 *   pnpm exec tsx examples/ledgerbrain-kya.ts <chain> <address>
 *
 * Example:
 *   PAYAGENTIC_API_KEY=rp_test_abc PAYAGENTIC_WALLET_ID=wal_uuid \
 *   pnpm exec tsx examples/ledgerbrain-kya.ts bitcoin 1A1zP1eP5QGefi2DMPTfTL5SLmv7Divfna
 */

import {
  PaymentsClient,
  PendingApprovalError,
  PolicyDeniedError,
  type PollOptions,
} from "../src/payments-client.js";

// ---------------------------------------------------------------------------
// Argument parsing
// ---------------------------------------------------------------------------

const args = process.argv.slice(2);

// Check for --report kyt --txid <id> form.
let reportType: "kya" | "kyt" = "kya";
let kytTxid: string | undefined;

const reportIdx = args.indexOf("--report");
if (reportIdx !== -1) {
  const rt = args[reportIdx + 1];
  if (rt === "kyt") {
    reportType = "kyt";
    const txidIdx = args.indexOf("--txid");
    if (txidIdx !== -1) {
      kytTxid = args[txidIdx + 1];
    }
    if (kytTxid === undefined || kytTxid === "") {
      console.error("--report kyt requires --txid <transaction_hash>");
      process.exit(1);
    }
  } else if (rt !== "kya" && rt !== undefined) {
    console.error(`Unknown report type: ${rt}. Use 'kya' or 'kyt'.`);
    process.exit(1);
  }
}

// KYA positional args: chain and address. Only exclude the --report value
// when --report is actually present (reportIdx === -1 would otherwise make
// args[reportIdx + 1] alias args[0] and drop the first positional).
const positional = args.filter(
  (a) => !a.startsWith("--") && (reportIdx === -1 || a !== args[reportIdx + 1]) && a !== kytTxid,
);
const [chain = "bitcoin", address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7Divfna"] = positional;

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const apiKey = process.env.PAYAGENTIC_API_KEY;
const walletId = process.env.PAYAGENTIC_WALLET_ID;

if (apiKey === undefined || apiKey === "") {
  console.error("Set PAYAGENTIC_API_KEY to your PayAgentic agent API key.");
  process.exit(1);
}
if (walletId === undefined || walletId === "") {
  console.error("Set PAYAGENTIC_WALLET_ID to the wallet UUID to debit.");
  process.exit(1);
}

const baseUrl = process.env.PAYAGENTIC_BASE_URL ?? "http://localhost:4080";

// Construct PaymentsClient with the real required fields.
// walletId: forwarded to propose as the debit wallet.
// apiKey:   Bearer token for PayAgentic API (propose + settlement report).
// baseUrl:  Gateway base URL (no /v1 suffix — the client adds it per route).
const client = new PaymentsClient({
  apiKey,
  walletId,
  baseUrl,
});

// ---------------------------------------------------------------------------
// Catalog discovery
// ---------------------------------------------------------------------------

interface CatalogResource {
  endpoint: string;
  price: string;
  currency: string;
  description?: string;
}

interface LedgerBrainCatalog {
  data: {
    resources: {
      kya_report?: CatalogResource;
      kyt_report?: CatalogResource;
      [key: string]: CatalogResource | undefined;
    };
  };
}

// LedgerBrain API host. Catalog `endpoint` values are relative paths
// (e.g. "/api/v1/x402/kya/report"); resolve them against this base before
// handing the URL to client.fetch, since globalThis.fetch rejects relative URLs.
const LEDGERBRAIN_API = "https://api.ledgercore.io";

console.log("Fetching LedgerBrain x402 catalog...");
let catalog: LedgerBrainCatalog;
try {
  const catalogResp = await globalThis.fetch(`${LEDGERBRAIN_API}/api/v1/x402/catalog`);
  if (!catalogResp.ok) {
    console.error(`Catalog fetch failed: HTTP ${catalogResp.status}`);
    process.exit(1);
  }
  catalog = (await catalogResp.json()) as LedgerBrainCatalog;
} catch (err) {
  console.error("Failed to fetch catalog:", err instanceof Error ? err.message : String(err));
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Report purchase
// ---------------------------------------------------------------------------

let resourceUrl: string;
let requestBody: Record<string, string>;
let maxSpend: string;
let catalogResource: CatalogResource | undefined;

if (reportType === "kya") {
  catalogResource = catalog.data.resources.kya_report;
  if (catalogResource === undefined) {
    console.error("Catalog does not list a kya_report resource. Check the catalog schema.");
    process.exit(1);
  }
  resourceUrl = new URL(catalogResource.endpoint, LEDGERBRAIN_API).toString();
  maxSpend = catalogResource.price;
  requestBody = { address, chain };
  console.log(`Catalog: KYA report at ${resourceUrl} for ${maxSpend} ${catalogResource.currency}`);
  console.log(`Requesting KYA report for ${chain}:${address}`);
} else {
  // kyt
  catalogResource = catalog.data.resources.kyt_report;
  if (catalogResource === undefined) {
    // Fallback: LedgerBrain may expose the KYT endpoint even without a
    // catalog entry; use the known path.
    resourceUrl = `${LEDGERBRAIN_API}/api/v1/x402/kyt/report`;
    maxSpend = "1.0";
    console.log("kyt_report not in catalog — using known endpoint, maxSpend=1.0 USDC");
  } else {
    resourceUrl = new URL(catalogResource.endpoint, LEDGERBRAIN_API).toString();
    maxSpend = catalogResource.price;
    console.log(
      `Catalog: KYT report at ${resourceUrl} for ${maxSpend} ${catalogResource.currency}`,
    );
  }
  requestBody = { txid: kytTxid as string, chain };
  console.log(`Requesting KYT report for txid ${kytTxid}`);
}

// maxSpend cross-check: the server denies the payment when the x402 challenge
// quotes more than this. If the catalog price is correct this never fires.
console.log(`maxSpend guard: ${maxSpend} USDC (server-enforced)`);

// ---------------------------------------------------------------------------
// x402 v2 purchase with approval wait
// ---------------------------------------------------------------------------

let transactionId: string | undefined;

let resp: Response;
try {
  resp = await client.fetch(resourceUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(requestBody),
    // Refuse if the 402 challenge quotes more than the catalog listed.
    maxSpend,
    // Wait up to 5 minutes for operator approval if the wallet's policy
    // includes a require_approval rule (demo "approvals beat").
    waitForApproval: { timeoutMs: 5 * 60 * 1_000 },
  });

  // The SDK records the transaction id behind every paid response.
  transactionId = client.transactionIdFor(resp);
} catch (err) {
  if (err instanceof PolicyDeniedError) {
    console.error(`Payment DENIED by policy: ${err.reason}`);
    if (err.transactionId !== undefined) {
      console.error(`Transaction ID (denied): ${err.transactionId}`);
    }
    process.exit(1);
  }
  if (err instanceof PendingApprovalError) {
    console.error("Payment parked for approval but approval timed out or was rejected.");
    if (err.transactionId !== undefined) {
      console.error(`Transaction ID (pending_approval): ${err.transactionId}`);
    }
    process.exit(1);
  }
  console.error(
    "Unexpected error during payment:",
    err instanceof Error ? err.message : String(err),
  );
  process.exit(1);
}

if (!resp.ok) {
  const bodyText = await resp.text();
  console.error(`Purchase failed: HTTP ${resp.status}`, bodyText);
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Parse report
// ---------------------------------------------------------------------------

const report = (await resp.json()) as Record<string, unknown>;
console.log("\nReport received:");
console.log(JSON.stringify(report, null, 2));

const reportData = report.data as Record<string, unknown> | undefined;
const riskLevel =
  typeof reportData?.risk_level === "string" ? reportData.risk_level : "(see report)";
console.log(`\nrisk_level: ${riskLevel}`);

// ---------------------------------------------------------------------------
// Settlement poll — wait for authorized -> confirming -> settled
// ---------------------------------------------------------------------------
// The x402 v2 flow parks the transaction at 'authorized' after signing
// (seller settles on-chain). We poll until the confirmation watcher
// promotes it to 'settled' and print the Base tx hash.
//
// If the SDK has no transaction id for this response (unpaid response or
// pre-v2 propose without a transaction_id), we skip the poll gracefully.

if (transactionId !== undefined) {
  console.log(`\nPolling settlement for transaction ${transactionId}...`);
  const pollOpts: PollOptions = {
    // Up to 60s at 1s intervals: mainnet watcher needs 2 confirmations
    // (~4s at Base's 2s block time) plus the watcher poll cycle before
    // the row is promoted. 60 attempts gives headroom without hanging
    // indefinitely.
    maxAttempts: 60,
    intervalMs: 1_000,
  };

  try {
    const settled = await client.pollUntilSettled(transactionId, pollOpts);
    const txHash = typeof settled.tx_hash === "string" ? settled.tx_hash : "(not yet available)";
    const finalStatus = typeof settled.status === "string" ? settled.status : "unknown";
    console.log(`Settlement status: ${finalStatus}`);
    console.log(`On-chain tx hash: ${txHash}`);
    if (typeof txHash === "string" && txHash.startsWith("0x")) {
      console.log(`View on Basescan: https://basescan.org/tx/${txHash}`);
    }
  } catch (err) {
    // Settlement polling failures are non-fatal: the confirmation watcher
    // will complete the lifecycle regardless. See runbook note on advisory
    // settlement reports.
    console.warn(
      "Settlement poll failed or timed out (the watcher will settle on-chain regardless):",
      err instanceof Error ? err.message : String(err),
    );
  }
} else {
  console.log(
    "\nNo transaction ID recorded for this response (was it actually paid?) — skipping settlement poll.",
    "Check the PayAgentic dashboard for the transaction lifecycle.",
  );
}
