import { PayagenticClient, PendingApprovalError, PolicyDeniedError } from "@payagentic.ai/sdk";

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} in your runtime environment before running this example.`);
  return value;
}

const apiKey = required("PAYAGENTIC_API_KEY");
if (!apiKey.startsWith("pa_test_") && !apiKey.startsWith("rp_test_")) {
  throw new Error("This example requires a test API key.");
}
const baseUrl = required("PAYAGENTIC_BASE_URL");
const resourceUrl = required("PAYAGENTIC_RESOURCE_URL");
for (const value of [baseUrl, resourceUrl]) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password) {
    throw new Error("Use HTTPS gateway and resource URLs without embedded credentials.");
  }
}
const maxSpend = required("PAYAGENTIC_MAX_SPEND");
if (!/^\d+\.\d{1,6}$/.test(maxSpend) || BigInt(maxSpend.replace(".", "")) === 0n) {
  throw new Error("PAYAGENTIC_MAX_SPEND must be a positive decimal string, e.g. 0.01.");
}
const client = new PayagenticClient({
  apiKey,
  baseUrl,
  x402WalletId: required("PAYAGENTIC_WALLET_ID"),
});

// Persist one unique key per logical purchase; reuse it when recovering that
// purchase. Reconcile an ambiguous outcome before starting a new purchase.
const idempotencyKey = required("PAYAGENTIC_IDEMPOTENCY_KEY");
try {
  const response = await client.x402.fetch(resourceUrl, { maxSpend, idempotencyKey });
  if (!response.ok) throw new Error(`Merchant returned HTTP ${response.status}`);
  console.log(`Merchant response: HTTP ${response.status}. Check the gateway transaction before recording settlement.`);
} catch (error) {
  if (error instanceof PolicyDeniedError) {
    console.error("Payment denied. Review the decision in the dashboard before retrying.");
  } else if (error instanceof PendingApprovalError) {
    console.error("Payment needs approval. Reconcile the pending transaction before retrying.");
  } else {
    console.error("Request failed. Check gateway and merchant status before retrying.");
  }
  process.exitCode = 1;
}
