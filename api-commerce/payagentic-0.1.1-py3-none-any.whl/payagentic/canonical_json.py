"""Shared RFC 8785 canonical JSON encoding for SDK signing and transport."""

from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

import rfc8785


def _normalize_binary64_integers(value: Any) -> Any:
    """Copy JSON containers while converting exact native integers to binary64."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        try:
            binary64 = float(value)
        except OverflowError as error:
            raise rfc8785.IntegerDomainError(value) from error
        if not math.isfinite(binary64) or int(binary64) != value:
            raise rfc8785.IntegerDomainError(value)
        return binary64
    if isinstance(value, Mapping):
        return {key: _normalize_binary64_integers(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_normalize_binary64_integers(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_normalize_binary64_integers(item) for item in value)
    return value


def canonical_json_bytes(value: Any) -> bytes:
    """Canonical-JSON encode ``value`` and return UTF-8 bytes."""
    return rfc8785.dumps(_normalize_binary64_integers(value))
