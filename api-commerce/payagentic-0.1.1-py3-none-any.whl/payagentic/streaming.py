"""Server-Sent Events (SSE) streaming for real-time updates."""

from __future__ import annotations

import contextlib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Self

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    import httpx

__all__ = [
    "AsyncEventStream",
    "ServerSentEvent",
    "subscribe_alerts",
    "subscribe_approvals",
    "subscribe_transactions",
]


@dataclass(frozen=True, slots=True)
class ServerSentEvent:
    """A single Server-Sent Event."""

    event: str
    data: str
    id: str | None = None
    retry: int | None = None


@dataclass(slots=True)
class _SSEAccumulator:
    """Mutable accumulator for parsing SSE fields into an event."""

    event_type: str = ""
    data_lines: list[str] = field(default_factory=list)
    event_id: str | None = None
    retry: int | None = None

    def apply_field(self, name: str, value: str) -> None:
        """Apply a parsed field to the accumulator."""
        if name == "event":
            self.event_type = value
        elif name == "data":
            self.data_lines.append(value)
        elif name == "id":
            self.event_id = value
        elif name == "retry":
            with contextlib.suppress(ValueError):
                self.retry = int(value)

    def emit(self) -> ServerSentEvent | None:
        """Emit an event if data has been accumulated, then reset."""
        if not self.data_lines:
            return None
        event = ServerSentEvent(
            event=self.event_type or "message",
            data="\n".join(self.data_lines),
            id=self.event_id,
            retry=self.retry,
        )
        self.event_type = ""
        self.data_lines = []
        self.event_id = None
        self.retry = None
        return event


class AsyncEventStream:
    """Async iterator over an SSE stream.

    Usage::

        async with AsyncEventStream(client, "/events/txns") as s:
            async for event in s:
                print(event.event, event.data)
    """

    def __init__(
        self,
        client: httpx.AsyncClient,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> None:
        self._client = client
        self._path = path
        self._params = params or {}
        self._response: httpx.Response | None = None

    async def __aenter__(self) -> Self:
        self._response = await self._client.send(
            self._client.build_request(
                "GET",
                self._path,
                params=self._params,
                headers={"Accept": "text/event-stream"},
            ),
            stream=True,
        )
        return self

    async def __aexit__(self, *_args: object) -> None:
        if self._response is not None:
            await self._response.aclose()

    async def __aiter__(self) -> AsyncIterator[ServerSentEvent]:
        """Yield parsed SSE events from the stream."""
        if self._response is None:
            msg = "Stream not opened. Use `async with` to open."
            raise RuntimeError(msg)

        acc = _SSEAccumulator()

        async for raw_line in self._response.aiter_lines():
            line = raw_line.rstrip("\n")

            if not line:
                event = acc.emit()
                if event is not None:
                    yield event
                continue

            if line.startswith(":"):
                continue

            field_name, _, value = line.partition(":")
            acc.apply_field(field_name, value.lstrip(" "))

        # Flush any trailing event.
        event = acc.emit()
        if event is not None:
            yield event


def subscribe_transactions(
    client: httpx.AsyncClient,
    *,
    wallet_id: str | None = None,
) -> AsyncEventStream:
    """Subscribe to real-time transaction events.

    Args:
        client: An authenticated ``httpx.AsyncClient``.
        wallet_id: Optionally filter by wallet.

    Returns:
        An :class:`AsyncEventStream` that yields transaction events.
    """
    params: dict[str, Any] = {}
    if wallet_id:
        params["wallet_id"] = wallet_id
    return AsyncEventStream(client, "/events/transactions", params=params)


def subscribe_alerts(client: httpx.AsyncClient) -> AsyncEventStream:
    """Subscribe to real-time alert events.

    Args:
        client: An authenticated ``httpx.AsyncClient``.

    Returns:
        An :class:`AsyncEventStream` that yields alert events.
    """
    return AsyncEventStream(client, "/events/alerts")


def subscribe_approvals(client: httpx.AsyncClient) -> AsyncEventStream:
    """Subscribe to real-time approval-request events.

    Args:
        client: An authenticated ``httpx.AsyncClient``.

    Returns:
        An :class:`AsyncEventStream` that yields approval events.
    """
    return AsyncEventStream(client, "/events/approvals")
