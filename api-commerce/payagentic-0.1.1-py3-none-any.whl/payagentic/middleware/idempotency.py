"""Idempotency-Key generation for non-idempotent operations.

The PayAgentic gateway requires Idempotency-Key on POST/PUT/PATCH/DELETE
to dedupe retries. This module provides a v4 UUID generator used by the
middleware transport when the caller doesn't supply their own key.
"""

from __future__ import annotations

import uuid


def generate_idempotency_key() -> str:
    """Return a fresh UUID v4 string suitable for Idempotency-Key headers."""
    return str(uuid.uuid4())
