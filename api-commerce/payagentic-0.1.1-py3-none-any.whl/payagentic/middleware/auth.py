"""Auth + Idempotency-Key header injection.

Returns a callable suitable for use as an httpx event hook on the
`request` event. The hook mutates the outgoing `httpx.Request` in
place, adding Authorization, optional x-agent-id, and an
Idempotency-Key for non-idempotent methods (unless the caller
already supplied one).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .idempotency import generate_idempotency_key

if TYPE_CHECKING:
    from collections.abc import Callable

    import httpx

NON_IDEMPOTENT_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


def build_auth_hook(
    *,
    api_key: str,
    agent_id: str | None = None,
) -> Callable[[httpx.Request], None]:
    """Return an httpx request hook that injects auth + idempotency headers.

    Usage::

        client = httpx.Client(event_hooks={
            "request": [build_auth_hook(api_key=key)],
        })
    """

    def hook(request: httpx.Request) -> None:
        request.headers["Authorization"] = f"Bearer {api_key}"
        if agent_id is not None:
            request.headers["x-agent-id"] = agent_id
        if (
            request.method.upper() in NON_IDEMPOTENT_METHODS
            and "idempotency-key" not in request.headers
        ):
            request.headers["Idempotency-Key"] = generate_idempotency_key()

    return hook
