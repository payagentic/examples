"""Retry logic with exponential back-off and jitter."""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

from .errors import PayAgenticError, RateLimitError, is_retryable

__all__ = [
    "DEFAULT_RETRY_POLICY",
    "RetryPolicy",
    "async_with_retry",
    "with_retry",
]


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Configuration for retry behaviour."""

    max_retries: int = 3
    base_delay: float = 0.5
    max_delay: float = 30.0
    jitter: float = 0.25
    retryable: Callable[[PayAgenticError], bool] = field(
        default=is_retryable,
    )


DEFAULT_RETRY_POLICY = RetryPolicy()
T = TypeVar("T")


def _compute_delay(
    attempt: int,
    policy: RetryPolicy,
    error: PayAgenticError,
) -> float:
    """Compute the delay before the next retry attempt."""
    # Honour Retry-After when the server tells us.
    if isinstance(error, RateLimitError) and error.retry_after is not None:
        return min(error.retry_after, policy.max_delay)

    delay: float = min(policy.base_delay * (2**attempt), policy.max_delay)
    jitter_range: float = delay * policy.jitter
    return delay + random.uniform(-jitter_range, jitter_range)  # noqa: S311


def with_retry(  # noqa: UP047
    fn: Callable[[], T],
    policy: RetryPolicy = DEFAULT_RETRY_POLICY,
) -> T:
    """Execute *fn* with synchronous retry logic.

    Retries up to ``policy.max_retries`` times for retryable errors,
    using exponential back-off with jitter.  The ``Retry-After`` header
    is respected for rate-limit errors.
    """
    last_error: PayAgenticError | None = None
    for attempt in range(policy.max_retries + 1):
        try:
            return fn()
        except PayAgenticError as exc:
            last_error = exc
            if not policy.retryable(exc) or attempt >= policy.max_retries:
                raise
            delay = _compute_delay(attempt, policy, exc)
            time.sleep(delay)

    # Should be unreachable, but keeps mypy happy.
    assert last_error is not None  # noqa: S101
    raise last_error


async def async_with_retry(  # noqa: UP047
    fn: Callable[[], Awaitable[T]],
    policy: RetryPolicy = DEFAULT_RETRY_POLICY,
) -> T:
    """Execute *fn* with asynchronous retry logic.

    Async counterpart of :func:`with_retry`.
    """
    last_error: PayAgenticError | None = None
    for attempt in range(policy.max_retries + 1):
        try:
            return await fn()
        except PayAgenticError as exc:
            last_error = exc
            if not policy.retryable(exc) or attempt >= policy.max_retries:
                raise
            delay = _compute_delay(attempt, policy, exc)
            await asyncio.sleep(delay)

    assert last_error is not None  # noqa: S101
    raise last_error
