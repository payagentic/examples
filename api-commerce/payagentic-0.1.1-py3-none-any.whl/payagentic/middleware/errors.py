"""PayAgentic error hierarchy and helpers."""

from __future__ import annotations

import contextlib
import logging
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    import httpx


class ProblemDetails(BaseModel):
    """RFC 9457 Problem Details for HTTP APIs.

    A small Pydantic model used internally by the error mapper. The
    generated ``_generated.models.ProblemDetails`` is an attrs class
    suited for typed operation responses, but we want a forgiving
    model_validate() entry point for arbitrary error bodies.
    """

    model_config = ConfigDict(frozen=True, extra="allow")

    type: str = Field(default="about:blank")
    title: str = Field(default="")
    status: int = Field(default=0)
    detail: str | None = Field(default=None)
    instance: str | None = Field(default=None)
    trace_id: str | None = Field(default=None)


__all__ = [
    "ConflictError",
    "ForbiddenError",
    "InternalError",
    "NotFoundError",
    "PayAgenticError",
    "ProblemDetails",
    "RateLimitError",
    "ServiceUnavailableError",
    "UnauthorizedError",
    "ValidationError",
    "from_response",
    "is_retryable",
]

_logger = logging.getLogger(__name__)


class PayAgenticError(Exception):
    """Base exception for all PayAgentic SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        problem_details: ProblemDetails | None = None,
        trace_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.problem_details = problem_details
        self.trace_id = trace_id

    def __repr__(self) -> str:
        cls = type(self).__name__
        return f"{cls}(status_code={self.status_code!r}, trace_id={self.trace_id!r})"


class NotFoundError(PayAgenticError):
    """Resource not found (HTTP 404)."""


class UnauthorizedError(PayAgenticError):
    """Authentication failed (HTTP 401)."""


class ForbiddenError(PayAgenticError):
    """Insufficient permissions (HTTP 403)."""


class ValidationError(PayAgenticError):
    """Request validation failed (HTTP 422)."""


class ConflictError(PayAgenticError):
    """Resource conflict (HTTP 409)."""


class InternalError(PayAgenticError):
    """Internal server error (HTTP 500)."""


class RateLimitError(PayAgenticError):
    """Rate limit exceeded (HTTP 429)."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        problem_details: ProblemDetails | None = None,
        trace_id: str | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            problem_details=problem_details,
            trace_id=trace_id,
        )
        self.retry_after = retry_after


class ServiceUnavailableError(PayAgenticError):
    """Service temporarily unavailable (HTTP 503)."""


_STATUS_MAP: dict[int, type[PayAgenticError]] = {
    401: UnauthorizedError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
    500: InternalError,
    503: ServiceUnavailableError,
}


def is_retryable(error: PayAgenticError) -> bool:
    """Return True if the error is retryable."""
    return isinstance(
        error,
        (RateLimitError, ServiceUnavailableError, InternalError),
    )


def from_response(response: httpx.Response) -> PayAgenticError:
    """Build the appropriate error from an HTTP response.

    Attempts to parse an RFC 9457 problem-details body.  Falls back to
    a generic ``PayAgenticError`` when the status code is unrecognised.
    """
    trace_id = response.headers.get("x-trace-id")
    problem: ProblemDetails | None = None
    detail: str = response.reason_phrase

    try:
        body: dict[str, Any] = response.json()
        problem = ProblemDetails.model_validate(body)
        detail = problem.detail or problem.title
        if problem.trace_id:
            trace_id = problem.trace_id
    except Exception:  # noqa: BLE001
        _logger.debug("Response body is not a problem-details payload")

    error_cls = _STATUS_MAP.get(response.status_code, PayAgenticError)

    kwargs: dict[str, Any] = {
        "status_code": response.status_code,
        "problem_details": problem,
        "trace_id": trace_id,
    }

    if error_cls is RateLimitError:
        retry_after_raw = response.headers.get("retry-after")
        retry_after: float | None = None
        if retry_after_raw is not None:
            with contextlib.suppress(ValueError):
                retry_after = float(retry_after_raw)
        kwargs["retry_after"] = retry_after

    return error_cls(detail, **kwargs)
