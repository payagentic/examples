"""RFC 7807 problem-details → typed exception mapping.

A response hook that raises the appropriate typed exception when the
response status is non-2xx. 2xx responses pass through silently.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .errors import from_response

if TYPE_CHECKING:
    import httpx


def raise_for_problem_details(response: httpx.Response) -> None:
    """Raise a typed exception if the response is non-2xx.

    Delegates to ``from_response(response)`` which inspects the body
    (parsed as JSON when content-type is ``application/problem+json``)
    and returns the matching ``PayAgenticError`` subclass.
    """
    if response.is_success:
        return
    raise from_response(response)
