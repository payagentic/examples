"""Unified PayagenticTransport: auth + retry + problem-details in one httpx Client.

``build_sync_client`` and ``build_async_client`` return ready-to-use httpx
clients with all middleware composed. The generated AuthenticatedClient
(Task 8 façade) constructs these and passes them to its httpx-based
operation functions.

Composition (request to response):

1. Auth event hook injects ``Authorization`` + ``Idempotency-Key`` on the
   outgoing request.
2. The wrap transport runs the inner ``send()`` inside ``with_retry`` and
   converts non-2xx responses to typed exceptions (which ``is_retryable``
   then classifies for retry).
"""

from __future__ import annotations

import httpx

from .auth import build_auth_hook
from .problem_details import raise_for_problem_details
from .retry import DEFAULT_RETRY_POLICY, RetryPolicy, async_with_retry, with_retry

__all__ = ["build_async_client", "build_sync_client"]


def build_sync_client(
    *,
    api_key: str,
    base_url: str,
    agent_id: str | None = None,
    retry_policy: RetryPolicy | None = None,
    inner_transport: httpx.BaseTransport | None = None,
) -> httpx.Client:
    """Build a fully wired sync ``httpx.Client``."""
    policy = retry_policy or DEFAULT_RETRY_POLICY
    auth_hook = build_auth_hook(api_key=api_key, agent_id=agent_id)

    wrapped = _SyncRetryTransport(
        inner=inner_transport or httpx.HTTPTransport(),
        policy=policy,
    )

    return httpx.Client(
        base_url=base_url,
        transport=wrapped,
        event_hooks={"request": [auth_hook]},
    )


def build_async_client(
    *,
    api_key: str,
    base_url: str,
    agent_id: str | None = None,
    retry_policy: RetryPolicy | None = None,
    inner_transport: httpx.AsyncBaseTransport | httpx.BaseTransport | None = None,
) -> httpx.AsyncClient:
    """Build a fully wired async ``httpx.AsyncClient``.

    For tests using ``httpx.MockTransport`` (which implements both sync and
    async dispatch), pass it via ``inner_transport``. For real use, omit
    ``inner_transport`` to get a default ``httpx.AsyncHTTPTransport``.
    """
    policy = retry_policy or DEFAULT_RETRY_POLICY
    sync_auth_hook = build_auth_hook(api_key=api_key, agent_id=agent_id)

    async def auth_hook(request: httpx.Request) -> None:
        sync_auth_hook(request)

    inner: httpx.AsyncBaseTransport | httpx.BaseTransport = (
        inner_transport if inner_transport is not None else httpx.AsyncHTTPTransport()
    )

    wrapped = _AsyncRetryTransport(inner=inner, policy=policy)

    return httpx.AsyncClient(
        base_url=base_url,
        transport=wrapped,
        event_hooks={"request": [auth_hook]},
    )


# ---------------------------------------------------------------------------
# Wrap transports — call the inner transport then run the problem-details
# hook inside ``with_retry`` so typed exceptions flow into ``is_retryable()``.
# ---------------------------------------------------------------------------


class _SyncRetryTransport(httpx.BaseTransport):
    def __init__(self, *, inner: httpx.BaseTransport, policy: RetryPolicy) -> None:
        self._inner: httpx.BaseTransport = inner
        self._policy: RetryPolicy = policy

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        def attempt() -> httpx.Response:
            response = self._inner.handle_request(request)
            raise_for_problem_details(response)
            return response

        return with_retry(attempt, self._policy)


class _AsyncRetryTransport(httpx.AsyncBaseTransport):
    def __init__(
        self,
        *,
        inner: httpx.AsyncBaseTransport | httpx.BaseTransport,
        policy: RetryPolicy,
    ) -> None:
        self._inner: httpx.AsyncBaseTransport | httpx.BaseTransport = inner
        self._policy: RetryPolicy = policy

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        async def attempt() -> httpx.Response:
            # ``httpx.MockTransport`` implements both interfaces and works
            # for sync and async paths in httpx 0.28+.
            if isinstance(self._inner, httpx.AsyncBaseTransport):
                response = await self._inner.handle_async_request(request)
            else:
                response = self._inner.handle_request(request)
            raise_for_problem_details(response)
            return response

        return await async_with_retry(attempt, self._policy)
