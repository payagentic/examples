# Code generated from api/openapi.json by generate-capability-sdk-contracts.mjs. DO NOT EDIT.

from typing import Final

CAPABILITY_TEST_ACCOUNTING_LABEL: Final = "test USDC, not real, not redeemable"

CAPABILITY_PROBLEM_TUPLES: Final = (
    ("allowance_exhausted", 429, "state_change", "wait for the next subscription period or upgrade"),
    ("allowance_exhausted", 503, "state_change", "capability invocation is disabled"),
    ("authentication_required", 401, "never", "send an active agent-scoped test credential"),
    ("authority_changed", 409, "state_change", "reload the binding authority before retrying"),
    ("binding_not_approved", 403, "state_change", "ask an authorized human to approve or resume the binding"),
    ("binding_not_found", 404, "state_change", "create and approve a pinned binding"),
    ("binding_not_found", 404, "state_change", "use a published capability endpoint"),
    ("budget_exceeded", 402, "state_change", "fund the agent's test USDC balance"),
    ("budget_exceeded", 403, "state_change", "increase the approved binding budget"),
    ("budget_exceeded", 429, "state_change", "wait for the binding velocity window"),
    ("capability_suspended", 409, "state_change", "wait for the provider or capability to be restored"),
    ("credential_wrong_mode", 403, "never", "use an agent-scoped test credential"),
    ("credential_wrong_mode", 403, "state_change", "use an active agent-scoped test credential"),
    ("execution_configuration_invalid", 503, "state_change", "hosted execution is temporarily unavailable"),
    ("execution_provider_unavailable", 502, "never", "contact the capability provider"),
    ("execution_provider_unavailable", 503, "reconcile", "check the invocation status before retrying"),
    ("execution_provider_unavailable", 503, "same_key", "retry with the same idempotency key"),
    ("execution_provider_unavailable", 503, "same_key", "retry with the same key after the provider recovers"),
    ("execution_timeout", 504, "same_key", "retry with the same key after checking status"),
    ("idempotency_conflict", 400, "never", "send one valid Idempotency-Key per logical invocation"),
    ("idempotency_conflict", 409, "never", "reuse the key only with the original request"),
    ("input_schema_invalid", 400, "never", "reduce the invocation input"),
    ("input_schema_invalid", 400, "never", "send bounded JSON matching the published input schema"),
    ("input_schema_invalid", 400, "never", "send valid JSON matching the published schema"),
    ("input_schema_invalid", 400, "never", "send input matching the published schema"),
    ("internal_error", 500, "never", "contact support with the correlation ID"),
    ("invocation_expired", 410, "never", "start a new invocation with a new idempotency key"),
    ("output_schema_invalid", 502, "never", "contact the capability provider"),
    ("permission_denied", 403, "never", "the approved version does not allow this transport"),
    ("permission_denied", 403, "state_change", "human approval is required for this binding"),
    ("permission_denied", 403, "state_change", "the agent policy denies this capability invocation"),
    ("permission_denied", 403, "state_change", "the agent policy requires approval for this invocation"),
    ("version_mismatch", 409, "state_change", "the pinned version is unavailable"),
)
