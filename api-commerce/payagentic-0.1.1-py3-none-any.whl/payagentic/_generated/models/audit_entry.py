from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.audit_entry_details import AuditEntryDetails


T = TypeVar("T", bound="AuditEntry")


@_attrs_define
class AuditEntry:
    """
    Attributes:
        action (str):
        actor_id (str):
        actor_type (str):
        created_at (datetime.datetime):
        details (AuditEntryDetails):
        hash_chain_current (str):
        hash_chain_previous (str):
        id (UUID):
        organization_id (UUID):
        resource_id (str):
        resource_type (str):
        verified (bool):
        actor_display (None | str | Unset): Human-readable actor: the user's email or the agent's name. `None` for
            true system actors (nil actor id) and unresolvable ids (e.g. the
            broadcaster's wallet-id actor).
    """

    action: str
    actor_id: str
    actor_type: str
    created_at: datetime.datetime
    details: AuditEntryDetails
    hash_chain_current: str
    hash_chain_previous: str
    id: UUID
    organization_id: UUID
    resource_id: str
    resource_type: str
    verified: bool
    actor_display: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.audit_entry_details import AuditEntryDetails

        action = self.action

        actor_id = self.actor_id

        actor_type = self.actor_type

        created_at = self.created_at.isoformat()

        details = self.details.to_dict()

        hash_chain_current = self.hash_chain_current

        hash_chain_previous = self.hash_chain_previous

        id = str(self.id)

        organization_id = str(self.organization_id)

        resource_id = self.resource_id

        resource_type = self.resource_type

        verified = self.verified

        actor_display: None | str | Unset
        if isinstance(self.actor_display, Unset):
            actor_display = UNSET
        else:
            actor_display = self.actor_display

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "action": action,
                "actorId": actor_id,
                "actorType": actor_type,
                "createdAt": created_at,
                "details": details,
                "hashChainCurrent": hash_chain_current,
                "hashChainPrevious": hash_chain_previous,
                "id": id,
                "organizationId": organization_id,
                "resourceId": resource_id,
                "resourceType": resource_type,
                "verified": verified,
            }
        )
        if actor_display is not UNSET:
            field_dict["actorDisplay"] = actor_display

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_entry_details import AuditEntryDetails

        d = dict(src_dict)
        action = d.pop("action")

        actor_id = d.pop("actorId")

        actor_type = d.pop("actorType")

        created_at = isoparse(d.pop("createdAt"))

        details = AuditEntryDetails.from_dict(d.pop("details"))

        hash_chain_current = d.pop("hashChainCurrent")

        hash_chain_previous = d.pop("hashChainPrevious")

        id = UUID(d.pop("id"))

        organization_id = UUID(d.pop("organizationId"))

        resource_id = d.pop("resourceId")

        resource_type = d.pop("resourceType")

        verified = d.pop("verified")

        def _parse_actor_display(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        actor_display = _parse_actor_display(d.pop("actorDisplay", UNSET))

        audit_entry = cls(
            action=action,
            actor_id=actor_id,
            actor_type=actor_type,
            created_at=created_at,
            details=details,
            hash_chain_current=hash_chain_current,
            hash_chain_previous=hash_chain_previous,
            id=id,
            organization_id=organization_id,
            resource_id=resource_id,
            resource_type=resource_type,
            verified=verified,
            actor_display=actor_display,
        )

        audit_entry.additional_properties = d
        return audit_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
