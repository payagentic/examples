from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CapabilityPriceResponse")


@_attrs_define
class CapabilityPriceResponse:
    """
    Attributes:
        currency (str):
        label (str):  Example: test USDC, not real, not redeemable.
        minor (str): Exact micro-USDC integer. It is a string so no JSON number can round it.
        mode (str):
    """

    currency: str
    label: str
    minor: str
    mode: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        currency = self.currency

        label = self.label

        minor = self.minor

        mode = self.mode

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "currency": currency,
                "label": label,
                "minor": minor,
                "mode": mode,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        currency = d.pop("currency")

        label = d.pop("label")

        minor = d.pop("minor")

        mode = d.pop("mode")

        capability_price_response = cls(
            currency=currency,
            label=label,
            minor=minor,
            mode=mode,
        )

        capability_price_response.additional_properties = d
        return capability_price_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
