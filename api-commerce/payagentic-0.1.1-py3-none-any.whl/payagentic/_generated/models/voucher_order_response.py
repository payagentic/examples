from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="VoucherOrderResponse")


@_attrs_define
class VoucherOrderResponse:
    """
    Attributes:
        checkout_intent_id (UUID):
        country (str):
        created_at (datetime.datetime):
        face_currency (str):
        face_value (str):
        merchant_name (str):
        provider (str):
        provider_product_id (str):
        secret_state (str):
        status (str):
        updated_at (datetime.datetime):
        voucher_order_id (UUID):
        delivery_format (None | str | Unset):
        live_provider_status (None | str | Unset): Best-effort, non-authoritative status straight from the live
            Bitrefill
            invoice (only populated when `bitrefill_provider != "mock"` and the
            order is past `awaiting_payment`). Never written back to `status`
            (which is a constrained internal state machine) -- this is purely for
            operator visibility while the durable reconciliation worker described
            in `docs/bitrefill-ecommerce-connector-spec.md` §11 doesn't exist yet.
        pay_amount (None | str | Unset):
        pay_chain (None | str | Unset):
        pay_currency (None | str | Unset):
        provider_invoice_id (None | str | Unset):
        provider_order_id (None | str | Unset):
        provider_package_id (None | str | Unset):
        redemption_status (None | str | Unset):
        tx_hash (None | str | Unset):
    """

    checkout_intent_id: UUID
    country: str
    created_at: datetime.datetime
    face_currency: str
    face_value: str
    merchant_name: str
    provider: str
    provider_product_id: str
    secret_state: str
    status: str
    updated_at: datetime.datetime
    voucher_order_id: UUID
    delivery_format: None | str | Unset = UNSET
    live_provider_status: None | str | Unset = UNSET
    pay_amount: None | str | Unset = UNSET
    pay_chain: None | str | Unset = UNSET
    pay_currency: None | str | Unset = UNSET
    provider_invoice_id: None | str | Unset = UNSET
    provider_order_id: None | str | Unset = UNSET
    provider_package_id: None | str | Unset = UNSET
    redemption_status: None | str | Unset = UNSET
    tx_hash: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        checkout_intent_id = str(self.checkout_intent_id)

        country = self.country

        created_at = self.created_at.isoformat()

        face_currency = self.face_currency

        face_value = self.face_value

        merchant_name = self.merchant_name

        provider = self.provider

        provider_product_id = self.provider_product_id

        secret_state = self.secret_state

        status = self.status

        updated_at = self.updated_at.isoformat()

        voucher_order_id = str(self.voucher_order_id)

        delivery_format: None | str | Unset
        if isinstance(self.delivery_format, Unset):
            delivery_format = UNSET
        else:
            delivery_format = self.delivery_format

        live_provider_status: None | str | Unset
        if isinstance(self.live_provider_status, Unset):
            live_provider_status = UNSET
        else:
            live_provider_status = self.live_provider_status

        pay_amount: None | str | Unset
        if isinstance(self.pay_amount, Unset):
            pay_amount = UNSET
        else:
            pay_amount = self.pay_amount

        pay_chain: None | str | Unset
        if isinstance(self.pay_chain, Unset):
            pay_chain = UNSET
        else:
            pay_chain = self.pay_chain

        pay_currency: None | str | Unset
        if isinstance(self.pay_currency, Unset):
            pay_currency = UNSET
        else:
            pay_currency = self.pay_currency

        provider_invoice_id: None | str | Unset
        if isinstance(self.provider_invoice_id, Unset):
            provider_invoice_id = UNSET
        else:
            provider_invoice_id = self.provider_invoice_id

        provider_order_id: None | str | Unset
        if isinstance(self.provider_order_id, Unset):
            provider_order_id = UNSET
        else:
            provider_order_id = self.provider_order_id

        provider_package_id: None | str | Unset
        if isinstance(self.provider_package_id, Unset):
            provider_package_id = UNSET
        else:
            provider_package_id = self.provider_package_id

        redemption_status: None | str | Unset
        if isinstance(self.redemption_status, Unset):
            redemption_status = UNSET
        else:
            redemption_status = self.redemption_status

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "checkoutIntentId": checkout_intent_id,
                "country": country,
                "createdAt": created_at,
                "faceCurrency": face_currency,
                "faceValue": face_value,
                "merchantName": merchant_name,
                "provider": provider,
                "providerProductId": provider_product_id,
                "secretState": secret_state,
                "status": status,
                "updatedAt": updated_at,
                "voucherOrderId": voucher_order_id,
            }
        )
        if delivery_format is not UNSET:
            field_dict["deliveryFormat"] = delivery_format
        if live_provider_status is not UNSET:
            field_dict["liveProviderStatus"] = live_provider_status
        if pay_amount is not UNSET:
            field_dict["payAmount"] = pay_amount
        if pay_chain is not UNSET:
            field_dict["payChain"] = pay_chain
        if pay_currency is not UNSET:
            field_dict["payCurrency"] = pay_currency
        if provider_invoice_id is not UNSET:
            field_dict["providerInvoiceId"] = provider_invoice_id
        if provider_order_id is not UNSET:
            field_dict["providerOrderId"] = provider_order_id
        if provider_package_id is not UNSET:
            field_dict["providerPackageId"] = provider_package_id
        if redemption_status is not UNSET:
            field_dict["redemptionStatus"] = redemption_status
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        checkout_intent_id = UUID(d.pop("checkoutIntentId"))

        country = d.pop("country")

        created_at = isoparse(d.pop("createdAt"))

        face_currency = d.pop("faceCurrency")

        face_value = d.pop("faceValue")

        merchant_name = d.pop("merchantName")

        provider = d.pop("provider")

        provider_product_id = d.pop("providerProductId")

        secret_state = d.pop("secretState")

        status = d.pop("status")

        updated_at = isoparse(d.pop("updatedAt"))

        voucher_order_id = UUID(d.pop("voucherOrderId"))

        def _parse_delivery_format(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        delivery_format = _parse_delivery_format(d.pop("deliveryFormat", UNSET))

        def _parse_live_provider_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        live_provider_status = _parse_live_provider_status(d.pop("liveProviderStatus", UNSET))

        def _parse_pay_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        pay_amount = _parse_pay_amount(d.pop("payAmount", UNSET))

        def _parse_pay_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        pay_chain = _parse_pay_chain(d.pop("payChain", UNSET))

        def _parse_pay_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        pay_currency = _parse_pay_currency(d.pop("payCurrency", UNSET))

        def _parse_provider_invoice_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_invoice_id = _parse_provider_invoice_id(d.pop("providerInvoiceId", UNSET))

        def _parse_provider_order_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_order_id = _parse_provider_order_id(d.pop("providerOrderId", UNSET))

        def _parse_provider_package_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_package_id = _parse_provider_package_id(d.pop("providerPackageId", UNSET))

        def _parse_redemption_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        redemption_status = _parse_redemption_status(d.pop("redemptionStatus", UNSET))

        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("txHash", UNSET))

        voucher_order_response = cls(
            checkout_intent_id=checkout_intent_id,
            country=country,
            created_at=created_at,
            face_currency=face_currency,
            face_value=face_value,
            merchant_name=merchant_name,
            provider=provider,
            provider_product_id=provider_product_id,
            secret_state=secret_state,
            status=status,
            updated_at=updated_at,
            voucher_order_id=voucher_order_id,
            delivery_format=delivery_format,
            live_provider_status=live_provider_status,
            pay_amount=pay_amount,
            pay_chain=pay_chain,
            pay_currency=pay_currency,
            provider_invoice_id=provider_invoice_id,
            provider_order_id=provider_order_id,
            provider_package_id=provider_package_id,
            redemption_status=redemption_status,
            tx_hash=tx_hash,
        )

        voucher_order_response.additional_properties = d
        return voucher_order_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
