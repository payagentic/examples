from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="EarningRow")


@_attrs_define
class EarningRow:
    """
    Attributes:
        amount_micro (int):
        currency (str):
        id (UUID):
        settled_at (datetime.datetime):
        agent_id_redacted (None | str | Unset):
        endpoint_id (None | Unset | UUID):
        endpoint_url (None | str | Unset):
        tx_hash (None | str | Unset):
    """

    amount_micro: int
    currency: str
    id: UUID
    settled_at: datetime.datetime
    agent_id_redacted: None | str | Unset = UNSET
    endpoint_id: None | Unset | UUID = UNSET
    endpoint_url: None | str | Unset = UNSET
    tx_hash: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount_micro = self.amount_micro

        currency = self.currency

        id = str(self.id)

        settled_at = self.settled_at.isoformat()

        agent_id_redacted: None | str | Unset
        if isinstance(self.agent_id_redacted, Unset):
            agent_id_redacted = UNSET
        else:
            agent_id_redacted = self.agent_id_redacted

        endpoint_id: None | str | Unset
        if isinstance(self.endpoint_id, Unset):
            endpoint_id = UNSET
        elif isinstance(self.endpoint_id, UUID):
            endpoint_id = str(self.endpoint_id)
        else:
            endpoint_id = self.endpoint_id

        endpoint_url: None | str | Unset
        if isinstance(self.endpoint_url, Unset):
            endpoint_url = UNSET
        else:
            endpoint_url = self.endpoint_url

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount_micro": amount_micro,
                "currency": currency,
                "id": id,
                "settled_at": settled_at,
            }
        )
        if agent_id_redacted is not UNSET:
            field_dict["agent_id_redacted"] = agent_id_redacted
        if endpoint_id is not UNSET:
            field_dict["endpoint_id"] = endpoint_id
        if endpoint_url is not UNSET:
            field_dict["endpoint_url"] = endpoint_url
        if tx_hash is not UNSET:
            field_dict["tx_hash"] = tx_hash

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount_micro = d.pop("amount_micro")

        currency = d.pop("currency")

        id = UUID(d.pop("id"))

        settled_at = isoparse(d.pop("settled_at"))

        def _parse_agent_id_redacted(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_id_redacted = _parse_agent_id_redacted(d.pop("agent_id_redacted", UNSET))

        def _parse_endpoint_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                endpoint_id_type_0 = UUID(data)

                return endpoint_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        endpoint_id = _parse_endpoint_id(d.pop("endpoint_id", UNSET))

        def _parse_endpoint_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        endpoint_url = _parse_endpoint_url(d.pop("endpoint_url", UNSET))

        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("tx_hash", UNSET))

        earning_row = cls(
            amount_micro=amount_micro,
            currency=currency,
            id=id,
            settled_at=settled_at,
            agent_id_redacted=agent_id_redacted,
            endpoint_id=endpoint_id,
            endpoint_url=endpoint_url,
            tx_hash=tx_hash,
        )

        earning_row.additional_properties = d
        return earning_row

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
