from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="RecordCheckoutReceiptRequest")


@_attrs_define
class RecordCheckoutReceiptRequest:
    """
    Attributes:
        currency (str):
        total (str):
        merchant_receipt_ref (None | str | Unset):
        order_id (None | str | Unset):
        raw_receipt (Any | Unset):
        receipt_url (None | str | Unset):
    """

    currency: str
    total: str
    merchant_receipt_ref: None | str | Unset = UNSET
    order_id: None | str | Unset = UNSET
    raw_receipt: Any | Unset = UNSET
    receipt_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        currency = self.currency

        total = self.total

        merchant_receipt_ref: None | str | Unset
        if isinstance(self.merchant_receipt_ref, Unset):
            merchant_receipt_ref = UNSET
        else:
            merchant_receipt_ref = self.merchant_receipt_ref

        order_id: None | str | Unset
        if isinstance(self.order_id, Unset):
            order_id = UNSET
        else:
            order_id = self.order_id

        raw_receipt = self.raw_receipt

        receipt_url: None | str | Unset
        if isinstance(self.receipt_url, Unset):
            receipt_url = UNSET
        else:
            receipt_url = self.receipt_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "currency": currency,
                "total": total,
            }
        )
        if merchant_receipt_ref is not UNSET:
            field_dict["merchantReceiptRef"] = merchant_receipt_ref
        if order_id is not UNSET:
            field_dict["orderId"] = order_id
        if raw_receipt is not UNSET:
            field_dict["rawReceipt"] = raw_receipt
        if receipt_url is not UNSET:
            field_dict["receiptUrl"] = receipt_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        currency = d.pop("currency")

        total = d.pop("total")

        def _parse_merchant_receipt_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        merchant_receipt_ref = _parse_merchant_receipt_ref(d.pop("merchantReceiptRef", UNSET))

        def _parse_order_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        order_id = _parse_order_id(d.pop("orderId", UNSET))

        raw_receipt = d.pop("rawReceipt", UNSET)

        def _parse_receipt_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        receipt_url = _parse_receipt_url(d.pop("receiptUrl", UNSET))

        record_checkout_receipt_request = cls(
            currency=currency,
            total=total,
            merchant_receipt_ref=merchant_receipt_ref,
            order_id=order_id,
            raw_receipt=raw_receipt,
            receipt_url=receipt_url,
        )

        record_checkout_receipt_request.additional_properties = d
        return record_checkout_receipt_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
