from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="RefundRow")


@_attrs_define
class RefundRow:
    """
    Attributes:
        amount_micro (int):
        currency (str):
        id (UUID):
        payment_id (UUID):
        requested_at (datetime.datetime):
        status (str):
        reason (None | str | Unset):
    """

    amount_micro: int
    currency: str
    id: UUID
    payment_id: UUID
    requested_at: datetime.datetime
    status: str
    reason: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount_micro = self.amount_micro

        currency = self.currency

        id = str(self.id)

        payment_id = str(self.payment_id)

        requested_at = self.requested_at.isoformat()

        status = self.status

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount_micro": amount_micro,
                "currency": currency,
                "id": id,
                "payment_id": payment_id,
                "requested_at": requested_at,
                "status": status,
            }
        )
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount_micro = d.pop("amount_micro")

        currency = d.pop("currency")

        id = UUID(d.pop("id"))

        payment_id = UUID(d.pop("payment_id"))

        requested_at = isoparse(d.pop("requested_at"))

        status = d.pop("status")

        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))

        refund_row = cls(
            amount_micro=amount_micro,
            currency=currency,
            id=id,
            payment_id=payment_id,
            requested_at=requested_at,
            status=status,
            reason=reason,
        )

        refund_row.additional_properties = d
        return refund_row

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
