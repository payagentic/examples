from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime


T = TypeVar("T", bound="VoucherConstraints")


@_attrs_define
class VoucherConstraints:
    """
    Attributes:
        expires_at (datetime.datetime | None | Unset):
        max_total (None | str | Unset):
        max_total_currency (None | str | Unset):
        requires_user_approval (bool | None | Unset):
    """

    expires_at: datetime.datetime | None | Unset = UNSET
    max_total: None | str | Unset = UNSET
    max_total_currency: None | str | Unset = UNSET
    requires_user_approval: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        max_total: None | str | Unset
        if isinstance(self.max_total, Unset):
            max_total = UNSET
        else:
            max_total = self.max_total

        max_total_currency: None | str | Unset
        if isinstance(self.max_total_currency, Unset):
            max_total_currency = UNSET
        else:
            max_total_currency = self.max_total_currency

        requires_user_approval: bool | None | Unset
        if isinstance(self.requires_user_approval, Unset):
            requires_user_approval = UNSET
        else:
            requires_user_approval = self.requires_user_approval

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at
        if max_total is not UNSET:
            field_dict["maxTotal"] = max_total
        if max_total_currency is not UNSET:
            field_dict["maxTotalCurrency"] = max_total_currency
        if requires_user_approval is not UNSET:
            field_dict["requiresUserApproval"] = requires_user_approval

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        def _parse_max_total(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        max_total = _parse_max_total(d.pop("maxTotal", UNSET))

        def _parse_max_total_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        max_total_currency = _parse_max_total_currency(d.pop("maxTotalCurrency", UNSET))

        def _parse_requires_user_approval(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        requires_user_approval = _parse_requires_user_approval(d.pop("requiresUserApproval", UNSET))

        voucher_constraints = cls(
            expires_at=expires_at,
            max_total=max_total,
            max_total_currency=max_total_currency,
            requires_user_approval=requires_user_approval,
        )

        voucher_constraints.additional_properties = d
        return voucher_constraints

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
