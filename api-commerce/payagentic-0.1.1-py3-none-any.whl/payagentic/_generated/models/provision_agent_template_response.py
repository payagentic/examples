from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.blueprint_guardrails import BlueprintGuardrails
    from ..models.blueprint_starter_kit import BlueprintStarterKit


T = TypeVar("T", bound="ProvisionAgentTemplateResponse")


@_attrs_define
class ProvisionAgentTemplateResponse:
    """
    Attributes:
        agent_id (UUID):
        api_key_prefix (str):
        credential_state (str):
        guardrails (BlueprintGuardrails):
        manifest_checksum (str):
        policy_ids (list[UUID]):
        profile (str):
        starter_kit (BlueprintStarterKit):
        template_slug (str):
        template_version (str):
        wallet_id (UUID):
        api_key (None | str | Unset):
    """

    agent_id: UUID
    api_key_prefix: str
    credential_state: str
    guardrails: BlueprintGuardrails
    manifest_checksum: str
    policy_ids: list[UUID]
    profile: str
    starter_kit: BlueprintStarterKit
    template_slug: str
    template_version: str
    wallet_id: UUID
    api_key: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.blueprint_guardrails import BlueprintGuardrails
        from ..models.blueprint_starter_kit import BlueprintStarterKit

        agent_id = str(self.agent_id)

        api_key_prefix = self.api_key_prefix

        credential_state = self.credential_state

        guardrails = self.guardrails.to_dict()

        manifest_checksum = self.manifest_checksum

        policy_ids = []
        for policy_ids_item_data in self.policy_ids:
            policy_ids_item = str(policy_ids_item_data)
            policy_ids.append(policy_ids_item)

        profile = self.profile

        starter_kit = self.starter_kit.to_dict()

        template_slug = self.template_slug

        template_version = self.template_version

        wallet_id = str(self.wallet_id)

        api_key: None | str | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        else:
            api_key = self.api_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentId": agent_id,
                "apiKeyPrefix": api_key_prefix,
                "credentialState": credential_state,
                "guardrails": guardrails,
                "manifestChecksum": manifest_checksum,
                "policyIds": policy_ids,
                "profile": profile,
                "starterKit": starter_kit,
                "templateSlug": template_slug,
                "templateVersion": template_version,
                "walletId": wallet_id,
            }
        )
        if api_key is not UNSET:
            field_dict["apiKey"] = api_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blueprint_guardrails import BlueprintGuardrails
        from ..models.blueprint_starter_kit import BlueprintStarterKit

        d = dict(src_dict)
        agent_id = UUID(d.pop("agentId"))

        api_key_prefix = d.pop("apiKeyPrefix")

        credential_state = d.pop("credentialState")

        guardrails = BlueprintGuardrails.from_dict(d.pop("guardrails"))

        manifest_checksum = d.pop("manifestChecksum")

        policy_ids = []
        _policy_ids = d.pop("policyIds")
        for policy_ids_item_data in _policy_ids:
            policy_ids_item = UUID(policy_ids_item_data)

            policy_ids.append(policy_ids_item)

        profile = d.pop("profile")

        starter_kit = BlueprintStarterKit.from_dict(d.pop("starterKit"))

        template_slug = d.pop("templateSlug")

        template_version = d.pop("templateVersion")

        wallet_id = UUID(d.pop("walletId"))

        def _parse_api_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key = _parse_api_key(d.pop("apiKey", UNSET))

        provision_agent_template_response = cls(
            agent_id=agent_id,
            api_key_prefix=api_key_prefix,
            credential_state=credential_state,
            guardrails=guardrails,
            manifest_checksum=manifest_checksum,
            policy_ids=policy_ids,
            profile=profile,
            starter_kit=starter_kit,
            template_slug=template_slug,
            template_version=template_version,
            wallet_id=wallet_id,
            api_key=api_key,
        )

        provision_agent_template_response.additional_properties = d
        return provision_agent_template_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
