from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="QuoteVoucherRequest")


@_attrs_define
class QuoteVoucherRequest:
    """
    Attributes:
        country (str):
        face_currency (str):
        face_value (str):
        pay_chain (str):
        pay_currency (str):
        provider_product_id (str):
    """

    country: str
    face_currency: str
    face_value: str
    pay_chain: str
    pay_currency: str
    provider_product_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        country = self.country

        face_currency = self.face_currency

        face_value = self.face_value

        pay_chain = self.pay_chain

        pay_currency = self.pay_currency

        provider_product_id = self.provider_product_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "country": country,
                "faceCurrency": face_currency,
                "faceValue": face_value,
                "payChain": pay_chain,
                "payCurrency": pay_currency,
                "providerProductId": provider_product_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        country = d.pop("country")

        face_currency = d.pop("faceCurrency")

        face_value = d.pop("faceValue")

        pay_chain = d.pop("payChain")

        pay_currency = d.pop("payCurrency")

        provider_product_id = d.pop("providerProductId")

        quote_voucher_request = cls(
            country=country,
            face_currency=face_currency,
            face_value=face_value,
            pay_chain=pay_chain,
            pay_currency=pay_currency,
            provider_product_id=provider_product_id,
        )

        quote_voucher_request.additional_properties = d
        return quote_voucher_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
