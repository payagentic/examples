from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="Approval")


@_attrs_define
class Approval:
    """
    Attributes:
        agent_id (UUID):
        amount (str):
        approval_type (str):
        created_at (datetime.datetime):
        currency (str):
        expires_at (datetime.datetime):
        id (UUID):
        organization_id (UUID):
        payment_id (UUID):
        reason (str):
        status (str):
        reviewed_by (None | str | Unset):
    """

    agent_id: UUID
    amount: str
    approval_type: str
    created_at: datetime.datetime
    currency: str
    expires_at: datetime.datetime
    id: UUID
    organization_id: UUID
    payment_id: UUID
    reason: str
    status: str
    reviewed_by: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_id = str(self.agent_id)

        amount = self.amount

        approval_type = self.approval_type

        created_at = self.created_at.isoformat()

        currency = self.currency

        expires_at = self.expires_at.isoformat()

        id = str(self.id)

        organization_id = str(self.organization_id)

        payment_id = str(self.payment_id)

        reason = self.reason

        status = self.status

        reviewed_by: None | str | Unset
        if isinstance(self.reviewed_by, Unset):
            reviewed_by = UNSET
        else:
            reviewed_by = self.reviewed_by

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentId": agent_id,
                "amount": amount,
                "approvalType": approval_type,
                "createdAt": created_at,
                "currency": currency,
                "expiresAt": expires_at,
                "id": id,
                "organizationId": organization_id,
                "paymentId": payment_id,
                "reason": reason,
                "status": status,
            }
        )
        if reviewed_by is not UNSET:
            field_dict["reviewedBy"] = reviewed_by

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_id = UUID(d.pop("agentId"))

        amount = d.pop("amount")

        approval_type = d.pop("approvalType")

        created_at = isoparse(d.pop("createdAt"))

        currency = d.pop("currency")

        expires_at = isoparse(d.pop("expiresAt"))

        id = UUID(d.pop("id"))

        organization_id = UUID(d.pop("organizationId"))

        payment_id = UUID(d.pop("paymentId"))

        reason = d.pop("reason")

        status = d.pop("status")

        def _parse_reviewed_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reviewed_by = _parse_reviewed_by(d.pop("reviewedBy", UNSET))

        approval = cls(
            agent_id=agent_id,
            amount=amount,
            approval_type=approval_type,
            created_at=created_at,
            currency=currency,
            expires_at=expires_at,
            id=id,
            organization_id=organization_id,
            payment_id=payment_id,
            reason=reason,
            status=status,
            reviewed_by=reviewed_by,
        )

        approval.additional_properties = d
        return approval

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
