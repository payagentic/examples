from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.capability_binding_authority_summary_data_policy import (
        CapabilityBindingAuthoritySummaryDataPolicy,
    )


T = TypeVar("T", bound="CapabilityBindingAuthoritySummary")


@_attrs_define
class CapabilityBindingAuthoritySummary:
    """
    Attributes:
        auto_invoke (bool):
        capability_id (str):
        data_policy (CapabilityBindingAuthoritySummaryDataPolicy):
        manifest_checksum (str):
        manifest_price (str):
        maximum_calls (int):
        per_call_limit (str):
        provider_display_name (str):
        provider_id (str):
        provider_verified (bool):
        purpose (str):
        total_limit (str):
        version (str):
    """

    auto_invoke: bool
    capability_id: str
    data_policy: CapabilityBindingAuthoritySummaryDataPolicy
    manifest_checksum: str
    manifest_price: str
    maximum_calls: int
    per_call_limit: str
    provider_display_name: str
    provider_id: str
    provider_verified: bool
    purpose: str
    total_limit: str
    version: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_binding_authority_summary_data_policy import (
            CapabilityBindingAuthoritySummaryDataPolicy,
        )

        auto_invoke = self.auto_invoke

        capability_id = self.capability_id

        data_policy = self.data_policy.to_dict()

        manifest_checksum = self.manifest_checksum

        manifest_price = self.manifest_price

        maximum_calls = self.maximum_calls

        per_call_limit = self.per_call_limit

        provider_display_name = self.provider_display_name

        provider_id = self.provider_id

        provider_verified = self.provider_verified

        purpose = self.purpose

        total_limit = self.total_limit

        version = self.version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "autoInvoke": auto_invoke,
                "capabilityId": capability_id,
                "dataPolicy": data_policy,
                "manifestChecksum": manifest_checksum,
                "manifestPrice": manifest_price,
                "maximumCalls": maximum_calls,
                "perCallLimit": per_call_limit,
                "providerDisplayName": provider_display_name,
                "providerId": provider_id,
                "providerVerified": provider_verified,
                "purpose": purpose,
                "totalLimit": total_limit,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_binding_authority_summary_data_policy import (
            CapabilityBindingAuthoritySummaryDataPolicy,
        )

        d = dict(src_dict)
        auto_invoke = d.pop("autoInvoke")

        capability_id = d.pop("capabilityId")

        data_policy = CapabilityBindingAuthoritySummaryDataPolicy.from_dict(d.pop("dataPolicy"))

        manifest_checksum = d.pop("manifestChecksum")

        manifest_price = d.pop("manifestPrice")

        maximum_calls = d.pop("maximumCalls")

        per_call_limit = d.pop("perCallLimit")

        provider_display_name = d.pop("providerDisplayName")

        provider_id = d.pop("providerId")

        provider_verified = d.pop("providerVerified")

        purpose = d.pop("purpose")

        total_limit = d.pop("totalLimit")

        version = d.pop("version")

        capability_binding_authority_summary = cls(
            auto_invoke=auto_invoke,
            capability_id=capability_id,
            data_policy=data_policy,
            manifest_checksum=manifest_checksum,
            manifest_price=manifest_price,
            maximum_calls=maximum_calls,
            per_call_limit=per_call_limit,
            provider_display_name=provider_display_name,
            provider_id=provider_id,
            provider_verified=provider_verified,
            purpose=purpose,
            total_limit=total_limit,
            version=version,
        )

        capability_binding_authority_summary.additional_properties = d
        return capability_binding_authority_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
