from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="MandateListItem")


@_attrs_define
class MandateListItem:
    """Row returned to the dashboard.

    Field names match `MandateListItem` in `web/src/lib/mandate-api.ts`.
    `org_id` is included so the platform-admin cross-org view can label rows
    by tenant; the dashboard renders it conditionally.

        Attributes:
            expires_at (datetime.datetime):
            issuer_kid (str):
            jti (str):
            org_id (UUID):
            revoked (bool):
            subject_agent_id (UUID):
            parent_jti (None | str | Unset):
    """

    expires_at: datetime.datetime
    issuer_kid: str
    jti: str
    org_id: UUID
    revoked: bool
    subject_agent_id: UUID
    parent_jti: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        expires_at = self.expires_at.isoformat()

        issuer_kid = self.issuer_kid

        jti = self.jti

        org_id = str(self.org_id)

        revoked = self.revoked

        subject_agent_id = str(self.subject_agent_id)

        parent_jti: None | str | Unset
        if isinstance(self.parent_jti, Unset):
            parent_jti = UNSET
        else:
            parent_jti = self.parent_jti

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "expires_at": expires_at,
                "issuer_kid": issuer_kid,
                "jti": jti,
                "org_id": org_id,
                "revoked": revoked,
                "subject_agent_id": subject_agent_id,
            }
        )
        if parent_jti is not UNSET:
            field_dict["parent_jti"] = parent_jti

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        expires_at = isoparse(d.pop("expires_at"))

        issuer_kid = d.pop("issuer_kid")

        jti = d.pop("jti")

        org_id = UUID(d.pop("org_id"))

        revoked = d.pop("revoked")

        subject_agent_id = UUID(d.pop("subject_agent_id"))

        def _parse_parent_jti(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_jti = _parse_parent_jti(d.pop("parent_jti", UNSET))

        mandate_list_item = cls(
            expires_at=expires_at,
            issuer_kid=issuer_kid,
            jti=jti,
            org_id=org_id,
            revoked=revoked,
            subject_agent_id=subject_agent_id,
            parent_jti=parent_jti,
        )

        mandate_list_item.additional_properties = d
        return mandate_list_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
