from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.checkout_amounts_response import CheckoutAmountsResponse
    from ..models.checkout_constraints_response import CheckoutConstraintsResponse
    from ..models.checkout_item import CheckoutItem
    from ..models.checkout_merchant import CheckoutMerchant
    from ..models.checkout_receipt import CheckoutReceipt


T = TypeVar("T", bound="CheckoutIntentResponse")


@_attrs_define
class CheckoutIntentResponse:
    """
    Attributes:
        agent_id (UUID):
        amounts (CheckoutAmountsResponse):
        constraints (CheckoutConstraintsResponse):
        created_at (datetime.datetime):
        id (UUID):
        items (list[CheckoutItem]):
        merchant (CheckoutMerchant):
        org_id (UUID):
        receipt (CheckoutReceipt | None):
        status (str):
        updated_at (datetime.datetime):
        wallet_id (UUID):
        acting_on_behalf_of_user_id (None | Unset | UUID):
        payment_transaction_id (None | Unset | UUID):
        policy_decision_id (None | Unset | UUID):
        purpose (None | str | Unset):
        receipt_id (None | Unset | UUID):
    """

    agent_id: UUID
    amounts: CheckoutAmountsResponse
    constraints: CheckoutConstraintsResponse
    created_at: datetime.datetime
    id: UUID
    items: list[CheckoutItem]
    merchant: CheckoutMerchant
    org_id: UUID
    receipt: CheckoutReceipt | None
    status: str
    updated_at: datetime.datetime
    wallet_id: UUID
    acting_on_behalf_of_user_id: None | Unset | UUID = UNSET
    payment_transaction_id: None | Unset | UUID = UNSET
    policy_decision_id: None | Unset | UUID = UNSET
    purpose: None | str | Unset = UNSET
    receipt_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.checkout_amounts_response import CheckoutAmountsResponse
        from ..models.checkout_constraints_response import CheckoutConstraintsResponse
        from ..models.checkout_item import CheckoutItem
        from ..models.checkout_merchant import CheckoutMerchant
        from ..models.checkout_receipt import CheckoutReceipt

        agent_id = str(self.agent_id)

        amounts = self.amounts.to_dict()

        constraints = self.constraints.to_dict()

        created_at = self.created_at.isoformat()

        id = str(self.id)

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)

        merchant = self.merchant.to_dict()

        org_id = str(self.org_id)

        receipt: dict[str, Any] | None
        if isinstance(self.receipt, CheckoutReceipt):
            receipt = self.receipt.to_dict()
        else:
            receipt = self.receipt

        status = self.status

        updated_at = self.updated_at.isoformat()

        wallet_id = str(self.wallet_id)

        acting_on_behalf_of_user_id: None | str | Unset
        if isinstance(self.acting_on_behalf_of_user_id, Unset):
            acting_on_behalf_of_user_id = UNSET
        elif isinstance(self.acting_on_behalf_of_user_id, UUID):
            acting_on_behalf_of_user_id = str(self.acting_on_behalf_of_user_id)
        else:
            acting_on_behalf_of_user_id = self.acting_on_behalf_of_user_id

        payment_transaction_id: None | str | Unset
        if isinstance(self.payment_transaction_id, Unset):
            payment_transaction_id = UNSET
        elif isinstance(self.payment_transaction_id, UUID):
            payment_transaction_id = str(self.payment_transaction_id)
        else:
            payment_transaction_id = self.payment_transaction_id

        policy_decision_id: None | str | Unset
        if isinstance(self.policy_decision_id, Unset):
            policy_decision_id = UNSET
        elif isinstance(self.policy_decision_id, UUID):
            policy_decision_id = str(self.policy_decision_id)
        else:
            policy_decision_id = self.policy_decision_id

        purpose: None | str | Unset
        if isinstance(self.purpose, Unset):
            purpose = UNSET
        else:
            purpose = self.purpose

        receipt_id: None | str | Unset
        if isinstance(self.receipt_id, Unset):
            receipt_id = UNSET
        elif isinstance(self.receipt_id, UUID):
            receipt_id = str(self.receipt_id)
        else:
            receipt_id = self.receipt_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentId": agent_id,
                "amounts": amounts,
                "constraints": constraints,
                "createdAt": created_at,
                "id": id,
                "items": items,
                "merchant": merchant,
                "orgId": org_id,
                "receipt": receipt,
                "status": status,
                "updatedAt": updated_at,
                "walletId": wallet_id,
            }
        )
        if acting_on_behalf_of_user_id is not UNSET:
            field_dict["actingOnBehalfOfUserId"] = acting_on_behalf_of_user_id
        if payment_transaction_id is not UNSET:
            field_dict["paymentTransactionId"] = payment_transaction_id
        if policy_decision_id is not UNSET:
            field_dict["policyDecisionId"] = policy_decision_id
        if purpose is not UNSET:
            field_dict["purpose"] = purpose
        if receipt_id is not UNSET:
            field_dict["receiptId"] = receipt_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.checkout_amounts_response import CheckoutAmountsResponse
        from ..models.checkout_constraints_response import CheckoutConstraintsResponse
        from ..models.checkout_item import CheckoutItem
        from ..models.checkout_merchant import CheckoutMerchant
        from ..models.checkout_receipt import CheckoutReceipt

        d = dict(src_dict)
        agent_id = UUID(d.pop("agentId"))

        amounts = CheckoutAmountsResponse.from_dict(d.pop("amounts"))

        constraints = CheckoutConstraintsResponse.from_dict(d.pop("constraints"))

        created_at = isoparse(d.pop("createdAt"))

        id = UUID(d.pop("id"))

        items = []
        _items = d.pop("items")
        for items_item_data in _items:
            items_item = CheckoutItem.from_dict(items_item_data)

            items.append(items_item)

        merchant = CheckoutMerchant.from_dict(d.pop("merchant"))

        org_id = UUID(d.pop("orgId"))

        def _parse_receipt(data: object) -> CheckoutReceipt | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                receipt_type_1 = CheckoutReceipt.from_dict(data)

                return receipt_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CheckoutReceipt | None, data)

        receipt = _parse_receipt(d.pop("receipt"))

        status = d.pop("status")

        updated_at = isoparse(d.pop("updatedAt"))

        wallet_id = UUID(d.pop("walletId"))

        def _parse_acting_on_behalf_of_user_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                acting_on_behalf_of_user_id_type_0 = UUID(data)

                return acting_on_behalf_of_user_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        acting_on_behalf_of_user_id = _parse_acting_on_behalf_of_user_id(
            d.pop("actingOnBehalfOfUserId", UNSET)
        )

        def _parse_payment_transaction_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                payment_transaction_id_type_0 = UUID(data)

                return payment_transaction_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        payment_transaction_id = _parse_payment_transaction_id(d.pop("paymentTransactionId", UNSET))

        def _parse_policy_decision_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                policy_decision_id_type_0 = UUID(data)

                return policy_decision_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        policy_decision_id = _parse_policy_decision_id(d.pop("policyDecisionId", UNSET))

        def _parse_purpose(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        purpose = _parse_purpose(d.pop("purpose", UNSET))

        def _parse_receipt_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                receipt_id_type_0 = UUID(data)

                return receipt_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        receipt_id = _parse_receipt_id(d.pop("receiptId", UNSET))

        checkout_intent_response = cls(
            agent_id=agent_id,
            amounts=amounts,
            constraints=constraints,
            created_at=created_at,
            id=id,
            items=items,
            merchant=merchant,
            org_id=org_id,
            receipt=receipt,
            status=status,
            updated_at=updated_at,
            wallet_id=wallet_id,
            acting_on_behalf_of_user_id=acting_on_behalf_of_user_id,
            payment_transaction_id=payment_transaction_id,
            policy_decision_id=policy_decision_id,
            purpose=purpose,
            receipt_id=receipt_id,
        )

        checkout_intent_response.additional_properties = d
        return checkout_intent_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
