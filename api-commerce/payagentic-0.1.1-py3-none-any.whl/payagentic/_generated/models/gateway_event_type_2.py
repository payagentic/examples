from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.gateway_event_type_2_type import GatewayEventType2Type
from uuid import UUID


T = TypeVar("T", bound="GatewayEventType2")


@_attrs_define
class GatewayEventType2:
    """
    Attributes:
        organization_id (UUID):
        payment_id (UUID):
        reason (str):
        type_ (GatewayEventType2Type):
    """

    organization_id: UUID
    payment_id: UUID
    reason: str
    type_: GatewayEventType2Type
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        organization_id = str(self.organization_id)

        payment_id = str(self.payment_id)

        reason = self.reason

        type_ = self.type_.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "organization_id": organization_id,
                "payment_id": payment_id,
                "reason": reason,
                "type": type_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        organization_id = UUID(d.pop("organization_id"))

        payment_id = UUID(d.pop("payment_id"))

        reason = d.pop("reason")

        type_ = GatewayEventType2Type(d.pop("type"))

        gateway_event_type_2 = cls(
            organization_id=organization_id,
            payment_id=payment_id,
            reason=reason,
            type_=type_,
        )

        gateway_event_type_2.additional_properties = d
        return gateway_event_type_2

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
