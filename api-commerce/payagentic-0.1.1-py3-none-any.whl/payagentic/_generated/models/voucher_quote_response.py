from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="VoucherQuoteResponse")


@_attrs_define
class VoucherQuoteResponse:
    """
    Attributes:
        estimated_pay_amount (str):
        expires_at (datetime.datetime):
        face_currency (str):
        face_value (str):
        fees (list[Any]):
        pay_chain (str):
        pay_currency (str):
        provider (str):
        provider_product_id (str):
        quote_id (UUID):
        warnings (list[str]):
    """

    estimated_pay_amount: str
    expires_at: datetime.datetime
    face_currency: str
    face_value: str
    fees: list[Any]
    pay_chain: str
    pay_currency: str
    provider: str
    provider_product_id: str
    quote_id: UUID
    warnings: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        estimated_pay_amount = self.estimated_pay_amount

        expires_at = self.expires_at.isoformat()

        face_currency = self.face_currency

        face_value = self.face_value

        fees = self.fees

        pay_chain = self.pay_chain

        pay_currency = self.pay_currency

        provider = self.provider

        provider_product_id = self.provider_product_id

        quote_id = str(self.quote_id)

        warnings = self.warnings

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "estimatedPayAmount": estimated_pay_amount,
                "expiresAt": expires_at,
                "faceCurrency": face_currency,
                "faceValue": face_value,
                "fees": fees,
                "payChain": pay_chain,
                "payCurrency": pay_currency,
                "provider": provider,
                "providerProductId": provider_product_id,
                "quoteId": quote_id,
                "warnings": warnings,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        estimated_pay_amount = d.pop("estimatedPayAmount")

        expires_at = isoparse(d.pop("expiresAt"))

        face_currency = d.pop("faceCurrency")

        face_value = d.pop("faceValue")

        fees = cast(list[Any], d.pop("fees"))

        pay_chain = d.pop("payChain")

        pay_currency = d.pop("payCurrency")

        provider = d.pop("provider")

        provider_product_id = d.pop("providerProductId")

        quote_id = UUID(d.pop("quoteId"))

        warnings = cast(list[str], d.pop("warnings"))

        voucher_quote_response = cls(
            estimated_pay_amount=estimated_pay_amount,
            expires_at=expires_at,
            face_currency=face_currency,
            face_value=face_value,
            fees=fees,
            pay_chain=pay_chain,
            pay_currency=pay_currency,
            provider=provider,
            provider_product_id=provider_product_id,
            quote_id=quote_id,
            warnings=warnings,
        )

        voucher_quote_response.additional_properties = d
        return voucher_quote_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
