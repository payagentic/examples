from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CapabilityDataPolicyInput")


@_attrs_define
class CapabilityDataPolicyInput:
    """
    Attributes:
        egress_allowed (bool):
        retention (str):
    """

    egress_allowed: bool
    retention: str

    def to_dict(self) -> dict[str, Any]:
        egress_allowed = self.egress_allowed

        retention = self.retention

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "egressAllowed": egress_allowed,
                "retention": retention,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        egress_allowed = d.pop("egressAllowed")

        retention = d.pop("retention")

        capability_data_policy_input = cls(
            egress_allowed=egress_allowed,
            retention=retention,
        )

        return capability_data_policy_input
