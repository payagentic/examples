from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.agent_chat_ui_block import AgentChatUiBlock


T = TypeVar("T", bound="AgentChatResponse")


@_attrs_define
class AgentChatResponse:
    """
    Attributes:
        content (str):
        runtime_key (str):
        model (None | str | Unset):
        ui (list[AgentChatUiBlock] | Unset):
    """

    content: str
    runtime_key: str
    model: None | str | Unset = UNSET
    ui: list[AgentChatUiBlock] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.agent_chat_ui_block import AgentChatUiBlock

        content = self.content

        runtime_key = self.runtime_key

        model: None | str | Unset
        if isinstance(self.model, Unset):
            model = UNSET
        else:
            model = self.model

        ui: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.ui, Unset):
            ui = []
            for ui_item_data in self.ui:
                ui_item = ui_item_data.to_dict()
                ui.append(ui_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
                "runtimeKey": runtime_key,
            }
        )
        if model is not UNSET:
            field_dict["model"] = model
        if ui is not UNSET:
            field_dict["ui"] = ui

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_chat_ui_block import AgentChatUiBlock

        d = dict(src_dict)
        content = d.pop("content")

        runtime_key = d.pop("runtimeKey")

        def _parse_model(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model = _parse_model(d.pop("model", UNSET))

        _ui = d.pop("ui", UNSET)
        ui: list[AgentChatUiBlock] | Unset = UNSET
        if _ui is not UNSET:
            ui = []
            for ui_item_data in _ui:
                ui_item = AgentChatUiBlock.from_dict(ui_item_data)

                ui.append(ui_item)

        agent_chat_response = cls(
            content=content,
            runtime_key=runtime_key,
            model=model,
            ui=ui,
        )

        agent_chat_response.additional_properties = d
        return agent_chat_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
