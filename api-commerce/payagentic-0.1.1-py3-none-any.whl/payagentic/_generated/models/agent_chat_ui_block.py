from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.agent_chat_ui_action import AgentChatUiAction
    from ..models.agent_chat_ui_field import AgentChatUiField


T = TypeVar("T", bound="AgentChatUiBlock")


@_attrs_define
class AgentChatUiBlock:
    """
    Attributes:
        kind (str):
        summary (str):
        title (str):
        actions (list[AgentChatUiAction] | Unset):
        fields (list[AgentChatUiField] | Unset):
        risk_level (None | str | Unset):
        status (None | str | Unset):
    """

    kind: str
    summary: str
    title: str
    actions: list[AgentChatUiAction] | Unset = UNSET
    fields: list[AgentChatUiField] | Unset = UNSET
    risk_level: None | str | Unset = UNSET
    status: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.agent_chat_ui_action import AgentChatUiAction
        from ..models.agent_chat_ui_field import AgentChatUiField

        kind = self.kind

        summary = self.summary

        title = self.title

        actions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.actions, Unset):
            actions = []
            for actions_item_data in self.actions:
                actions_item = actions_item_data.to_dict()
                actions.append(actions_item)

        fields: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.fields, Unset):
            fields = []
            for fields_item_data in self.fields:
                fields_item = fields_item_data.to_dict()
                fields.append(fields_item)

        risk_level: None | str | Unset
        if isinstance(self.risk_level, Unset):
            risk_level = UNSET
        else:
            risk_level = self.risk_level

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "kind": kind,
                "summary": summary,
                "title": title,
            }
        )
        if actions is not UNSET:
            field_dict["actions"] = actions
        if fields is not UNSET:
            field_dict["fields"] = fields
        if risk_level is not UNSET:
            field_dict["riskLevel"] = risk_level
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_chat_ui_action import AgentChatUiAction
        from ..models.agent_chat_ui_field import AgentChatUiField

        d = dict(src_dict)
        kind = d.pop("kind")

        summary = d.pop("summary")

        title = d.pop("title")

        _actions = d.pop("actions", UNSET)
        actions: list[AgentChatUiAction] | Unset = UNSET
        if _actions is not UNSET:
            actions = []
            for actions_item_data in _actions:
                actions_item = AgentChatUiAction.from_dict(actions_item_data)

                actions.append(actions_item)

        _fields = d.pop("fields", UNSET)
        fields: list[AgentChatUiField] | Unset = UNSET
        if _fields is not UNSET:
            fields = []
            for fields_item_data in _fields:
                fields_item = AgentChatUiField.from_dict(fields_item_data)

                fields.append(fields_item)

        def _parse_risk_level(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        risk_level = _parse_risk_level(d.pop("riskLevel", UNSET))

        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        agent_chat_ui_block = cls(
            kind=kind,
            summary=summary,
            title=title,
            actions=actions,
            fields=fields,
            risk_level=risk_level,
            status=status,
        )

        agent_chat_ui_block.additional_properties = d
        return agent_chat_ui_block

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
