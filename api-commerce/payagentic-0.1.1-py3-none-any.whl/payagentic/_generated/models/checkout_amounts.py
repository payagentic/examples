from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="CheckoutAmounts")


@_attrs_define
class CheckoutAmounts:
    """
    Attributes:
        currency (str):
        subtotal (str):
        total (str):
        discount (None | str | Unset):
        shipping (None | str | Unset):
        tax (None | str | Unset):
    """

    currency: str
    subtotal: str
    total: str
    discount: None | str | Unset = UNSET
    shipping: None | str | Unset = UNSET
    tax: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        currency = self.currency

        subtotal = self.subtotal

        total = self.total

        discount: None | str | Unset
        if isinstance(self.discount, Unset):
            discount = UNSET
        else:
            discount = self.discount

        shipping: None | str | Unset
        if isinstance(self.shipping, Unset):
            shipping = UNSET
        else:
            shipping = self.shipping

        tax: None | str | Unset
        if isinstance(self.tax, Unset):
            tax = UNSET
        else:
            tax = self.tax

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "currency": currency,
                "subtotal": subtotal,
                "total": total,
            }
        )
        if discount is not UNSET:
            field_dict["discount"] = discount
        if shipping is not UNSET:
            field_dict["shipping"] = shipping
        if tax is not UNSET:
            field_dict["tax"] = tax

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        currency = d.pop("currency")

        subtotal = d.pop("subtotal")

        total = d.pop("total")

        def _parse_discount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        discount = _parse_discount(d.pop("discount", UNSET))

        def _parse_shipping(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        shipping = _parse_shipping(d.pop("shipping", UNSET))

        def _parse_tax(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tax = _parse_tax(d.pop("tax", UNSET))

        checkout_amounts = cls(
            currency=currency,
            subtotal=subtotal,
            total=total,
            discount=discount,
            shipping=shipping,
            tax=tax,
        )

        checkout_amounts.additional_properties = d
        return checkout_amounts

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
