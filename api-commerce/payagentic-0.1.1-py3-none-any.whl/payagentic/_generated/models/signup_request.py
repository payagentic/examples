from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="SignupRequest")


@_attrs_define
class SignupRequest:
    """
    Attributes:
        org_name (str): Display name for the new organization (e.g. "Acme AI Labs").
        agent_name (None | str | Unset): Display name for the default agent. Defaults to "default-agent".
        country (None | str | Unset): ISO 3166-1 alpha-2 country code (e.g. "ZA"). When omitted, the gateway
            seeds it from the proxy geo header, falling back to the configured
            `default_jurisdiction`.
        wallet_chain (None | str | Unset): Chain to provision the default wallet on. When omitted, defaults to the
            deployment's configured production wallet rail. Supported values include
            base, ethereum, polygon, arbitrum, solana, and tron.
    """

    org_name: str
    agent_name: None | str | Unset = UNSET
    country: None | str | Unset = UNSET
    wallet_chain: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        org_name = self.org_name

        agent_name: None | str | Unset
        if isinstance(self.agent_name, Unset):
            agent_name = UNSET
        else:
            agent_name = self.agent_name

        country: None | str | Unset
        if isinstance(self.country, Unset):
            country = UNSET
        else:
            country = self.country

        wallet_chain: None | str | Unset
        if isinstance(self.wallet_chain, Unset):
            wallet_chain = UNSET
        else:
            wallet_chain = self.wallet_chain

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "org_name": org_name,
            }
        )
        if agent_name is not UNSET:
            field_dict["agent_name"] = agent_name
        if country is not UNSET:
            field_dict["country"] = country
        if wallet_chain is not UNSET:
            field_dict["wallet_chain"] = wallet_chain

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        org_name = d.pop("org_name")

        def _parse_agent_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_name = _parse_agent_name(d.pop("agent_name", UNSET))

        def _parse_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        country = _parse_country(d.pop("country", UNSET))

        def _parse_wallet_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        wallet_chain = _parse_wallet_chain(d.pop("wallet_chain", UNSET))

        signup_request = cls(
            org_name=org_name,
            agent_name=agent_name,
            country=country,
            wallet_chain=wallet_chain,
        )

        signup_request.additional_properties = d
        return signup_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
