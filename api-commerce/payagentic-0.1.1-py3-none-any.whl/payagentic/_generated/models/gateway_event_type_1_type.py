from enum import Enum


class GatewayEventType1Type(str, Enum):
    PAYMENT_SETTLED = "payment_settled"

    def __str__(self) -> str:
        return str(self.value)
