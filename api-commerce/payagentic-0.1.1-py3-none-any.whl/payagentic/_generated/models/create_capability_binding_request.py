from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="CreateCapabilityBindingRequest")


@_attrs_define
class CreateCapabilityBindingRequest:
    """
    Attributes:
        auto_invoke (bool):
        capability_id (UUID):
        per_call_limit (str):
        purpose (str):
        total_limit (str):
        version (str):
    """

    auto_invoke: bool
    capability_id: UUID
    per_call_limit: str
    purpose: str
    total_limit: str
    version: str

    def to_dict(self) -> dict[str, Any]:
        auto_invoke = self.auto_invoke

        capability_id = str(self.capability_id)

        per_call_limit = self.per_call_limit

        purpose = self.purpose

        total_limit = self.total_limit

        version = self.version

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "autoInvoke": auto_invoke,
                "capabilityId": capability_id,
                "perCallLimit": per_call_limit,
                "purpose": purpose,
                "totalLimit": total_limit,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        auto_invoke = d.pop("autoInvoke")

        capability_id = UUID(d.pop("capabilityId"))

        per_call_limit = d.pop("perCallLimit")

        purpose = d.pop("purpose")

        total_limit = d.pop("totalLimit")

        version = d.pop("version")

        create_capability_binding_request = cls(
            auto_invoke=auto_invoke,
            capability_id=capability_id,
            per_call_limit=per_call_limit,
            purpose=purpose,
            total_limit=total_limit,
            version=version,
        )

        return create_capability_binding_request
