from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="AgentRuntimePreferenceResponse")


@_attrs_define
class AgentRuntimePreferenceResponse:
    """The signed-in user's durable Companion selection. It contains identifiers
    only: provider credentials remain in their separately encrypted settings.

        Attributes:
            model_id (str):
            runtime_key (None | str | Unset):
    """

    model_id: str
    runtime_key: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        model_id = self.model_id

        runtime_key: None | str | Unset
        if isinstance(self.runtime_key, Unset):
            runtime_key = UNSET
        else:
            runtime_key = self.runtime_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "modelId": model_id,
            }
        )
        if runtime_key is not UNSET:
            field_dict["runtimeKey"] = runtime_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        model_id = d.pop("modelId")

        def _parse_runtime_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        runtime_key = _parse_runtime_key(d.pop("runtimeKey", UNSET))

        agent_runtime_preference_response = cls(
            model_id=model_id,
            runtime_key=runtime_key,
        )

        agent_runtime_preference_response.additional_properties = d
        return agent_runtime_preference_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
