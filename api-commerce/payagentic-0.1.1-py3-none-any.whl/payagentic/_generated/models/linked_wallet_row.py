from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="LinkedWalletRow")


@_attrs_define
class LinkedWalletRow:
    """A linked wallet row returned by list / insert queries.

    Attributes:
        address (str):
        created_at (datetime.datetime):
        id (UUID):
        proof_method (str):
        screening_status (str):
        status (str):
        ens_name (None | str | Unset):
        label (None | str | Unset):
    """

    address: str
    created_at: datetime.datetime
    id: UUID
    proof_method: str
    screening_status: str
    status: str
    ens_name: None | str | Unset = UNSET
    label: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        address = self.address

        created_at = self.created_at.isoformat()

        id = str(self.id)

        proof_method = self.proof_method

        screening_status = self.screening_status

        status = self.status

        ens_name: None | str | Unset
        if isinstance(self.ens_name, Unset):
            ens_name = UNSET
        else:
            ens_name = self.ens_name

        label: None | str | Unset
        if isinstance(self.label, Unset):
            label = UNSET
        else:
            label = self.label

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "address": address,
                "created_at": created_at,
                "id": id,
                "proof_method": proof_method,
                "screening_status": screening_status,
                "status": status,
            }
        )
        if ens_name is not UNSET:
            field_dict["ens_name"] = ens_name
        if label is not UNSET:
            field_dict["label"] = label

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address = d.pop("address")

        created_at = isoparse(d.pop("created_at"))

        id = UUID(d.pop("id"))

        proof_method = d.pop("proof_method")

        screening_status = d.pop("screening_status")

        status = d.pop("status")

        def _parse_ens_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ens_name = _parse_ens_name(d.pop("ens_name", UNSET))

        def _parse_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label = _parse_label(d.pop("label", UNSET))

        linked_wallet_row = cls(
            address=address,
            created_at=created_at,
            id=id,
            proof_method=proof_method,
            screening_status=screening_status,
            status=status,
            ens_name=ens_name,
            label=label,
        )

        linked_wallet_row.additional_properties = d
        return linked_wallet_row

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
