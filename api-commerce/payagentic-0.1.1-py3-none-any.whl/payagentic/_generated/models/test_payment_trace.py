from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="TestPaymentTrace")


@_attrs_define
class TestPaymentTrace:
    """
    Attributes:
        decision (str):
        endpoint_id (UUID):
        endpoint_method (str):
        endpoint_url (str):
        notes (list[str]):
        price_amount (str):
        price_currency (str):
        synthetic_credential (str):
        timestamp (datetime.datetime):
    """

    decision: str
    endpoint_id: UUID
    endpoint_method: str
    endpoint_url: str
    notes: list[str]
    price_amount: str
    price_currency: str
    synthetic_credential: str
    timestamp: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        decision = self.decision

        endpoint_id = str(self.endpoint_id)

        endpoint_method = self.endpoint_method

        endpoint_url = self.endpoint_url

        notes = self.notes

        price_amount = self.price_amount

        price_currency = self.price_currency

        synthetic_credential = self.synthetic_credential

        timestamp = self.timestamp.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "decision": decision,
                "endpoint_id": endpoint_id,
                "endpoint_method": endpoint_method,
                "endpoint_url": endpoint_url,
                "notes": notes,
                "price_amount": price_amount,
                "price_currency": price_currency,
                "synthetic_credential": synthetic_credential,
                "timestamp": timestamp,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        decision = d.pop("decision")

        endpoint_id = UUID(d.pop("endpoint_id"))

        endpoint_method = d.pop("endpoint_method")

        endpoint_url = d.pop("endpoint_url")

        notes = cast(list[str], d.pop("notes"))

        price_amount = d.pop("price_amount")

        price_currency = d.pop("price_currency")

        synthetic_credential = d.pop("synthetic_credential")

        timestamp = isoparse(d.pop("timestamp"))

        test_payment_trace = cls(
            decision=decision,
            endpoint_id=endpoint_id,
            endpoint_method=endpoint_method,
            endpoint_url=endpoint_url,
            notes=notes,
            price_amount=price_amount,
            price_currency=price_currency,
            synthetic_credential=synthetic_credential,
            timestamp=timestamp,
        )

        test_payment_trace.additional_properties = d
        return test_payment_trace

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
