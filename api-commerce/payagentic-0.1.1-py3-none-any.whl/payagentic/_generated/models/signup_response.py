from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="SignupResponse")


@_attrs_define
class SignupResponse:
    """
    Attributes:
        agent_id (UUID):
        api_key (str): The API key — shown ONCE, never again. Send as
            `Authorization: Bearer <api_key>`.
        api_key_prefix (str):
        next_steps (str): Human-readable note about what to do next.
        org_id (UUID):
        wallet_address (str): On-chain address derived from the wallet's signing key. Fund this
            address with the supported stablecoin for the selected network before
            making payments; some networks also require native gas.
        wallet_id (UUID):
    """

    agent_id: UUID
    api_key: str
    api_key_prefix: str
    next_steps: str
    org_id: UUID
    wallet_address: str
    wallet_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_id = str(self.agent_id)

        api_key = self.api_key

        api_key_prefix = self.api_key_prefix

        next_steps = self.next_steps

        org_id = str(self.org_id)

        wallet_address = self.wallet_address

        wallet_id = str(self.wallet_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_id": agent_id,
                "api_key": api_key,
                "api_key_prefix": api_key_prefix,
                "next_steps": next_steps,
                "org_id": org_id,
                "wallet_address": wallet_address,
                "wallet_id": wallet_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_id = UUID(d.pop("agent_id"))

        api_key = d.pop("api_key")

        api_key_prefix = d.pop("api_key_prefix")

        next_steps = d.pop("next_steps")

        org_id = UUID(d.pop("org_id"))

        wallet_address = d.pop("wallet_address")

        wallet_id = UUID(d.pop("wallet_id"))

        signup_response = cls(
            agent_id=agent_id,
            api_key=api_key,
            api_key_prefix=api_key_prefix,
            next_steps=next_steps,
            org_id=org_id,
            wallet_address=wallet_address,
            wallet_id=wallet_id,
        )

        signup_response.additional_properties = d
        return signup_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
