from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="DraftChecksums")


@_attrs_define
class DraftChecksums:
    """
    Attributes:
        implementation (str):
        input_schema (str):
        manifest (str):
        output_schema (str):
    """

    implementation: str
    input_schema: str
    manifest: str
    output_schema: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        implementation = self.implementation

        input_schema = self.input_schema

        manifest = self.manifest

        output_schema = self.output_schema

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "implementation": implementation,
                "inputSchema": input_schema,
                "manifest": manifest,
                "outputSchema": output_schema,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        implementation = d.pop("implementation")

        input_schema = d.pop("inputSchema")

        manifest = d.pop("manifest")

        output_schema = d.pop("outputSchema")

        draft_checksums = cls(
            implementation=implementation,
            input_schema=input_schema,
            manifest=manifest,
            output_schema=output_schema,
        )

        draft_checksums.additional_properties = d
        return draft_checksums

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
