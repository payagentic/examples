from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="CapabilityReceiptResponse")


@_attrs_define
class CapabilityReceiptResponse:
    """
    Attributes:
        capability_id (UUID):
        capability_version_id (UUID):
        contract (Any):
        created_at (datetime.datetime):
        evidence (Any):
        id (UUID):
        invocation_id (UUID):
        receipt_version (str):
        settlement (Any):
        status (str):
        transport (str):
    """

    capability_id: UUID
    capability_version_id: UUID
    contract: Any
    created_at: datetime.datetime
    evidence: Any
    id: UUID
    invocation_id: UUID
    receipt_version: str
    settlement: Any
    status: str
    transport: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        capability_id = str(self.capability_id)

        capability_version_id = str(self.capability_version_id)

        contract = self.contract

        created_at = self.created_at.isoformat()

        evidence = self.evidence

        id = str(self.id)

        invocation_id = str(self.invocation_id)

        receipt_version = self.receipt_version

        settlement = self.settlement

        status = self.status

        transport = self.transport

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "capabilityId": capability_id,
                "capabilityVersionId": capability_version_id,
                "contract": contract,
                "createdAt": created_at,
                "evidence": evidence,
                "id": id,
                "invocationId": invocation_id,
                "receiptVersion": receipt_version,
                "settlement": settlement,
                "status": status,
                "transport": transport,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        capability_id = UUID(d.pop("capabilityId"))

        capability_version_id = UUID(d.pop("capabilityVersionId"))

        contract = d.pop("contract")

        created_at = isoparse(d.pop("createdAt"))

        evidence = d.pop("evidence")

        id = UUID(d.pop("id"))

        invocation_id = UUID(d.pop("invocationId"))

        receipt_version = d.pop("receiptVersion")

        settlement = d.pop("settlement")

        status = d.pop("status")

        transport = d.pop("transport")

        capability_receipt_response = cls(
            capability_id=capability_id,
            capability_version_id=capability_version_id,
            contract=contract,
            created_at=created_at,
            evidence=evidence,
            id=id,
            invocation_id=invocation_id,
            receipt_version=receipt_version,
            settlement=settlement,
            status=status,
            transport=transport,
        )

        capability_receipt_response.additional_properties = d
        return capability_receipt_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
