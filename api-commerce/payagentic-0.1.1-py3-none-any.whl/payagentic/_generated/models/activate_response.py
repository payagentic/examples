from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="ActivateResponse")


@_attrs_define
class ActivateResponse:
    """
    Attributes:
        api_key (str): Shown ONCE. Send as `Authorization: Bearer <api_key>` on subsequent
            merchant API calls.
        api_key_prefix (str):
        merchant_id (UUID):
        merchant_profile_id (UUID):
        next_steps (str):
        org_id (UUID):
        payout_wallet_id (UUID):
    """

    api_key: str
    api_key_prefix: str
    merchant_id: UUID
    merchant_profile_id: UUID
    next_steps: str
    org_id: UUID
    payout_wallet_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        api_key = self.api_key

        api_key_prefix = self.api_key_prefix

        merchant_id = str(self.merchant_id)

        merchant_profile_id = str(self.merchant_profile_id)

        next_steps = self.next_steps

        org_id = str(self.org_id)

        payout_wallet_id = str(self.payout_wallet_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "api_key": api_key,
                "api_key_prefix": api_key_prefix,
                "merchant_id": merchant_id,
                "merchant_profile_id": merchant_profile_id,
                "next_steps": next_steps,
                "org_id": org_id,
                "payout_wallet_id": payout_wallet_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api_key = d.pop("api_key")

        api_key_prefix = d.pop("api_key_prefix")

        merchant_id = UUID(d.pop("merchant_id"))

        merchant_profile_id = UUID(d.pop("merchant_profile_id"))

        next_steps = d.pop("next_steps")

        org_id = UUID(d.pop("org_id"))

        payout_wallet_id = UUID(d.pop("payout_wallet_id"))

        activate_response = cls(
            api_key=api_key,
            api_key_prefix=api_key_prefix,
            merchant_id=merchant_id,
            merchant_profile_id=merchant_profile_id,
            next_steps=next_steps,
            org_id=org_id,
            payout_wallet_id=payout_wallet_id,
        )

        activate_response.additional_properties = d
        return activate_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
