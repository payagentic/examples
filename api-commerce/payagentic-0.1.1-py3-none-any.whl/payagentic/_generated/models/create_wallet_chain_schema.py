from enum import Enum


class CreateWalletChainSchema(str, Enum):
    ARBITRUM = "arbitrum"
    BASE = "base"
    ETHEREUM = "ethereum"
    POLYGON = "polygon"
    SOLANA = "solana"
    TRON = "tron"

    def __str__(self) -> str:
        return str(self.value)
