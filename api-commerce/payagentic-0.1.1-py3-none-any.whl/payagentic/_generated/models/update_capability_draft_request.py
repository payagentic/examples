from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.capability_data_policy_input import CapabilityDataPolicyInput
    from ..models.capability_limits_input import CapabilityLimitsInput
    from ..models.capability_price_input import CapabilityPriceInput
    from ..models.capability_transport_input import CapabilityTransportInput
    from ..models.structured_example_dto import StructuredExampleDto
    from ..models.update_capability_draft_request_input_schema_type_0 import (
        UpdateCapabilityDraftRequestInputSchemaType0,
    )
    from ..models.update_capability_draft_request_output_schema_type_0 import (
        UpdateCapabilityDraftRequestOutputSchemaType0,
    )


T = TypeVar("T", bound="UpdateCapabilityDraftRequest")


@_attrs_define
class UpdateCapabilityDraftRequest:
    """
    Attributes:
        categories (list[str] | None | Unset):
        data_policy (CapabilityDataPolicyInput | None | Unset):
        description (None | str | Unset):
        egress_json_pointers (list[str] | None | Unset):
        examples (list[StructuredExampleDto] | None | Unset):
        input_schema (None | Unset | UpdateCapabilityDraftRequestInputSchemaType0):
        limits (CapabilityLimitsInput | None | Unset):
        name (None | str | Unset):
        output_schema (None | Unset | UpdateCapabilityDraftRequestOutputSchemaType0):
        price (CapabilityPriceInput | None | Unset):
        private_knowledge (None | str | Unset):
        provider_instructions (None | str | Unset):
        slug (None | str | Unset):
        tags (list[str] | None | Unset):
        transports (CapabilityTransportInput | None | Unset):
    """

    categories: list[str] | None | Unset = UNSET
    data_policy: CapabilityDataPolicyInput | None | Unset = UNSET
    description: None | str | Unset = UNSET
    egress_json_pointers: list[str] | None | Unset = UNSET
    examples: list[StructuredExampleDto] | None | Unset = UNSET
    input_schema: None | Unset | UpdateCapabilityDraftRequestInputSchemaType0 = UNSET
    limits: CapabilityLimitsInput | None | Unset = UNSET
    name: None | str | Unset = UNSET
    output_schema: None | Unset | UpdateCapabilityDraftRequestOutputSchemaType0 = UNSET
    price: CapabilityPriceInput | None | Unset = UNSET
    private_knowledge: None | str | Unset = UNSET
    provider_instructions: None | str | Unset = UNSET
    slug: None | str | Unset = UNSET
    tags: list[str] | None | Unset = UNSET
    transports: CapabilityTransportInput | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_data_policy_input import CapabilityDataPolicyInput
        from ..models.capability_limits_input import CapabilityLimitsInput
        from ..models.capability_price_input import CapabilityPriceInput
        from ..models.capability_transport_input import CapabilityTransportInput
        from ..models.structured_example_dto import StructuredExampleDto
        from ..models.update_capability_draft_request_input_schema_type_0 import (
            UpdateCapabilityDraftRequestInputSchemaType0,
        )
        from ..models.update_capability_draft_request_output_schema_type_0 import (
            UpdateCapabilityDraftRequestOutputSchemaType0,
        )

        categories: list[str] | None | Unset
        if isinstance(self.categories, Unset):
            categories = UNSET
        elif isinstance(self.categories, list):
            categories = self.categories

        else:
            categories = self.categories

        data_policy: dict[str, Any] | None | Unset
        if isinstance(self.data_policy, Unset):
            data_policy = UNSET
        elif isinstance(self.data_policy, CapabilityDataPolicyInput):
            data_policy = self.data_policy.to_dict()
        else:
            data_policy = self.data_policy

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        egress_json_pointers: list[str] | None | Unset
        if isinstance(self.egress_json_pointers, Unset):
            egress_json_pointers = UNSET
        elif isinstance(self.egress_json_pointers, list):
            egress_json_pointers = self.egress_json_pointers

        else:
            egress_json_pointers = self.egress_json_pointers

        examples: list[dict[str, Any]] | None | Unset
        if isinstance(self.examples, Unset):
            examples = UNSET
        elif isinstance(self.examples, list):
            examples = []
            for examples_type_0_item_data in self.examples:
                examples_type_0_item = examples_type_0_item_data.to_dict()
                examples.append(examples_type_0_item)

        else:
            examples = self.examples

        input_schema: dict[str, Any] | None | Unset
        if isinstance(self.input_schema, Unset):
            input_schema = UNSET
        elif isinstance(self.input_schema, UpdateCapabilityDraftRequestInputSchemaType0):
            input_schema = self.input_schema.to_dict()
        else:
            input_schema = self.input_schema

        limits: dict[str, Any] | None | Unset
        if isinstance(self.limits, Unset):
            limits = UNSET
        elif isinstance(self.limits, CapabilityLimitsInput):
            limits = self.limits.to_dict()
        else:
            limits = self.limits

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        output_schema: dict[str, Any] | None | Unset
        if isinstance(self.output_schema, Unset):
            output_schema = UNSET
        elif isinstance(self.output_schema, UpdateCapabilityDraftRequestOutputSchemaType0):
            output_schema = self.output_schema.to_dict()
        else:
            output_schema = self.output_schema

        price: dict[str, Any] | None | Unset
        if isinstance(self.price, Unset):
            price = UNSET
        elif isinstance(self.price, CapabilityPriceInput):
            price = self.price.to_dict()
        else:
            price = self.price

        private_knowledge: None | str | Unset
        if isinstance(self.private_knowledge, Unset):
            private_knowledge = UNSET
        else:
            private_knowledge = self.private_knowledge

        provider_instructions: None | str | Unset
        if isinstance(self.provider_instructions, Unset):
            provider_instructions = UNSET
        else:
            provider_instructions = self.provider_instructions

        slug: None | str | Unset
        if isinstance(self.slug, Unset):
            slug = UNSET
        else:
            slug = self.slug

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags

        else:
            tags = self.tags

        transports: dict[str, Any] | None | Unset
        if isinstance(self.transports, Unset):
            transports = UNSET
        elif isinstance(self.transports, CapabilityTransportInput):
            transports = self.transports.to_dict()
        else:
            transports = self.transports

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if categories is not UNSET:
            field_dict["categories"] = categories
        if data_policy is not UNSET:
            field_dict["dataPolicy"] = data_policy
        if description is not UNSET:
            field_dict["description"] = description
        if egress_json_pointers is not UNSET:
            field_dict["egressJsonPointers"] = egress_json_pointers
        if examples is not UNSET:
            field_dict["examples"] = examples
        if input_schema is not UNSET:
            field_dict["inputSchema"] = input_schema
        if limits is not UNSET:
            field_dict["limits"] = limits
        if name is not UNSET:
            field_dict["name"] = name
        if output_schema is not UNSET:
            field_dict["outputSchema"] = output_schema
        if price is not UNSET:
            field_dict["price"] = price
        if private_knowledge is not UNSET:
            field_dict["privateKnowledge"] = private_knowledge
        if provider_instructions is not UNSET:
            field_dict["providerInstructions"] = provider_instructions
        if slug is not UNSET:
            field_dict["slug"] = slug
        if tags is not UNSET:
            field_dict["tags"] = tags
        if transports is not UNSET:
            field_dict["transports"] = transports

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_data_policy_input import CapabilityDataPolicyInput
        from ..models.capability_limits_input import CapabilityLimitsInput
        from ..models.capability_price_input import CapabilityPriceInput
        from ..models.capability_transport_input import CapabilityTransportInput
        from ..models.structured_example_dto import StructuredExampleDto
        from ..models.update_capability_draft_request_input_schema_type_0 import (
            UpdateCapabilityDraftRequestInputSchemaType0,
        )
        from ..models.update_capability_draft_request_output_schema_type_0 import (
            UpdateCapabilityDraftRequestOutputSchemaType0,
        )

        d = dict(src_dict)

        def _parse_categories(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                categories_type_0 = cast(list[str], data)

                return categories_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        categories = _parse_categories(d.pop("categories", UNSET))

        def _parse_data_policy(data: object) -> CapabilityDataPolicyInput | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_policy_type_1 = CapabilityDataPolicyInput.from_dict(data)

                return data_policy_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CapabilityDataPolicyInput | None | Unset, data)

        data_policy = _parse_data_policy(d.pop("dataPolicy", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_egress_json_pointers(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                egress_json_pointers_type_0 = cast(list[str], data)

                return egress_json_pointers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        egress_json_pointers = _parse_egress_json_pointers(d.pop("egressJsonPointers", UNSET))

        def _parse_examples(data: object) -> list[StructuredExampleDto] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                examples_type_0 = []
                _examples_type_0 = data
                for examples_type_0_item_data in _examples_type_0:
                    examples_type_0_item = StructuredExampleDto.from_dict(examples_type_0_item_data)

                    examples_type_0.append(examples_type_0_item)

                return examples_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[StructuredExampleDto] | None | Unset, data)

        examples = _parse_examples(d.pop("examples", UNSET))

        def _parse_input_schema(
            data: object,
        ) -> None | Unset | UpdateCapabilityDraftRequestInputSchemaType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_schema_type_0 = UpdateCapabilityDraftRequestInputSchemaType0.from_dict(data)

                return input_schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateCapabilityDraftRequestInputSchemaType0, data)

        input_schema = _parse_input_schema(d.pop("inputSchema", UNSET))

        def _parse_limits(data: object) -> CapabilityLimitsInput | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                limits_type_1 = CapabilityLimitsInput.from_dict(data)

                return limits_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CapabilityLimitsInput | None | Unset, data)

        limits = _parse_limits(d.pop("limits", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_output_schema(
            data: object,
        ) -> None | Unset | UpdateCapabilityDraftRequestOutputSchemaType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_schema_type_0 = UpdateCapabilityDraftRequestOutputSchemaType0.from_dict(data)

                return output_schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateCapabilityDraftRequestOutputSchemaType0, data)

        output_schema = _parse_output_schema(d.pop("outputSchema", UNSET))

        def _parse_price(data: object) -> CapabilityPriceInput | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                price_type_1 = CapabilityPriceInput.from_dict(data)

                return price_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CapabilityPriceInput | None | Unset, data)

        price = _parse_price(d.pop("price", UNSET))

        def _parse_private_knowledge(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        private_knowledge = _parse_private_knowledge(d.pop("privateKnowledge", UNSET))

        def _parse_provider_instructions(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider_instructions = _parse_provider_instructions(d.pop("providerInstructions", UNSET))

        def _parse_slug(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        slug = _parse_slug(d.pop("slug", UNSET))

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))

        def _parse_transports(data: object) -> CapabilityTransportInput | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                transports_type_1 = CapabilityTransportInput.from_dict(data)

                return transports_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CapabilityTransportInput | None | Unset, data)

        transports = _parse_transports(d.pop("transports", UNSET))

        update_capability_draft_request = cls(
            categories=categories,
            data_policy=data_policy,
            description=description,
            egress_json_pointers=egress_json_pointers,
            examples=examples,
            input_schema=input_schema,
            limits=limits,
            name=name,
            output_schema=output_schema,
            price=price,
            private_knowledge=private_knowledge,
            provider_instructions=provider_instructions,
            slug=slug,
            tags=tags,
            transports=transports,
        )

        return update_capability_draft_request
