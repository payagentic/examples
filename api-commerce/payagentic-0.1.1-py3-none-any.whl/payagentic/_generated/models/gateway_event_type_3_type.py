from enum import Enum


class GatewayEventType3Type(str, Enum):
    TRANSFER_STATE_CHANGED = "transfer_state_changed"

    def __str__(self) -> str:
        return str(self.value)
