from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CapabilityLimitsInput")


@_attrs_define
class CapabilityLimitsInput:
    """
    Attributes:
        max_output_bytes (int):
        timeout_ms (int):
    """

    max_output_bytes: int
    timeout_ms: int

    def to_dict(self) -> dict[str, Any]:
        max_output_bytes = self.max_output_bytes

        timeout_ms = self.timeout_ms

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "maxOutputBytes": max_output_bytes,
                "timeoutMs": timeout_ms,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        max_output_bytes = d.pop("maxOutputBytes")

        timeout_ms = d.pop("timeoutMs")

        capability_limits_input = cls(
            max_output_bytes=max_output_bytes,
            timeout_ms=timeout_ms,
        )

        return capability_limits_input
