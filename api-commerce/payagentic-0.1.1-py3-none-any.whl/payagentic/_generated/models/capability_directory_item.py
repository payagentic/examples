from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.capability_directory_item_data_policy import CapabilityDirectoryItemDataPolicy
    from ..models.capability_directory_item_examples_item import CapabilityDirectoryItemExamplesItem
    from ..models.capability_directory_item_input_schema import CapabilityDirectoryItemInputSchema
    from ..models.capability_directory_item_output_schema import CapabilityDirectoryItemOutputSchema
    from ..models.capability_directory_item_transports import CapabilityDirectoryItemTransports
    from ..models.capability_directory_provider import CapabilityDirectoryProvider
    from ..models.capability_price_response import CapabilityPriceResponse
    from ..models.observed_metrics import ObservedMetrics
    from ..models.ranking_evidence import RankingEvidence


T = TypeVar("T", bound="CapabilityDirectoryItem")


@_attrs_define
class CapabilityDirectoryItem:
    """
    Attributes:
        categories (list[str]):
        data_policy (CapabilityDirectoryItemDataPolicy):
        description (str):
        examples (list[CapabilityDirectoryItemExamplesItem]):
        id (UUID):
        input_schema (CapabilityDirectoryItemInputSchema):
        lifecycle (str):
        manifest_checksum (str):
        name (str):
        observed_metrics (ObservedMetrics):
        output_schema (CapabilityDirectoryItemOutputSchema):
        price (CapabilityPriceResponse):
        provider (CapabilityDirectoryProvider):
        published_at (datetime.datetime):
        ranking (RankingEvidence):
        slug (str):
        tags (list[str]):
        transports (CapabilityDirectoryItemTransports):
        version (str):
        version_id (UUID):
        deprecation_notice (None | str | Unset):
    """

    categories: list[str]
    data_policy: CapabilityDirectoryItemDataPolicy
    description: str
    examples: list[CapabilityDirectoryItemExamplesItem]
    id: UUID
    input_schema: CapabilityDirectoryItemInputSchema
    lifecycle: str
    manifest_checksum: str
    name: str
    observed_metrics: ObservedMetrics
    output_schema: CapabilityDirectoryItemOutputSchema
    price: CapabilityPriceResponse
    provider: CapabilityDirectoryProvider
    published_at: datetime.datetime
    ranking: RankingEvidence
    slug: str
    tags: list[str]
    transports: CapabilityDirectoryItemTransports
    version: str
    version_id: UUID
    deprecation_notice: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_directory_item_data_policy import CapabilityDirectoryItemDataPolicy
        from ..models.capability_directory_item_examples_item import (
            CapabilityDirectoryItemExamplesItem,
        )
        from ..models.capability_directory_item_input_schema import (
            CapabilityDirectoryItemInputSchema,
        )
        from ..models.capability_directory_item_output_schema import (
            CapabilityDirectoryItemOutputSchema,
        )
        from ..models.capability_directory_item_transports import CapabilityDirectoryItemTransports
        from ..models.capability_directory_provider import CapabilityDirectoryProvider
        from ..models.capability_price_response import CapabilityPriceResponse
        from ..models.observed_metrics import ObservedMetrics
        from ..models.ranking_evidence import RankingEvidence

        categories = self.categories

        data_policy = self.data_policy.to_dict()

        description = self.description

        examples = []
        for examples_item_data in self.examples:
            examples_item = examples_item_data.to_dict()
            examples.append(examples_item)

        id = str(self.id)

        input_schema = self.input_schema.to_dict()

        lifecycle = self.lifecycle

        manifest_checksum = self.manifest_checksum

        name = self.name

        observed_metrics = self.observed_metrics.to_dict()

        output_schema = self.output_schema.to_dict()

        price = self.price.to_dict()

        provider = self.provider.to_dict()

        published_at = self.published_at.isoformat()

        ranking = self.ranking.to_dict()

        slug = self.slug

        tags = self.tags

        transports = self.transports.to_dict()

        version = self.version

        version_id = str(self.version_id)

        deprecation_notice: None | str | Unset
        if isinstance(self.deprecation_notice, Unset):
            deprecation_notice = UNSET
        else:
            deprecation_notice = self.deprecation_notice

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "categories": categories,
                "dataPolicy": data_policy,
                "description": description,
                "examples": examples,
                "id": id,
                "inputSchema": input_schema,
                "lifecycle": lifecycle,
                "manifestChecksum": manifest_checksum,
                "name": name,
                "observedMetrics": observed_metrics,
                "outputSchema": output_schema,
                "price": price,
                "provider": provider,
                "publishedAt": published_at,
                "ranking": ranking,
                "slug": slug,
                "tags": tags,
                "transports": transports,
                "version": version,
                "versionId": version_id,
            }
        )
        if deprecation_notice is not UNSET:
            field_dict["deprecationNotice"] = deprecation_notice

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_directory_item_data_policy import CapabilityDirectoryItemDataPolicy
        from ..models.capability_directory_item_examples_item import (
            CapabilityDirectoryItemExamplesItem,
        )
        from ..models.capability_directory_item_input_schema import (
            CapabilityDirectoryItemInputSchema,
        )
        from ..models.capability_directory_item_output_schema import (
            CapabilityDirectoryItemOutputSchema,
        )
        from ..models.capability_directory_item_transports import CapabilityDirectoryItemTransports
        from ..models.capability_directory_provider import CapabilityDirectoryProvider
        from ..models.capability_price_response import CapabilityPriceResponse
        from ..models.observed_metrics import ObservedMetrics
        from ..models.ranking_evidence import RankingEvidence

        d = dict(src_dict)
        categories = cast(list[str], d.pop("categories"))

        data_policy = CapabilityDirectoryItemDataPolicy.from_dict(d.pop("dataPolicy"))

        description = d.pop("description")

        examples = []
        _examples = d.pop("examples")
        for examples_item_data in _examples:
            examples_item = CapabilityDirectoryItemExamplesItem.from_dict(examples_item_data)

            examples.append(examples_item)

        id = UUID(d.pop("id"))

        input_schema = CapabilityDirectoryItemInputSchema.from_dict(d.pop("inputSchema"))

        lifecycle = d.pop("lifecycle")

        manifest_checksum = d.pop("manifestChecksum")

        name = d.pop("name")

        observed_metrics = ObservedMetrics.from_dict(d.pop("observedMetrics"))

        output_schema = CapabilityDirectoryItemOutputSchema.from_dict(d.pop("outputSchema"))

        price = CapabilityPriceResponse.from_dict(d.pop("price"))

        provider = CapabilityDirectoryProvider.from_dict(d.pop("provider"))

        published_at = isoparse(d.pop("publishedAt"))

        ranking = RankingEvidence.from_dict(d.pop("ranking"))

        slug = d.pop("slug")

        tags = cast(list[str], d.pop("tags"))

        transports = CapabilityDirectoryItemTransports.from_dict(d.pop("transports"))

        version = d.pop("version")

        version_id = UUID(d.pop("versionId"))

        def _parse_deprecation_notice(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        deprecation_notice = _parse_deprecation_notice(d.pop("deprecationNotice", UNSET))

        capability_directory_item = cls(
            categories=categories,
            data_policy=data_policy,
            description=description,
            examples=examples,
            id=id,
            input_schema=input_schema,
            lifecycle=lifecycle,
            manifest_checksum=manifest_checksum,
            name=name,
            observed_metrics=observed_metrics,
            output_schema=output_schema,
            price=price,
            provider=provider,
            published_at=published_at,
            ranking=ranking,
            slug=slug,
            tags=tags,
            transports=transports,
            version=version,
            version_id=version_id,
            deprecation_notice=deprecation_notice,
        )

        capability_directory_item.additional_properties = d
        return capability_directory_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
