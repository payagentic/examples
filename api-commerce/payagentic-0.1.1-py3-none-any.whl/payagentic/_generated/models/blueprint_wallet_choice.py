from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="BlueprintWalletChoice")


@_attrs_define
class BlueprintWalletChoice:
    """
    Attributes:
        mode (str):
        chain (None | str | Unset):
        existing_wallet_id (None | Unset | UUID):
    """

    mode: str
    chain: None | str | Unset = UNSET
    existing_wallet_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        mode = self.mode

        chain: None | str | Unset
        if isinstance(self.chain, Unset):
            chain = UNSET
        else:
            chain = self.chain

        existing_wallet_id: None | str | Unset
        if isinstance(self.existing_wallet_id, Unset):
            existing_wallet_id = UNSET
        elif isinstance(self.existing_wallet_id, UUID):
            existing_wallet_id = str(self.existing_wallet_id)
        else:
            existing_wallet_id = self.existing_wallet_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "mode": mode,
            }
        )
        if chain is not UNSET:
            field_dict["chain"] = chain
        if existing_wallet_id is not UNSET:
            field_dict["existingWalletId"] = existing_wallet_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        mode = d.pop("mode")

        def _parse_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chain = _parse_chain(d.pop("chain", UNSET))

        def _parse_existing_wallet_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                existing_wallet_id_type_0 = UUID(data)

                return existing_wallet_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        existing_wallet_id = _parse_existing_wallet_id(d.pop("existingWalletId", UNSET))

        blueprint_wallet_choice = cls(
            mode=mode,
            chain=chain,
            existing_wallet_id=existing_wallet_id,
        )

        blueprint_wallet_choice.additional_properties = d
        return blueprint_wallet_choice

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
