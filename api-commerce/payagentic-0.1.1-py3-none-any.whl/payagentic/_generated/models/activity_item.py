from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="ActivityItem")


@_attrs_define
class ActivityItem:
    """
    Attributes:
        created_at (datetime.datetime):
        description (str):
        direction (str):
        id (UUID):
        status (str):
        type_ (str):
        agent_name (None | str | Unset):
        amount (None | str | Unset):
        chain (None | str | Unset):
        counterparty (None | str | Unset):
        counterparty_name (None | str | Unset):
        resource_label (None | str | Unset):
        resource_url (None | str | Unset):
        tx_hash (None | str | Unset):
    """

    created_at: datetime.datetime
    description: str
    direction: str
    id: UUID
    status: str
    type_: str
    agent_name: None | str | Unset = UNSET
    amount: None | str | Unset = UNSET
    chain: None | str | Unset = UNSET
    counterparty: None | str | Unset = UNSET
    counterparty_name: None | str | Unset = UNSET
    resource_label: None | str | Unset = UNSET
    resource_url: None | str | Unset = UNSET
    tx_hash: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        created_at = self.created_at.isoformat()

        description = self.description

        direction = self.direction

        id = str(self.id)

        status = self.status

        type_ = self.type_

        agent_name: None | str | Unset
        if isinstance(self.agent_name, Unset):
            agent_name = UNSET
        else:
            agent_name = self.agent_name

        amount: None | str | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        chain: None | str | Unset
        if isinstance(self.chain, Unset):
            chain = UNSET
        else:
            chain = self.chain

        counterparty: None | str | Unset
        if isinstance(self.counterparty, Unset):
            counterparty = UNSET
        else:
            counterparty = self.counterparty

        counterparty_name: None | str | Unset
        if isinstance(self.counterparty_name, Unset):
            counterparty_name = UNSET
        else:
            counterparty_name = self.counterparty_name

        resource_label: None | str | Unset
        if isinstance(self.resource_label, Unset):
            resource_label = UNSET
        else:
            resource_label = self.resource_label

        resource_url: None | str | Unset
        if isinstance(self.resource_url, Unset):
            resource_url = UNSET
        else:
            resource_url = self.resource_url

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "createdAt": created_at,
                "description": description,
                "direction": direction,
                "id": id,
                "status": status,
                "type": type_,
            }
        )
        if agent_name is not UNSET:
            field_dict["agentName"] = agent_name
        if amount is not UNSET:
            field_dict["amount"] = amount
        if chain is not UNSET:
            field_dict["chain"] = chain
        if counterparty is not UNSET:
            field_dict["counterparty"] = counterparty
        if counterparty_name is not UNSET:
            field_dict["counterpartyName"] = counterparty_name
        if resource_label is not UNSET:
            field_dict["resourceLabel"] = resource_label
        if resource_url is not UNSET:
            field_dict["resourceUrl"] = resource_url
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        created_at = isoparse(d.pop("createdAt"))

        description = d.pop("description")

        direction = d.pop("direction")

        id = UUID(d.pop("id"))

        status = d.pop("status")

        type_ = d.pop("type")

        def _parse_agent_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_name = _parse_agent_name(d.pop("agentName", UNSET))

        def _parse_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))

        def _parse_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chain = _parse_chain(d.pop("chain", UNSET))

        def _parse_counterparty(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        counterparty = _parse_counterparty(d.pop("counterparty", UNSET))

        def _parse_counterparty_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        counterparty_name = _parse_counterparty_name(d.pop("counterpartyName", UNSET))

        def _parse_resource_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resource_label = _parse_resource_label(d.pop("resourceLabel", UNSET))

        def _parse_resource_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        resource_url = _parse_resource_url(d.pop("resourceUrl", UNSET))

        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("txHash", UNSET))

        activity_item = cls(
            created_at=created_at,
            description=description,
            direction=direction,
            id=id,
            status=status,
            type_=type_,
            agent_name=agent_name,
            amount=amount,
            chain=chain,
            counterparty=counterparty,
            counterparty_name=counterparty_name,
            resource_label=resource_label,
            resource_url=resource_url,
            tx_hash=tx_hash,
        )

        activity_item.additional_properties = d
        return activity_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
