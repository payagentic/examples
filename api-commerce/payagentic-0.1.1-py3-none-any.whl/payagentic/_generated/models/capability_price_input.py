from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CapabilityPriceInput")


@_attrs_define
class CapabilityPriceInput:
    """
    Attributes:
        amount (str):
        currency (str):
        mode (str):
    """

    amount: str
    currency: str
    mode: str

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        currency = self.currency

        mode = self.mode

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "amount": amount,
                "currency": currency,
                "mode": mode,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        currency = d.pop("currency")

        mode = d.pop("mode")

        capability_price_input = cls(
            amount=amount,
            currency=currency,
            mode=mode,
        )

        return capability_price_input
