from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.wallet_deposit_item import WalletDepositItem


T = TypeVar("T", bound="RefreshWalletDepositsResponse")


@_attrs_define
class RefreshWalletDepositsResponse:
    """
    Attributes:
        credited_count (int):
        scanned_from_block (int):
        scanned_to_block (int):
        status (str):
        wallet_id (UUID):
        latest_deposit (None | Unset | WalletDepositItem):
    """

    credited_count: int
    scanned_from_block: int
    scanned_to_block: int
    status: str
    wallet_id: UUID
    latest_deposit: None | Unset | WalletDepositItem = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.wallet_deposit_item import WalletDepositItem

        credited_count = self.credited_count

        scanned_from_block = self.scanned_from_block

        scanned_to_block = self.scanned_to_block

        status = self.status

        wallet_id = str(self.wallet_id)

        latest_deposit: dict[str, Any] | None | Unset
        if isinstance(self.latest_deposit, Unset):
            latest_deposit = UNSET
        elif isinstance(self.latest_deposit, WalletDepositItem):
            latest_deposit = self.latest_deposit.to_dict()
        else:
            latest_deposit = self.latest_deposit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "creditedCount": credited_count,
                "scannedFromBlock": scanned_from_block,
                "scannedToBlock": scanned_to_block,
                "status": status,
                "walletId": wallet_id,
            }
        )
        if latest_deposit is not UNSET:
            field_dict["latestDeposit"] = latest_deposit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.wallet_deposit_item import WalletDepositItem

        d = dict(src_dict)
        credited_count = d.pop("creditedCount")

        scanned_from_block = d.pop("scannedFromBlock")

        scanned_to_block = d.pop("scannedToBlock")

        status = d.pop("status")

        wallet_id = UUID(d.pop("walletId"))

        def _parse_latest_deposit(data: object) -> None | Unset | WalletDepositItem:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                latest_deposit_type_1 = WalletDepositItem.from_dict(data)

                return latest_deposit_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WalletDepositItem, data)

        latest_deposit = _parse_latest_deposit(d.pop("latestDeposit", UNSET))

        refresh_wallet_deposits_response = cls(
            credited_count=credited_count,
            scanned_from_block=scanned_from_block,
            scanned_to_block=scanned_to_block,
            status=status,
            wallet_id=wallet_id,
            latest_deposit=latest_deposit,
        )

        refresh_wallet_deposits_response.additional_properties = d
        return refresh_wallet_deposits_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
