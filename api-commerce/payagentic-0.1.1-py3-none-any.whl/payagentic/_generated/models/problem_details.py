from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="ProblemDetails")


@_attrs_define
class ProblemDetails:
    """
    Attributes:
        code (str):
        correlation_id (UUID):
        recovery_hint (str):
        retry (str):
        status (int):
        title (str):
    """

    code: str
    correlation_id: UUID
    recovery_hint: str
    retry: str
    status: int
    title: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        code = self.code

        correlation_id = str(self.correlation_id)

        recovery_hint = self.recovery_hint

        retry = self.retry

        status = self.status

        title = self.title

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "code": code,
                "correlationId": correlation_id,
                "recoveryHint": recovery_hint,
                "retry": retry,
                "status": status,
                "title": title,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        code = d.pop("code")

        correlation_id = UUID(d.pop("correlationId"))

        recovery_hint = d.pop("recoveryHint")

        retry = d.pop("retry")

        status = d.pop("status")

        title = d.pop("title")

        problem_details = cls(
            code=code,
            correlation_id=correlation_id,
            recovery_hint=recovery_hint,
            retry=retry,
            status=status,
            title=title,
        )

        problem_details.additional_properties = d
        return problem_details

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
