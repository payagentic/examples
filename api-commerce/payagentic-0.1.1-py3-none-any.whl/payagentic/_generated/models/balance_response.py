from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="BalanceResponse")


@_attrs_define
class BalanceResponse:
    """
    Attributes:
        available_micro (int):
        currency (str):
        pending_micro (int):
    """

    available_micro: int
    currency: str
    pending_micro: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        available_micro = self.available_micro

        currency = self.currency

        pending_micro = self.pending_micro

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "available_micro": available_micro,
                "currency": currency,
                "pending_micro": pending_micro,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        available_micro = d.pop("available_micro")

        currency = d.pop("currency")

        pending_micro = d.pop("pending_micro")

        balance_response = cls(
            available_micro=available_micro,
            currency=currency,
            pending_micro=pending_micro,
        )

        balance_response.additional_properties = d
        return balance_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
