from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="GetTransferResponse")


@_attrs_define
class GetTransferResponse:
    """Response shape for `GET /v1/transfers/{id}`.

    Attributes:
        status (str):
        transfer_id (UUID):
        failure_reason (None | str | Unset):
        tx_hash (None | str | Unset):
    """

    status: str
    transfer_id: UUID
    failure_reason: None | str | Unset = UNSET
    tx_hash: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status

        transfer_id = str(self.transfer_id)

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "transferId": transfer_id,
            }
        )
        if failure_reason is not UNSET:
            field_dict["failureReason"] = failure_reason
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status")

        transfer_id = UUID(d.pop("transferId"))

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failureReason", UNSET))

        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("txHash", UNSET))

        get_transfer_response = cls(
            status=status,
            transfer_id=transfer_id,
            failure_reason=failure_reason,
            tx_hash=tx_hash,
        )

        get_transfer_response.additional_properties = d
        return get_transfer_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
