from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="WithdrawRequest")


@_attrs_define
class WithdrawRequest:
    """Request body for withdrawing from a wallet.

    Attributes:
        amount (str): Amount to withdraw. Example: 100.00.
        currency (str): Currency code (e.g., "USDC", "ZAR"). Example: USDC.
        destination (str): Destination address or bank account reference. Example:
            0x1234567890abcdef1234567890abcdef12345678.
    """

    amount: str
    currency: str
    destination: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        currency = self.currency

        destination = self.destination

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "currency": currency,
                "destination": destination,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        currency = d.pop("currency")

        destination = d.pop("destination")

        withdraw_request = cls(
            amount=amount,
            currency=currency,
            destination=destination,
        )

        withdraw_request.additional_properties = d
        return withdraw_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
