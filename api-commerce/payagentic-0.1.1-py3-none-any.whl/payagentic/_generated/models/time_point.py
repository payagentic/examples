from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime


T = TypeVar("T", bound="TimePoint")


@_attrs_define
class TimePoint:
    """
    Attributes:
        bucket_start (datetime.datetime):
        currency (str):
        total_micro (int):
    """

    bucket_start: datetime.datetime
    currency: str
    total_micro: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bucket_start = self.bucket_start.isoformat()

        currency = self.currency

        total_micro = self.total_micro

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bucket_start": bucket_start,
                "currency": currency,
                "total_micro": total_micro,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        bucket_start = isoparse(d.pop("bucket_start"))

        currency = d.pop("currency")

        total_micro = d.pop("total_micro")

        time_point = cls(
            bucket_start=bucket_start,
            currency=currency,
            total_micro=total_micro,
        )

        time_point.additional_properties = d
        return time_point

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
