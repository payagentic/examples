from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.voucher_constraints import VoucherConstraints
    from ..models.voucher_target_merchant import VoucherTargetMerchant


T = TypeVar("T", bound="CreateVoucherIntentRequest")


@_attrs_define
class CreateVoucherIntentRequest:
    """
    Attributes:
        country (str):
        face_currency (str):
        face_value (str):
        idempotency_key (str):
        pay_chain (str):
        pay_currency (str):
        provider_product_id (str):
        target_merchant (VoucherTargetMerchant):
        wallet_id (UUID):
        agent_id (None | Unset | UUID):
        constraints (None | Unset | VoucherConstraints):
        purpose (None | str | Unset):
        recipient (None | str | Unset): Recipient identifier required by `recipient_type = "phone_number"`
            products (mobile top-ups/refills) -- e.g. `"+27636424343"`. Ignored
            (and safe to omit) for products with no recipient requirement. Only
            consulted by the live Bitrefill path; the pre-existing mock path never
            needed one.
    """

    country: str
    face_currency: str
    face_value: str
    idempotency_key: str
    pay_chain: str
    pay_currency: str
    provider_product_id: str
    target_merchant: VoucherTargetMerchant
    wallet_id: UUID
    agent_id: None | Unset | UUID = UNSET
    constraints: None | Unset | VoucherConstraints = UNSET
    purpose: None | str | Unset = UNSET
    recipient: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.voucher_constraints import VoucherConstraints
        from ..models.voucher_target_merchant import VoucherTargetMerchant

        country = self.country

        face_currency = self.face_currency

        face_value = self.face_value

        idempotency_key = self.idempotency_key

        pay_chain = self.pay_chain

        pay_currency = self.pay_currency

        provider_product_id = self.provider_product_id

        target_merchant = self.target_merchant.to_dict()

        wallet_id = str(self.wallet_id)

        agent_id: None | str | Unset
        if isinstance(self.agent_id, Unset):
            agent_id = UNSET
        elif isinstance(self.agent_id, UUID):
            agent_id = str(self.agent_id)
        else:
            agent_id = self.agent_id

        constraints: dict[str, Any] | None | Unset
        if isinstance(self.constraints, Unset):
            constraints = UNSET
        elif isinstance(self.constraints, VoucherConstraints):
            constraints = self.constraints.to_dict()
        else:
            constraints = self.constraints

        purpose: None | str | Unset
        if isinstance(self.purpose, Unset):
            purpose = UNSET
        else:
            purpose = self.purpose

        recipient: None | str | Unset
        if isinstance(self.recipient, Unset):
            recipient = UNSET
        else:
            recipient = self.recipient

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "country": country,
                "faceCurrency": face_currency,
                "faceValue": face_value,
                "idempotencyKey": idempotency_key,
                "payChain": pay_chain,
                "payCurrency": pay_currency,
                "providerProductId": provider_product_id,
                "targetMerchant": target_merchant,
                "walletId": wallet_id,
            }
        )
        if agent_id is not UNSET:
            field_dict["agentId"] = agent_id
        if constraints is not UNSET:
            field_dict["constraints"] = constraints
        if purpose is not UNSET:
            field_dict["purpose"] = purpose
        if recipient is not UNSET:
            field_dict["recipient"] = recipient

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.voucher_constraints import VoucherConstraints
        from ..models.voucher_target_merchant import VoucherTargetMerchant

        d = dict(src_dict)
        country = d.pop("country")

        face_currency = d.pop("faceCurrency")

        face_value = d.pop("faceValue")

        idempotency_key = d.pop("idempotencyKey")

        pay_chain = d.pop("payChain")

        pay_currency = d.pop("payCurrency")

        provider_product_id = d.pop("providerProductId")

        target_merchant = VoucherTargetMerchant.from_dict(d.pop("targetMerchant"))

        wallet_id = UUID(d.pop("walletId"))

        def _parse_agent_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                agent_id_type_0 = UUID(data)

                return agent_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        agent_id = _parse_agent_id(d.pop("agentId", UNSET))

        def _parse_constraints(data: object) -> None | Unset | VoucherConstraints:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                constraints_type_1 = VoucherConstraints.from_dict(data)

                return constraints_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VoucherConstraints, data)

        constraints = _parse_constraints(d.pop("constraints", UNSET))

        def _parse_purpose(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        purpose = _parse_purpose(d.pop("purpose", UNSET))

        def _parse_recipient(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        recipient = _parse_recipient(d.pop("recipient", UNSET))

        create_voucher_intent_request = cls(
            country=country,
            face_currency=face_currency,
            face_value=face_value,
            idempotency_key=idempotency_key,
            pay_chain=pay_chain,
            pay_currency=pay_currency,
            provider_product_id=provider_product_id,
            target_merchant=target_merchant,
            wallet_id=wallet_id,
            agent_id=agent_id,
            constraints=constraints,
            purpose=purpose,
            recipient=recipient,
        )

        create_voucher_intent_request.additional_properties = d
        return create_voucher_intent_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
