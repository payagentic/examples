from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.gateway_event_type_1_type import GatewayEventType1Type
from uuid import UUID


T = TypeVar("T", bound="GatewayEventType1")


@_attrs_define
class GatewayEventType1:
    """
    Attributes:
        amount (str): Decimal-formatted stablecoin amount, e.g. "12.50". Source of truth
            is the payments table; this is for display in dashboard toasts.
        currency (str): Settlement currency for the payment (`USDC` or `USDT`).
        organization_id (UUID):
        payment_id (UUID):
        type_ (GatewayEventType1Type):
        wallet_id (UUID):
    """

    amount: str
    currency: str
    organization_id: UUID
    payment_id: UUID
    type_: GatewayEventType1Type
    wallet_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        currency = self.currency

        organization_id = str(self.organization_id)

        payment_id = str(self.payment_id)

        type_ = self.type_.value

        wallet_id = str(self.wallet_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "currency": currency,
                "organization_id": organization_id,
                "payment_id": payment_id,
                "type": type_,
                "wallet_id": wallet_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        currency = d.pop("currency")

        organization_id = UUID(d.pop("organization_id"))

        payment_id = UUID(d.pop("payment_id"))

        type_ = GatewayEventType1Type(d.pop("type"))

        wallet_id = UUID(d.pop("wallet_id"))

        gateway_event_type_1 = cls(
            amount=amount,
            currency=currency,
            organization_id=organization_id,
            payment_id=payment_id,
            type_=type_,
            wallet_id=wallet_id,
        )

        gateway_event_type_1.additional_properties = d
        return gateway_event_type_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
