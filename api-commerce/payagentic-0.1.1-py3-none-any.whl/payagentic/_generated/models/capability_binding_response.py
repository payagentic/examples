from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.capability_binding_authority_summary import CapabilityBindingAuthoritySummary


T = TypeVar("T", bound="CapabilityBindingResponse")


@_attrs_define
class CapabilityBindingResponse:
    """
    Attributes:
        agent_id (UUID):
        authority (CapabilityBindingAuthoritySummary):
        authority_checksum (str):
        created_at (datetime.datetime):
        execution_eligible (bool):
        id (UUID):
        spent_minor (str):
        status (str):
        updated_at (datetime.datetime):
        approved_at (datetime.datetime | None | Unset):
        deprecation_notice (None | str | Unset):
        revoked_at (datetime.datetime | None | Unset):
    """

    agent_id: UUID
    authority: CapabilityBindingAuthoritySummary
    authority_checksum: str
    created_at: datetime.datetime
    execution_eligible: bool
    id: UUID
    spent_minor: str
    status: str
    updated_at: datetime.datetime
    approved_at: datetime.datetime | None | Unset = UNSET
    deprecation_notice: None | str | Unset = UNSET
    revoked_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_binding_authority_summary import CapabilityBindingAuthoritySummary

        agent_id = str(self.agent_id)

        authority = self.authority.to_dict()

        authority_checksum = self.authority_checksum

        created_at = self.created_at.isoformat()

        execution_eligible = self.execution_eligible

        id = str(self.id)

        spent_minor = self.spent_minor

        status = self.status

        updated_at = self.updated_at.isoformat()

        approved_at: None | str | Unset
        if isinstance(self.approved_at, Unset):
            approved_at = UNSET
        elif isinstance(self.approved_at, datetime.datetime):
            approved_at = self.approved_at.isoformat()
        else:
            approved_at = self.approved_at

        deprecation_notice: None | str | Unset
        if isinstance(self.deprecation_notice, Unset):
            deprecation_notice = UNSET
        else:
            deprecation_notice = self.deprecation_notice

        revoked_at: None | str | Unset
        if isinstance(self.revoked_at, Unset):
            revoked_at = UNSET
        elif isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentId": agent_id,
                "authority": authority,
                "authorityChecksum": authority_checksum,
                "createdAt": created_at,
                "executionEligible": execution_eligible,
                "id": id,
                "spentMinor": spent_minor,
                "status": status,
                "updatedAt": updated_at,
            }
        )
        if approved_at is not UNSET:
            field_dict["approvedAt"] = approved_at
        if deprecation_notice is not UNSET:
            field_dict["deprecationNotice"] = deprecation_notice
        if revoked_at is not UNSET:
            field_dict["revokedAt"] = revoked_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_binding_authority_summary import CapabilityBindingAuthoritySummary

        d = dict(src_dict)
        agent_id = UUID(d.pop("agentId"))

        authority = CapabilityBindingAuthoritySummary.from_dict(d.pop("authority"))

        authority_checksum = d.pop("authorityChecksum")

        created_at = isoparse(d.pop("createdAt"))

        execution_eligible = d.pop("executionEligible")

        id = UUID(d.pop("id"))

        spent_minor = d.pop("spentMinor")

        status = d.pop("status")

        updated_at = isoparse(d.pop("updatedAt"))

        def _parse_approved_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                approved_at_type_0 = isoparse(data)

                return approved_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        approved_at = _parse_approved_at(d.pop("approvedAt", UNSET))

        def _parse_deprecation_notice(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        deprecation_notice = _parse_deprecation_notice(d.pop("deprecationNotice", UNSET))

        def _parse_revoked_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = isoparse(data)

                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        revoked_at = _parse_revoked_at(d.pop("revokedAt", UNSET))

        capability_binding_response = cls(
            agent_id=agent_id,
            authority=authority,
            authority_checksum=authority_checksum,
            created_at=created_at,
            execution_eligible=execution_eligible,
            id=id,
            spent_minor=spent_minor,
            status=status,
            updated_at=updated_at,
            approved_at=approved_at,
            deprecation_notice=deprecation_notice,
            revoked_at=revoked_at,
        )

        capability_binding_response.additional_properties = d
        return capability_binding_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
