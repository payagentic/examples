from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.blueprint_guardrails import BlueprintGuardrails
    from ..models.blueprint_wallet_choice import BlueprintWalletChoice


T = TypeVar("T", bound="ProvisionAgentTemplateRequest")


@_attrs_define
class ProvisionAgentTemplateRequest:
    """
    Attributes:
        agent_name (str):
        authority_confirmed (bool):
        guardrails (BlueprintGuardrails):
        language (str):
        profile (str):
        template_version (str):
        wallet (BlueprintWalletChoice):
    """

    agent_name: str
    authority_confirmed: bool
    guardrails: BlueprintGuardrails
    language: str
    profile: str
    template_version: str
    wallet: BlueprintWalletChoice
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.blueprint_guardrails import BlueprintGuardrails
        from ..models.blueprint_wallet_choice import BlueprintWalletChoice

        agent_name = self.agent_name

        authority_confirmed = self.authority_confirmed

        guardrails = self.guardrails.to_dict()

        language = self.language

        profile = self.profile

        template_version = self.template_version

        wallet = self.wallet.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentName": agent_name,
                "authorityConfirmed": authority_confirmed,
                "guardrails": guardrails,
                "language": language,
                "profile": profile,
                "templateVersion": template_version,
                "wallet": wallet,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blueprint_guardrails import BlueprintGuardrails
        from ..models.blueprint_wallet_choice import BlueprintWalletChoice

        d = dict(src_dict)
        agent_name = d.pop("agentName")

        authority_confirmed = d.pop("authorityConfirmed")

        guardrails = BlueprintGuardrails.from_dict(d.pop("guardrails"))

        language = d.pop("language")

        profile = d.pop("profile")

        template_version = d.pop("templateVersion")

        wallet = BlueprintWalletChoice.from_dict(d.pop("wallet"))

        provision_agent_template_request = cls(
            agent_name=agent_name,
            authority_confirmed=authority_confirmed,
            guardrails=guardrails,
            language=language,
            profile=profile,
            template_version=template_version,
            wallet=wallet,
        )

        provision_agent_template_request.additional_properties = d
        return provision_agent_template_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
