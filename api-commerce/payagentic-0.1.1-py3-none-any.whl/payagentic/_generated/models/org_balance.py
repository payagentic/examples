from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.time_series_point import TimeSeriesPoint


T = TypeVar("T", bound="OrgBalance")


@_attrs_define
class OrgBalance:
    """
    Attributes:
        delta_abs (float):
        delta_pct (float):
        history (list[TimeSeriesPoint]):
        total (float):
    """

    delta_abs: float
    delta_pct: float
    history: list[TimeSeriesPoint]
    total: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.time_series_point import TimeSeriesPoint

        delta_abs = self.delta_abs

        delta_pct = self.delta_pct

        history = []
        for history_item_data in self.history:
            history_item = history_item_data.to_dict()
            history.append(history_item)

        total = self.total

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "deltaAbs": delta_abs,
                "deltaPct": delta_pct,
                "history": history,
                "total": total,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.time_series_point import TimeSeriesPoint

        d = dict(src_dict)
        delta_abs = d.pop("deltaAbs")

        delta_pct = d.pop("deltaPct")

        history = []
        _history = d.pop("history")
        for history_item_data in _history:
            history_item = TimeSeriesPoint.from_dict(history_item_data)

            history.append(history_item)

        total = d.pop("total")

        org_balance = cls(
            delta_abs=delta_abs,
            delta_pct=delta_pct,
            history=history,
            total=total,
        )

        org_balance.additional_properties = d
        return org_balance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
