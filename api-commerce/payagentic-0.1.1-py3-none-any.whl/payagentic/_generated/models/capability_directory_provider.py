from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CapabilityDirectoryProvider")


@_attrs_define
class CapabilityDirectoryProvider:
    """
    Attributes:
        display_name (str):
        id (str):
        kya_tier (int):
        verified (bool):
    """

    display_name: str
    id: str
    kya_tier: int
    verified: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        display_name = self.display_name

        id = self.id

        kya_tier = self.kya_tier

        verified = self.verified

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "displayName": display_name,
                "id": id,
                "kyaTier": kya_tier,
                "verified": verified,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        display_name = d.pop("displayName")

        id = d.pop("id")

        kya_tier = d.pop("kyaTier")

        verified = d.pop("verified")

        capability_directory_provider = cls(
            display_name=display_name,
            id=id,
            kya_tier=kya_tier,
            verified=verified,
        )

        capability_directory_provider.additional_properties = d
        return capability_directory_provider

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
