from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="SellerBinding")


@_attrs_define
class SellerBinding:
    """
    Attributes:
        amount (str):
        currency (str):
        endpoint_id (str):
        expires_at (str):
        merchant_id (str):
        mode (str):
        nonce (str):
        recipient (str):
        resource_url (str):
        signature (str):
        version (int):
    """

    amount: str
    currency: str
    endpoint_id: str
    expires_at: str
    merchant_id: str
    mode: str
    nonce: str
    recipient: str
    resource_url: str
    signature: str
    version: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        currency = self.currency

        endpoint_id = self.endpoint_id

        expires_at = self.expires_at

        merchant_id = self.merchant_id

        mode = self.mode

        nonce = self.nonce

        recipient = self.recipient

        resource_url = self.resource_url

        signature = self.signature

        version = self.version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "currency": currency,
                "endpointId": endpoint_id,
                "expiresAt": expires_at,
                "merchantId": merchant_id,
                "mode": mode,
                "nonce": nonce,
                "recipient": recipient,
                "resourceUrl": resource_url,
                "signature": signature,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        currency = d.pop("currency")

        endpoint_id = d.pop("endpointId")

        expires_at = d.pop("expiresAt")

        merchant_id = d.pop("merchantId")

        mode = d.pop("mode")

        nonce = d.pop("nonce")

        recipient = d.pop("recipient")

        resource_url = d.pop("resourceUrl")

        signature = d.pop("signature")

        version = d.pop("version")

        seller_binding = cls(
            amount=amount,
            currency=currency,
            endpoint_id=endpoint_id,
            expires_at=expires_at,
            merchant_id=merchant_id,
            mode=mode,
            nonce=nonce,
            recipient=recipient,
            resource_url=resource_url,
            signature=signature,
            version=version,
        )

        seller_binding.additional_properties = d
        return seller_binding

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
