from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="DailyKpis")


@_attrs_define
class DailyKpis:
    """
    Attributes:
        open_alerts (int):
        pending_approvals (int):
        today_spend (float):
    """

    open_alerts: int
    pending_approvals: int
    today_spend: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        open_alerts = self.open_alerts

        pending_approvals = self.pending_approvals

        today_spend = self.today_spend

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "openAlerts": open_alerts,
                "pendingApprovals": pending_approvals,
                "todaySpend": today_spend,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        open_alerts = d.pop("openAlerts")

        pending_approvals = d.pop("pendingApprovals")

        today_spend = d.pop("todaySpend")

        daily_kpis = cls(
            open_alerts=open_alerts,
            pending_approvals=pending_approvals,
            today_spend=today_spend,
        )

        daily_kpis.additional_properties = d
        return daily_kpis

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
