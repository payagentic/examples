from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="VerifyRequest")


@_attrs_define
class VerifyRequest:
    """
    Attributes:
        credential (str): Base64-encoded JSON: `{"scheme":"exact","authorization":{...},"signature":"0x..."}`.
            Extracted by the vendor SDK from `Authorization: Payment <credential>`.
        expected_amount (None | str | Unset): Optional: amount the vendor expects (decimal string). If provided,
            verify checks transactions.amount matches.
        expected_currency (None | str | Unset): Optional: currency the vendor expects (e.g. "USDC").
        expected_url (None | str | Unset): Optional: URL the vendor is protecting. Accepted but currently
            ignored — URL binding lands in P4.
    """

    credential: str
    expected_amount: None | str | Unset = UNSET
    expected_currency: None | str | Unset = UNSET
    expected_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        credential = self.credential

        expected_amount: None | str | Unset
        if isinstance(self.expected_amount, Unset):
            expected_amount = UNSET
        else:
            expected_amount = self.expected_amount

        expected_currency: None | str | Unset
        if isinstance(self.expected_currency, Unset):
            expected_currency = UNSET
        else:
            expected_currency = self.expected_currency

        expected_url: None | str | Unset
        if isinstance(self.expected_url, Unset):
            expected_url = UNSET
        else:
            expected_url = self.expected_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "credential": credential,
            }
        )
        if expected_amount is not UNSET:
            field_dict["expected_amount"] = expected_amount
        if expected_currency is not UNSET:
            field_dict["expected_currency"] = expected_currency
        if expected_url is not UNSET:
            field_dict["expected_url"] = expected_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        credential = d.pop("credential")

        def _parse_expected_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_amount = _parse_expected_amount(d.pop("expected_amount", UNSET))

        def _parse_expected_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_currency = _parse_expected_currency(d.pop("expected_currency", UNSET))

        def _parse_expected_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_url = _parse_expected_url(d.pop("expected_url", UNSET))

        verify_request = cls(
            credential=credential,
            expected_amount=expected_amount,
            expected_currency=expected_currency,
            expected_url=expected_url,
        )

        verify_request.additional_properties = d
        return verify_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
