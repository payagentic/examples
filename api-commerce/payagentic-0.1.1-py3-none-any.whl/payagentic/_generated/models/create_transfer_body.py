from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="CreateTransferBody")


@_attrs_define
class CreateTransferBody:
    """Inbound shape — mirrors `web/src/app/_hooks/right/use-submit-transfer.ts`.

    Attributes:
        amount (str):
        source_wallet_id (UUID):
        currency (None | str | Unset):
        destination_address (None | str | Unset):
        destination_wallet_id (None | Unset | UUID):
        idempotency_key (None | str | Unset): Client-generated idempotency key. Replays with the same key return the
            existing transfer instead of broadcasting a second one (dedup on
            `(org_id, idempotency_key_hash)` in the payments service).
        mode (None | str | Unset):
    """

    amount: str
    source_wallet_id: UUID
    currency: None | str | Unset = UNSET
    destination_address: None | str | Unset = UNSET
    destination_wallet_id: None | Unset | UUID = UNSET
    idempotency_key: None | str | Unset = UNSET
    mode: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        source_wallet_id = str(self.source_wallet_id)

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        destination_address: None | str | Unset
        if isinstance(self.destination_address, Unset):
            destination_address = UNSET
        else:
            destination_address = self.destination_address

        destination_wallet_id: None | str | Unset
        if isinstance(self.destination_wallet_id, Unset):
            destination_wallet_id = UNSET
        elif isinstance(self.destination_wallet_id, UUID):
            destination_wallet_id = str(self.destination_wallet_id)
        else:
            destination_wallet_id = self.destination_wallet_id

        idempotency_key: None | str | Unset
        if isinstance(self.idempotency_key, Unset):
            idempotency_key = UNSET
        else:
            idempotency_key = self.idempotency_key

        mode: None | str | Unset
        if isinstance(self.mode, Unset):
            mode = UNSET
        else:
            mode = self.mode

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "sourceWalletId": source_wallet_id,
            }
        )
        if currency is not UNSET:
            field_dict["currency"] = currency
        if destination_address is not UNSET:
            field_dict["destinationAddress"] = destination_address
        if destination_wallet_id is not UNSET:
            field_dict["destinationWalletId"] = destination_wallet_id
        if idempotency_key is not UNSET:
            field_dict["idempotencyKey"] = idempotency_key
        if mode is not UNSET:
            field_dict["mode"] = mode

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        source_wallet_id = UUID(d.pop("sourceWalletId"))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_destination_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        destination_address = _parse_destination_address(d.pop("destinationAddress", UNSET))

        def _parse_destination_wallet_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                destination_wallet_id_type_0 = UUID(data)

                return destination_wallet_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        destination_wallet_id = _parse_destination_wallet_id(d.pop("destinationWalletId", UNSET))

        def _parse_idempotency_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        idempotency_key = _parse_idempotency_key(d.pop("idempotencyKey", UNSET))

        def _parse_mode(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mode = _parse_mode(d.pop("mode", UNSET))

        create_transfer_body = cls(
            amount=amount,
            source_wallet_id=source_wallet_id,
            currency=currency,
            destination_address=destination_address,
            destination_wallet_id=destination_wallet_id,
            idempotency_key=idempotency_key,
            mode=mode,
        )

        create_transfer_body.additional_properties = d
        return create_transfer_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
