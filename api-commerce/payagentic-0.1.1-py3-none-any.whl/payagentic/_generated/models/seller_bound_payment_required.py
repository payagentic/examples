from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.seller_binding import SellerBinding
    from ..models.seller_bound_accept import SellerBoundAccept
    from ..models.seller_bound_resource import SellerBoundResource


T = TypeVar("T", bound="SellerBoundPaymentRequired")


@_attrs_define
class SellerBoundPaymentRequired:
    """
    Attributes:
        accepts (list[SellerBoundAccept]):
        endpoint_id (str):
        resource (SellerBoundResource):
        seller_binding (SellerBinding):
        x_402_version (int):
    """

    accepts: list[SellerBoundAccept]
    endpoint_id: str
    resource: SellerBoundResource
    seller_binding: SellerBinding
    x_402_version: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.seller_binding import SellerBinding
        from ..models.seller_bound_accept import SellerBoundAccept
        from ..models.seller_bound_resource import SellerBoundResource

        accepts = []
        for accepts_item_data in self.accepts:
            accepts_item = accepts_item_data.to_dict()
            accepts.append(accepts_item)

        endpoint_id = self.endpoint_id

        resource = self.resource.to_dict()

        seller_binding = self.seller_binding.to_dict()

        x_402_version = self.x_402_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "accepts": accepts,
                "endpointId": endpoint_id,
                "resource": resource,
                "sellerBinding": seller_binding,
                "x402Version": x_402_version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.seller_binding import SellerBinding
        from ..models.seller_bound_accept import SellerBoundAccept
        from ..models.seller_bound_resource import SellerBoundResource

        d = dict(src_dict)
        accepts = []
        _accepts = d.pop("accepts")
        for accepts_item_data in _accepts:
            accepts_item = SellerBoundAccept.from_dict(accepts_item_data)

            accepts.append(accepts_item)

        endpoint_id = d.pop("endpointId")

        resource = SellerBoundResource.from_dict(d.pop("resource"))

        seller_binding = SellerBinding.from_dict(d.pop("sellerBinding"))

        x_402_version = d.pop("x402Version")

        seller_bound_payment_required = cls(
            accepts=accepts,
            endpoint_id=endpoint_id,
            resource=resource,
            seller_binding=seller_binding,
            x_402_version=x_402_version,
        )

        seller_bound_payment_required.additional_properties = d
        return seller_bound_payment_required

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
