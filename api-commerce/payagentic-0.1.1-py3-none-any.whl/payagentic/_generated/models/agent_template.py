from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.blueprint_profile import BlueprintProfile


T = TypeVar("T", bound="AgentTemplate")


@_attrs_define
class AgentTemplate:
    """
    Attributes:
        accent (str):
        capabilities (list[str]):
        checksum (str):
        dedicated_wallet_default (bool):
        default_profile (str):
        description (str):
        eyebrow (str):
        languages (list[str]):
        name (str):
        profiles (list[BlueprintProfile]):
        released_at (str):
        runtime_architecture (list[str]):
        slug (str):
        version (str):
        wallet_default (str):
    """

    accent: str
    capabilities: list[str]
    checksum: str
    dedicated_wallet_default: bool
    default_profile: str
    description: str
    eyebrow: str
    languages: list[str]
    name: str
    profiles: list[BlueprintProfile]
    released_at: str
    runtime_architecture: list[str]
    slug: str
    version: str
    wallet_default: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.blueprint_profile import BlueprintProfile

        accent = self.accent

        capabilities = self.capabilities

        checksum = self.checksum

        dedicated_wallet_default = self.dedicated_wallet_default

        default_profile = self.default_profile

        description = self.description

        eyebrow = self.eyebrow

        languages = self.languages

        name = self.name

        profiles = []
        for profiles_item_data in self.profiles:
            profiles_item = profiles_item_data.to_dict()
            profiles.append(profiles_item)

        released_at = self.released_at

        runtime_architecture = self.runtime_architecture

        slug = self.slug

        version = self.version

        wallet_default = self.wallet_default

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "accent": accent,
                "capabilities": capabilities,
                "checksum": checksum,
                "dedicatedWalletDefault": dedicated_wallet_default,
                "defaultProfile": default_profile,
                "description": description,
                "eyebrow": eyebrow,
                "languages": languages,
                "name": name,
                "profiles": profiles,
                "releasedAt": released_at,
                "runtimeArchitecture": runtime_architecture,
                "slug": slug,
                "version": version,
                "walletDefault": wallet_default,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blueprint_profile import BlueprintProfile

        d = dict(src_dict)
        accent = d.pop("accent")

        capabilities = cast(list[str], d.pop("capabilities"))

        checksum = d.pop("checksum")

        dedicated_wallet_default = d.pop("dedicatedWalletDefault")

        default_profile = d.pop("defaultProfile")

        description = d.pop("description")

        eyebrow = d.pop("eyebrow")

        languages = cast(list[str], d.pop("languages"))

        name = d.pop("name")

        profiles = []
        _profiles = d.pop("profiles")
        for profiles_item_data in _profiles:
            profiles_item = BlueprintProfile.from_dict(profiles_item_data)

            profiles.append(profiles_item)

        released_at = d.pop("releasedAt")

        runtime_architecture = cast(list[str], d.pop("runtimeArchitecture"))

        slug = d.pop("slug")

        version = d.pop("version")

        wallet_default = d.pop("walletDefault")

        agent_template = cls(
            accent=accent,
            capabilities=capabilities,
            checksum=checksum,
            dedicated_wallet_default=dedicated_wallet_default,
            default_profile=default_profile,
            description=description,
            eyebrow=eyebrow,
            languages=languages,
            name=name,
            profiles=profiles,
            released_at=released_at,
            runtime_architecture=runtime_architecture,
            slug=slug,
            version=version,
            wallet_default=wallet_default,
        )

        agent_template.additional_properties = d
        return agent_template

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
