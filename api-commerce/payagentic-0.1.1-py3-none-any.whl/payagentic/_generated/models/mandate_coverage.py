from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="MandateCoverage")


@_attrs_define
class MandateCoverage:
    """Shape returned to the dashboard. Field names match
    `MandateCoverageMetric` in `web/src/lib/mandate-api.ts`. The web
    `coveragePercent` helper computes the percentage client-side.

        Attributes:
            total (int):
            window (str):
            with_mandate (int):
    """

    total: int
    window: str
    with_mandate: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        window = self.window

        with_mandate = self.with_mandate

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "window": window,
                "with_mandate": with_mandate,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total = d.pop("total")

        window = d.pop("window")

        with_mandate = d.pop("with_mandate")

        mandate_coverage = cls(
            total=total,
            window=window,
            with_mandate=with_mandate,
        )

        mandate_coverage.additional_properties = d
        return mandate_coverage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
