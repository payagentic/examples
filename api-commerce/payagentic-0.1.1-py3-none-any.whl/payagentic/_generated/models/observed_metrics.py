from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime


T = TypeVar("T", bound="ObservedMetrics")


@_attrs_define
class ObservedMetrics:
    """
    Attributes:
        eligible_terminal_attempt_count (int):
        evidence (str):
        latency_observation_count (int):
        reliability_basis_points (int):
        settled_invocation_count (int):
        average_latency_ms (int | None | Unset):
        latest_platform_test_at (datetime.datetime | None | Unset):
    """

    eligible_terminal_attempt_count: int
    evidence: str
    latency_observation_count: int
    reliability_basis_points: int
    settled_invocation_count: int
    average_latency_ms: int | None | Unset = UNSET
    latest_platform_test_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        eligible_terminal_attempt_count = self.eligible_terminal_attempt_count

        evidence = self.evidence

        latency_observation_count = self.latency_observation_count

        reliability_basis_points = self.reliability_basis_points

        settled_invocation_count = self.settled_invocation_count

        average_latency_ms: int | None | Unset
        if isinstance(self.average_latency_ms, Unset):
            average_latency_ms = UNSET
        else:
            average_latency_ms = self.average_latency_ms

        latest_platform_test_at: None | str | Unset
        if isinstance(self.latest_platform_test_at, Unset):
            latest_platform_test_at = UNSET
        elif isinstance(self.latest_platform_test_at, datetime.datetime):
            latest_platform_test_at = self.latest_platform_test_at.isoformat()
        else:
            latest_platform_test_at = self.latest_platform_test_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eligibleTerminalAttemptCount": eligible_terminal_attempt_count,
                "evidence": evidence,
                "latencyObservationCount": latency_observation_count,
                "reliabilityBasisPoints": reliability_basis_points,
                "settledInvocationCount": settled_invocation_count,
            }
        )
        if average_latency_ms is not UNSET:
            field_dict["averageLatencyMs"] = average_latency_ms
        if latest_platform_test_at is not UNSET:
            field_dict["latestPlatformTestAt"] = latest_platform_test_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        eligible_terminal_attempt_count = d.pop("eligibleTerminalAttemptCount")

        evidence = d.pop("evidence")

        latency_observation_count = d.pop("latencyObservationCount")

        reliability_basis_points = d.pop("reliabilityBasisPoints")

        settled_invocation_count = d.pop("settledInvocationCount")

        def _parse_average_latency_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        average_latency_ms = _parse_average_latency_ms(d.pop("averageLatencyMs", UNSET))

        def _parse_latest_platform_test_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                latest_platform_test_at_type_0 = isoparse(data)

                return latest_platform_test_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        latest_platform_test_at = _parse_latest_platform_test_at(
            d.pop("latestPlatformTestAt", UNSET)
        )

        observed_metrics = cls(
            eligible_terminal_attempt_count=eligible_terminal_attempt_count,
            evidence=evidence,
            latency_observation_count=latency_observation_count,
            reliability_basis_points=reliability_basis_points,
            settled_invocation_count=settled_invocation_count,
            average_latency_ms=average_latency_ms,
            latest_platform_test_at=latest_platform_test_at,
        )

        observed_metrics.additional_properties = d
        return observed_metrics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
