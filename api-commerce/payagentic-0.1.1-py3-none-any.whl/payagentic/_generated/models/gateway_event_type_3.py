from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.gateway_event_type_3_type import GatewayEventType3Type
from uuid import UUID


T = TypeVar("T", bound="GatewayEventType3")


@_attrs_define
class GatewayEventType3:
    """
    Attributes:
        organization_id (UUID):
        state (str):
        transfer_id (UUID):
        type_ (GatewayEventType3Type):
    """

    organization_id: UUID
    state: str
    transfer_id: UUID
    type_: GatewayEventType3Type
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        organization_id = str(self.organization_id)

        state = self.state

        transfer_id = str(self.transfer_id)

        type_ = self.type_.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "organization_id": organization_id,
                "state": state,
                "transfer_id": transfer_id,
                "type": type_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        organization_id = UUID(d.pop("organization_id"))

        state = d.pop("state")

        transfer_id = UUID(d.pop("transfer_id"))

        type_ = GatewayEventType3Type(d.pop("type"))

        gateway_event_type_3 = cls(
            organization_id=organization_id,
            state=state,
            transfer_id=transfer_id,
            type_=type_,
        )

        gateway_event_type_3.additional_properties = d
        return gateway_event_type_3

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
