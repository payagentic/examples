from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="RankingEvidence")


@_attrs_define
class RankingEvidence:
    """
    Attributes:
        budget_fit (int):
        latency (int):
        relevance (int):
        reliability (int):
        schema_compatibility (int):
        trust (int):
    """

    budget_fit: int
    latency: int
    relevance: int
    reliability: int
    schema_compatibility: int
    trust: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        budget_fit = self.budget_fit

        latency = self.latency

        relevance = self.relevance

        reliability = self.reliability

        schema_compatibility = self.schema_compatibility

        trust = self.trust

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "budgetFit": budget_fit,
                "latency": latency,
                "relevance": relevance,
                "reliability": reliability,
                "schemaCompatibility": schema_compatibility,
                "trust": trust,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        budget_fit = d.pop("budgetFit")

        latency = d.pop("latency")

        relevance = d.pop("relevance")

        reliability = d.pop("reliability")

        schema_compatibility = d.pop("schemaCompatibility")

        trust = d.pop("trust")

        ranking_evidence = cls(
            budget_fit=budget_fit,
            latency=latency,
            relevance=relevance,
            reliability=reliability,
            schema_compatibility=schema_compatibility,
            trust=trust,
        )

        ranking_evidence.additional_properties = d
        return ranking_evidence

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
