from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="MerchantOriginProof")


@_attrs_define
class MerchantOriginProof:
    """
    Attributes:
        api_id (str):
        canonical_base_url (str):
        challenge_id (str):
        expires_at (str):
        merchant_id (str):
        mode (str):
        nonce (str):
        version (int):
        signature (None | str | Unset):
    """

    api_id: str
    canonical_base_url: str
    challenge_id: str
    expires_at: str
    merchant_id: str
    mode: str
    nonce: str
    version: int
    signature: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        api_id = self.api_id

        canonical_base_url = self.canonical_base_url

        challenge_id = self.challenge_id

        expires_at = self.expires_at

        merchant_id = self.merchant_id

        mode = self.mode

        nonce = self.nonce

        version = self.version

        signature: None | str | Unset
        if isinstance(self.signature, Unset):
            signature = UNSET
        else:
            signature = self.signature

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "apiId": api_id,
                "canonicalBaseUrl": canonical_base_url,
                "challengeId": challenge_id,
                "expiresAt": expires_at,
                "merchantId": merchant_id,
                "mode": mode,
                "nonce": nonce,
                "version": version,
            }
        )
        if signature is not UNSET:
            field_dict["signature"] = signature

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api_id = d.pop("apiId")

        canonical_base_url = d.pop("canonicalBaseUrl")

        challenge_id = d.pop("challengeId")

        expires_at = d.pop("expiresAt")

        merchant_id = d.pop("merchantId")

        mode = d.pop("mode")

        nonce = d.pop("nonce")

        version = d.pop("version")

        def _parse_signature(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        signature = _parse_signature(d.pop("signature", UNSET))

        merchant_origin_proof = cls(
            api_id=api_id,
            canonical_base_url=canonical_base_url,
            challenge_id=challenge_id,
            expires_at=expires_at,
            merchant_id=merchant_id,
            mode=mode,
            nonce=nonce,
            version=version,
            signature=signature,
        )

        merchant_origin_proof.additional_properties = d
        return merchant_origin_proof

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
