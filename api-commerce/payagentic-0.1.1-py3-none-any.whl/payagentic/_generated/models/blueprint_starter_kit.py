from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="BlueprintStarterKit")


@_attrs_define
class BlueprintStarterKit:
    """
    Attributes:
        bytes_ (int):
        download_url (str):
        dry_run_command (str):
        language (str):
        sha256 (str):
        source_path (str):
    """

    bytes_: int
    download_url: str
    dry_run_command: str
    language: str
    sha256: str
    source_path: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bytes_ = self.bytes_

        download_url = self.download_url

        dry_run_command = self.dry_run_command

        language = self.language

        sha256 = self.sha256

        source_path = self.source_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bytes": bytes_,
                "downloadUrl": download_url,
                "dryRunCommand": dry_run_command,
                "language": language,
                "sha256": sha256,
                "sourcePath": source_path,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        bytes_ = d.pop("bytes")

        download_url = d.pop("downloadUrl")

        dry_run_command = d.pop("dryRunCommand")

        language = d.pop("language")

        sha256 = d.pop("sha256")

        source_path = d.pop("sourcePath")

        blueprint_starter_kit = cls(
            bytes_=bytes_,
            download_url=download_url,
            dry_run_command=dry_run_command,
            language=language,
            sha256=sha256,
            source_path=source_path,
        )

        blueprint_starter_kit.additional_properties = d
        return blueprint_starter_kit

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
