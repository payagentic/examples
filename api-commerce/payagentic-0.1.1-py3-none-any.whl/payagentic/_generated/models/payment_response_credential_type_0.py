from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="PaymentResponseCredentialType0")


@_attrs_define
class PaymentResponseCredentialType0:
    """Rail-formatted credential header returned on approve/settled success.

    An object with `header_name` and `header_value` keys.  The header name
    is rail-specific: `X-Payment` for x402 legacy, `Authorization` (with a
    `Payment <base64>` value) for MPP, `PAYMENT-SIGNATURE` for x402 v2.
    The SDK sets `header_name: header_value` verbatim when retrying the
    upstream vendor request.  Present on 200; absent (null) on
    pending-approval (202) or failure.

    """

    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        payment_response_credential_type_0 = cls()

        payment_response_credential_type_0.additional_properties = d
        return payment_response_credential_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
