from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="RegisterLinkedWalletRequest")


@_attrs_define
class RegisterLinkedWalletRequest:
    """Request body for `POST /v1/linked-wallets`.

    Attributes:
        address (str):
        proof_method (str): `'privy_linked_account'` (sign-in wallet) or `'challenge_signature'`.
        challenge_id (None | Unset | UUID): Required for the `challenge_signature` path.
        ens_name (None | str | Unset):
        label (None | str | Unset):
        signature (None | str | Unset): 65-byte `personal_sign` signature hex. Required for the `challenge_signature`
            path.
    """

    address: str
    proof_method: str
    challenge_id: None | Unset | UUID = UNSET
    ens_name: None | str | Unset = UNSET
    label: None | str | Unset = UNSET
    signature: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        address = self.address

        proof_method = self.proof_method

        challenge_id: None | str | Unset
        if isinstance(self.challenge_id, Unset):
            challenge_id = UNSET
        elif isinstance(self.challenge_id, UUID):
            challenge_id = str(self.challenge_id)
        else:
            challenge_id = self.challenge_id

        ens_name: None | str | Unset
        if isinstance(self.ens_name, Unset):
            ens_name = UNSET
        else:
            ens_name = self.ens_name

        label: None | str | Unset
        if isinstance(self.label, Unset):
            label = UNSET
        else:
            label = self.label

        signature: None | str | Unset
        if isinstance(self.signature, Unset):
            signature = UNSET
        else:
            signature = self.signature

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "address": address,
                "proof_method": proof_method,
            }
        )
        if challenge_id is not UNSET:
            field_dict["challenge_id"] = challenge_id
        if ens_name is not UNSET:
            field_dict["ens_name"] = ens_name
        if label is not UNSET:
            field_dict["label"] = label
        if signature is not UNSET:
            field_dict["signature"] = signature

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address = d.pop("address")

        proof_method = d.pop("proof_method")

        def _parse_challenge_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                challenge_id_type_0 = UUID(data)

                return challenge_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        challenge_id = _parse_challenge_id(d.pop("challenge_id", UNSET))

        def _parse_ens_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ens_name = _parse_ens_name(d.pop("ens_name", UNSET))

        def _parse_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label = _parse_label(d.pop("label", UNSET))

        def _parse_signature(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        signature = _parse_signature(d.pop("signature", UNSET))

        register_linked_wallet_request = cls(
            address=address,
            proof_method=proof_method,
            challenge_id=challenge_id,
            ens_name=ens_name,
            label=label,
            signature=signature,
        )

        register_linked_wallet_request.additional_properties = d
        return register_linked_wallet_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
