from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="PaymentDecisionResponse")


@_attrs_define
class PaymentDecisionResponse:
    """
    Attributes:
        reason (str):
        status (str):
        transaction_id (str):
        retry_requires_fresh_seller_binding (bool | None | Unset):
        retry_with_new_idempotency_key (bool | None | Unset):
    """

    reason: str
    status: str
    transaction_id: str
    retry_requires_fresh_seller_binding: bool | None | Unset = UNSET
    retry_with_new_idempotency_key: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        reason = self.reason

        status = self.status

        transaction_id = self.transaction_id

        retry_requires_fresh_seller_binding: bool | None | Unset
        if isinstance(self.retry_requires_fresh_seller_binding, Unset):
            retry_requires_fresh_seller_binding = UNSET
        else:
            retry_requires_fresh_seller_binding = self.retry_requires_fresh_seller_binding

        retry_with_new_idempotency_key: bool | None | Unset
        if isinstance(self.retry_with_new_idempotency_key, Unset):
            retry_with_new_idempotency_key = UNSET
        else:
            retry_with_new_idempotency_key = self.retry_with_new_idempotency_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "reason": reason,
                "status": status,
                "transaction_id": transaction_id,
            }
        )
        if retry_requires_fresh_seller_binding is not UNSET:
            field_dict["retry_requires_fresh_seller_binding"] = retry_requires_fresh_seller_binding
        if retry_with_new_idempotency_key is not UNSET:
            field_dict["retry_with_new_idempotency_key"] = retry_with_new_idempotency_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reason = d.pop("reason")

        status = d.pop("status")

        transaction_id = d.pop("transaction_id")

        def _parse_retry_requires_fresh_seller_binding(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        retry_requires_fresh_seller_binding = _parse_retry_requires_fresh_seller_binding(
            d.pop("retry_requires_fresh_seller_binding", UNSET)
        )

        def _parse_retry_with_new_idempotency_key(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        retry_with_new_idempotency_key = _parse_retry_with_new_idempotency_key(
            d.pop("retry_with_new_idempotency_key", UNSET)
        )

        payment_decision_response = cls(
            reason=reason,
            status=status,
            transaction_id=transaction_id,
            retry_requires_fresh_seller_binding=retry_requires_fresh_seller_binding,
            retry_with_new_idempotency_key=retry_with_new_idempotency_key,
        )

        payment_decision_response.additional_properties = d
        return payment_decision_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
