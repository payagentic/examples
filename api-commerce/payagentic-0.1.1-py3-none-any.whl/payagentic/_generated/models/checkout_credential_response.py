from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="CheckoutCredentialResponse")


@_attrs_define
class CheckoutCredentialResponse:
    """
    Attributes:
        checkout_intent_id (UUID):
        credential_type (str):
        expires_at (datetime.datetime):
        handoff_url (str):
        status (str):
    """

    checkout_intent_id: UUID
    credential_type: str
    expires_at: datetime.datetime
    handoff_url: str
    status: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        checkout_intent_id = str(self.checkout_intent_id)

        credential_type = self.credential_type

        expires_at = self.expires_at.isoformat()

        handoff_url = self.handoff_url

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "checkoutIntentId": checkout_intent_id,
                "credentialType": credential_type,
                "expiresAt": expires_at,
                "handoffUrl": handoff_url,
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        checkout_intent_id = UUID(d.pop("checkoutIntentId"))

        credential_type = d.pop("credentialType")

        expires_at = isoparse(d.pop("expiresAt"))

        handoff_url = d.pop("handoffUrl")

        status = d.pop("status")

        checkout_credential_response = cls(
            checkout_intent_id=checkout_intent_id,
            credential_type=credential_type,
            expires_at=expires_at,
            handoff_url=handoff_url,
            status=status,
        )

        checkout_credential_response.additional_properties = d
        return checkout_credential_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
