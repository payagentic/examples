from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="RotateKeyResponse")


@_attrs_define
class RotateKeyResponse:
    """Response returned after rotating an agent's API key.

    Attributes:
        agent_id (UUID): Agent ID whose key was rotated. Example: 019433e0-1b3c-7d0a-8e4f-000000000002.
        api_key (str): The new API key (shown only once -- store it securely). Example:
            rp_live_019433e0-1b3c-7d0a-8e4f-000000000099.
        api_key_prefix (str): API key prefix for future identification. Example: rp_live_.
        rotated_at (datetime.datetime): When the new key was generated (ISO 8601). Example: 2025-01-15T12:00:00Z.
    """

    agent_id: UUID
    api_key: str
    api_key_prefix: str
    rotated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_id = str(self.agent_id)

        api_key = self.api_key

        api_key_prefix = self.api_key_prefix

        rotated_at = self.rotated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentId": agent_id,
                "apiKey": api_key,
                "apiKeyPrefix": api_key_prefix,
                "rotatedAt": rotated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_id = UUID(d.pop("agentId"))

        api_key = d.pop("apiKey")

        api_key_prefix = d.pop("apiKeyPrefix")

        rotated_at = isoparse(d.pop("rotatedAt"))

        rotate_key_response = cls(
            agent_id=agent_id,
            api_key=api_key,
            api_key_prefix=api_key_prefix,
            rotated_at=rotated_at,
        )

        rotate_key_response.additional_properties = d
        return rotate_key_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
