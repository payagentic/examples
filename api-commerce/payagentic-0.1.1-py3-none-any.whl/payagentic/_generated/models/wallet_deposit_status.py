from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.wallet_deposit_item import WalletDepositItem


T = TypeVar("T", bound="WalletDepositStatus")


@_attrs_define
class WalletDepositStatus:
    """
    Attributes:
        chain (str):
        currency (str):
        refresh_supported (bool):
        status (str):
        wallet_id (UUID):
        cursor_updated_at (datetime.datetime | None | Unset):
        last_scanned_block (int | None | Unset):
        latest_deposit (None | Unset | WalletDepositItem):
    """

    chain: str
    currency: str
    refresh_supported: bool
    status: str
    wallet_id: UUID
    cursor_updated_at: datetime.datetime | None | Unset = UNSET
    last_scanned_block: int | None | Unset = UNSET
    latest_deposit: None | Unset | WalletDepositItem = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.wallet_deposit_item import WalletDepositItem

        chain = self.chain

        currency = self.currency

        refresh_supported = self.refresh_supported

        status = self.status

        wallet_id = str(self.wallet_id)

        cursor_updated_at: None | str | Unset
        if isinstance(self.cursor_updated_at, Unset):
            cursor_updated_at = UNSET
        elif isinstance(self.cursor_updated_at, datetime.datetime):
            cursor_updated_at = self.cursor_updated_at.isoformat()
        else:
            cursor_updated_at = self.cursor_updated_at

        last_scanned_block: int | None | Unset
        if isinstance(self.last_scanned_block, Unset):
            last_scanned_block = UNSET
        else:
            last_scanned_block = self.last_scanned_block

        latest_deposit: dict[str, Any] | None | Unset
        if isinstance(self.latest_deposit, Unset):
            latest_deposit = UNSET
        elif isinstance(self.latest_deposit, WalletDepositItem):
            latest_deposit = self.latest_deposit.to_dict()
        else:
            latest_deposit = self.latest_deposit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "chain": chain,
                "currency": currency,
                "refreshSupported": refresh_supported,
                "status": status,
                "walletId": wallet_id,
            }
        )
        if cursor_updated_at is not UNSET:
            field_dict["cursorUpdatedAt"] = cursor_updated_at
        if last_scanned_block is not UNSET:
            field_dict["lastScannedBlock"] = last_scanned_block
        if latest_deposit is not UNSET:
            field_dict["latestDeposit"] = latest_deposit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.wallet_deposit_item import WalletDepositItem

        d = dict(src_dict)
        chain = d.pop("chain")

        currency = d.pop("currency")

        refresh_supported = d.pop("refreshSupported")

        status = d.pop("status")

        wallet_id = UUID(d.pop("walletId"))

        def _parse_cursor_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                cursor_updated_at_type_0 = isoparse(data)

                return cursor_updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        cursor_updated_at = _parse_cursor_updated_at(d.pop("cursorUpdatedAt", UNSET))

        def _parse_last_scanned_block(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        last_scanned_block = _parse_last_scanned_block(d.pop("lastScannedBlock", UNSET))

        def _parse_latest_deposit(data: object) -> None | Unset | WalletDepositItem:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                latest_deposit_type_1 = WalletDepositItem.from_dict(data)

                return latest_deposit_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WalletDepositItem, data)

        latest_deposit = _parse_latest_deposit(d.pop("latestDeposit", UNSET))

        wallet_deposit_status = cls(
            chain=chain,
            currency=currency,
            refresh_supported=refresh_supported,
            status=status,
            wallet_id=wallet_id,
            cursor_updated_at=cursor_updated_at,
            last_scanned_block=last_scanned_block,
            latest_deposit=latest_deposit,
        )

        wallet_deposit_status.additional_properties = d
        return wallet_deposit_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
