from enum import Enum


class GatewayEventType4Type(str, Enum):
    ALERT_RAISED = "alert_raised"

    def __str__(self) -> str:
        return str(self.value)
