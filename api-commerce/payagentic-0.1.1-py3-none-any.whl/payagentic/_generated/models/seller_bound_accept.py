from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.seller_bound_accept_extra import SellerBoundAcceptExtra


T = TypeVar("T", bound="SellerBoundAccept")


@_attrs_define
class SellerBoundAccept:
    """
    Attributes:
        amount (str):
        asset (str):
        extra (SellerBoundAcceptExtra):
        max_timeout_seconds (int):
        network (str):
        pay_to (str):
        scheme (str):
    """

    amount: str
    asset: str
    extra: SellerBoundAcceptExtra
    max_timeout_seconds: int
    network: str
    pay_to: str
    scheme: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.seller_bound_accept_extra import SellerBoundAcceptExtra

        amount = self.amount

        asset = self.asset

        extra = self.extra.to_dict()

        max_timeout_seconds = self.max_timeout_seconds

        network = self.network

        pay_to = self.pay_to

        scheme = self.scheme

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "asset": asset,
                "extra": extra,
                "maxTimeoutSeconds": max_timeout_seconds,
                "network": network,
                "payTo": pay_to,
                "scheme": scheme,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.seller_bound_accept_extra import SellerBoundAcceptExtra

        d = dict(src_dict)
        amount = d.pop("amount")

        asset = d.pop("asset")

        extra = SellerBoundAcceptExtra.from_dict(d.pop("extra"))

        max_timeout_seconds = d.pop("maxTimeoutSeconds")

        network = d.pop("network")

        pay_to = d.pop("payTo")

        scheme = d.pop("scheme")

        seller_bound_accept = cls(
            amount=amount,
            asset=asset,
            extra=extra,
            max_timeout_seconds=max_timeout_seconds,
            network=network,
            pay_to=pay_to,
            scheme=scheme,
        )

        seller_bound_accept.additional_properties = d
        return seller_bound_accept

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
