from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="StatsResponse")


@_attrs_define
class StatsResponse:
    """
    Attributes:
        call_count (int):
        currency (str):
        range_ (str):
        total_revenue_micro (int): Transaction amounts in micro units (`amount * 1_000_000`).
    """

    call_count: int
    currency: str
    range_: str
    total_revenue_micro: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        call_count = self.call_count

        currency = self.currency

        range_ = self.range_

        total_revenue_micro = self.total_revenue_micro

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "call_count": call_count,
                "currency": currency,
                "range": range_,
                "total_revenue_micro": total_revenue_micro,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        call_count = d.pop("call_count")

        currency = d.pop("currency")

        range_ = d.pop("range")

        total_revenue_micro = d.pop("total_revenue_micro")

        stats_response = cls(
            call_count=call_count,
            currency=currency,
            range_=range_,
            total_revenue_micro=total_revenue_micro,
        )

        stats_response.additional_properties = d
        return stats_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
