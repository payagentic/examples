from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.merchant_summary import MerchantSummary


T = TypeVar("T", bound="MeResponse")


@_attrs_define
class MeResponse:
    """
    Attributes:
        is_platform_admin (bool): Platform-admin tier (cross-org). Gates admin surfaces like KYB review.
        is_super_admin (bool): Super-admin tier: manages the platform-admin list itself. Granted
            exclusively by the environment allowlist.
        mode (str):
        org_id (UUID):
        principal (str):
        role (str):
        welcome_dismissed (bool): Whether this user has completed or dismissed the first-run welcome
            wizard. Profile state (users.welcome_dismissed_at), not browser state.
        email (None | str | Unset):
        jurisdiction (None | str | Unset):
        merchant (MerchantSummary | None | Unset):
        org_name (None | str | Unset):
        user_id (None | Unset | UUID):
    """

    is_platform_admin: bool
    is_super_admin: bool
    mode: str
    org_id: UUID
    principal: str
    role: str
    welcome_dismissed: bool
    email: None | str | Unset = UNSET
    jurisdiction: None | str | Unset = UNSET
    merchant: MerchantSummary | None | Unset = UNSET
    org_name: None | str | Unset = UNSET
    user_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.merchant_summary import MerchantSummary

        is_platform_admin = self.is_platform_admin

        is_super_admin = self.is_super_admin

        mode = self.mode

        org_id = str(self.org_id)

        principal = self.principal

        role = self.role

        welcome_dismissed = self.welcome_dismissed

        email: None | str | Unset
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        jurisdiction: None | str | Unset
        if isinstance(self.jurisdiction, Unset):
            jurisdiction = UNSET
        else:
            jurisdiction = self.jurisdiction

        merchant: dict[str, Any] | None | Unset
        if isinstance(self.merchant, Unset):
            merchant = UNSET
        elif isinstance(self.merchant, MerchantSummary):
            merchant = self.merchant.to_dict()
        else:
            merchant = self.merchant

        org_name: None | str | Unset
        if isinstance(self.org_name, Unset):
            org_name = UNSET
        else:
            org_name = self.org_name

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        elif isinstance(self.user_id, UUID):
            user_id = str(self.user_id)
        else:
            user_id = self.user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "isPlatformAdmin": is_platform_admin,
                "isSuperAdmin": is_super_admin,
                "mode": mode,
                "orgId": org_id,
                "principal": principal,
                "role": role,
                "welcomeDismissed": welcome_dismissed,
            }
        )
        if email is not UNSET:
            field_dict["email"] = email
        if jurisdiction is not UNSET:
            field_dict["jurisdiction"] = jurisdiction
        if merchant is not UNSET:
            field_dict["merchant"] = merchant
        if org_name is not UNSET:
            field_dict["orgName"] = org_name
        if user_id is not UNSET:
            field_dict["userId"] = user_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.merchant_summary import MerchantSummary

        d = dict(src_dict)
        is_platform_admin = d.pop("isPlatformAdmin")

        is_super_admin = d.pop("isSuperAdmin")

        mode = d.pop("mode")

        org_id = UUID(d.pop("orgId"))

        principal = d.pop("principal")

        role = d.pop("role")

        welcome_dismissed = d.pop("welcomeDismissed")

        def _parse_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        email = _parse_email(d.pop("email", UNSET))

        def _parse_jurisdiction(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        jurisdiction = _parse_jurisdiction(d.pop("jurisdiction", UNSET))

        def _parse_merchant(data: object) -> MerchantSummary | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                merchant_type_1 = MerchantSummary.from_dict(data)

                return merchant_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(MerchantSummary | None | Unset, data)

        merchant = _parse_merchant(d.pop("merchant", UNSET))

        def _parse_org_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        org_name = _parse_org_name(d.pop("orgName", UNSET))

        def _parse_user_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                user_id_type_0 = UUID(data)

                return user_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        me_response = cls(
            is_platform_admin=is_platform_admin,
            is_super_admin=is_super_admin,
            mode=mode,
            org_id=org_id,
            principal=principal,
            role=role,
            welcome_dismissed=welcome_dismissed,
            email=email,
            jurisdiction=jurisdiction,
            merchant=merchant,
            org_name=org_name,
            user_id=user_id,
        )

        me_response.additional_properties = d
        return me_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
