from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.capability_data_policy_input import CapabilityDataPolicyInput
    from ..models.capability_limits_input import CapabilityLimitsInput
    from ..models.capability_price_input import CapabilityPriceInput
    from ..models.capability_transport_input import CapabilityTransportInput
    from ..models.create_capability_draft_request_input_schema import (
        CreateCapabilityDraftRequestInputSchema,
    )
    from ..models.create_capability_draft_request_output_schema import (
        CreateCapabilityDraftRequestOutputSchema,
    )
    from ..models.structured_example_dto import StructuredExampleDto


T = TypeVar("T", bound="CreateCapabilityDraftRequest")


@_attrs_define
class CreateCapabilityDraftRequest:
    """
    Attributes:
        categories (list[str]):
        data_policy (CapabilityDataPolicyInput):
        description (str):
        egress_json_pointers (list[str]):
        examples (list[StructuredExampleDto]):
        input_schema (CreateCapabilityDraftRequestInputSchema):
        limits (CapabilityLimitsInput):
        name (str):
        output_schema (CreateCapabilityDraftRequestOutputSchema):
        price (CapabilityPriceInput):
        private_knowledge (str):
        provider_instructions (str):
        slug (str):
        tags (list[str]):
        transports (CapabilityTransportInput):
    """

    categories: list[str]
    data_policy: CapabilityDataPolicyInput
    description: str
    egress_json_pointers: list[str]
    examples: list[StructuredExampleDto]
    input_schema: CreateCapabilityDraftRequestInputSchema
    limits: CapabilityLimitsInput
    name: str
    output_schema: CreateCapabilityDraftRequestOutputSchema
    price: CapabilityPriceInput
    private_knowledge: str
    provider_instructions: str
    slug: str
    tags: list[str]
    transports: CapabilityTransportInput

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_data_policy_input import CapabilityDataPolicyInput
        from ..models.capability_limits_input import CapabilityLimitsInput
        from ..models.capability_price_input import CapabilityPriceInput
        from ..models.capability_transport_input import CapabilityTransportInput
        from ..models.create_capability_draft_request_input_schema import (
            CreateCapabilityDraftRequestInputSchema,
        )
        from ..models.create_capability_draft_request_output_schema import (
            CreateCapabilityDraftRequestOutputSchema,
        )
        from ..models.structured_example_dto import StructuredExampleDto

        categories = self.categories

        data_policy = self.data_policy.to_dict()

        description = self.description

        egress_json_pointers = self.egress_json_pointers

        examples = []
        for examples_item_data in self.examples:
            examples_item = examples_item_data.to_dict()
            examples.append(examples_item)

        input_schema = self.input_schema.to_dict()

        limits = self.limits.to_dict()

        name = self.name

        output_schema = self.output_schema.to_dict()

        price = self.price.to_dict()

        private_knowledge = self.private_knowledge

        provider_instructions = self.provider_instructions

        slug = self.slug

        tags = self.tags

        transports = self.transports.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "categories": categories,
                "dataPolicy": data_policy,
                "description": description,
                "egressJsonPointers": egress_json_pointers,
                "examples": examples,
                "inputSchema": input_schema,
                "limits": limits,
                "name": name,
                "outputSchema": output_schema,
                "price": price,
                "privateKnowledge": private_knowledge,
                "providerInstructions": provider_instructions,
                "slug": slug,
                "tags": tags,
                "transports": transports,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_data_policy_input import CapabilityDataPolicyInput
        from ..models.capability_limits_input import CapabilityLimitsInput
        from ..models.capability_price_input import CapabilityPriceInput
        from ..models.capability_transport_input import CapabilityTransportInput
        from ..models.create_capability_draft_request_input_schema import (
            CreateCapabilityDraftRequestInputSchema,
        )
        from ..models.create_capability_draft_request_output_schema import (
            CreateCapabilityDraftRequestOutputSchema,
        )
        from ..models.structured_example_dto import StructuredExampleDto

        d = dict(src_dict)
        categories = cast(list[str], d.pop("categories"))

        data_policy = CapabilityDataPolicyInput.from_dict(d.pop("dataPolicy"))

        description = d.pop("description")

        egress_json_pointers = cast(list[str], d.pop("egressJsonPointers"))

        examples = []
        _examples = d.pop("examples")
        for examples_item_data in _examples:
            examples_item = StructuredExampleDto.from_dict(examples_item_data)

            examples.append(examples_item)

        input_schema = CreateCapabilityDraftRequestInputSchema.from_dict(d.pop("inputSchema"))

        limits = CapabilityLimitsInput.from_dict(d.pop("limits"))

        name = d.pop("name")

        output_schema = CreateCapabilityDraftRequestOutputSchema.from_dict(d.pop("outputSchema"))

        price = CapabilityPriceInput.from_dict(d.pop("price"))

        private_knowledge = d.pop("privateKnowledge")

        provider_instructions = d.pop("providerInstructions")

        slug = d.pop("slug")

        tags = cast(list[str], d.pop("tags"))

        transports = CapabilityTransportInput.from_dict(d.pop("transports"))

        create_capability_draft_request = cls(
            categories=categories,
            data_policy=data_policy,
            description=description,
            egress_json_pointers=egress_json_pointers,
            examples=examples,
            input_schema=input_schema,
            limits=limits,
            name=name,
            output_schema=output_schema,
            price=price,
            private_knowledge=private_knowledge,
            provider_instructions=provider_instructions,
            slug=slug,
            tags=tags,
            transports=transports,
        )

        return create_capability_draft_request
