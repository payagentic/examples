from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="CreateApiKeyResponse")


@_attrs_define
class CreateApiKeyResponse:
    """POST response embeds the plaintext `secret` exactly once.

    Attributes:
        created_at (datetime.datetime):
        id (UUID):
        key_type (str):
        name (str):
        organization_id (UUID):
        permissions (list[str]): RBAC is not enforced on a per-key basis yet, but the dashboard
            shows a badge list. Returning `[]` keeps the UI happy.
        prefix (str):
        secret (str): Plaintext key. Show once, store hashed copy server-side.
        expires_at (datetime.datetime | None | Unset):
        last_used_at (datetime.datetime | None | Unset):
    """

    created_at: datetime.datetime
    id: UUID
    key_type: str
    name: str
    organization_id: UUID
    permissions: list[str]
    prefix: str
    secret: str
    expires_at: datetime.datetime | None | Unset = UNSET
    last_used_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        created_at = self.created_at.isoformat()

        id = str(self.id)

        key_type = self.key_type

        name = self.name

        organization_id = str(self.organization_id)

        permissions = self.permissions

        prefix = self.prefix

        secret = self.secret

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        last_used_at: None | str | Unset
        if isinstance(self.last_used_at, Unset):
            last_used_at = UNSET
        elif isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "createdAt": created_at,
                "id": id,
                "keyType": key_type,
                "name": name,
                "organizationId": organization_id,
                "permissions": permissions,
                "prefix": prefix,
                "secret": secret,
            }
        )
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at
        if last_used_at is not UNSET:
            field_dict["lastUsedAt"] = last_used_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        created_at = isoparse(d.pop("createdAt"))

        id = UUID(d.pop("id"))

        key_type = d.pop("keyType")

        name = d.pop("name")

        organization_id = UUID(d.pop("organizationId"))

        permissions = cast(list[str], d.pop("permissions"))

        prefix = d.pop("prefix")

        secret = d.pop("secret")

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        def _parse_last_used_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = isoparse(data)

                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_used_at = _parse_last_used_at(d.pop("lastUsedAt", UNSET))

        create_api_key_response = cls(
            created_at=created_at,
            id=id,
            key_type=key_type,
            name=name,
            organization_id=organization_id,
            permissions=permissions,
            prefix=prefix,
            secret=secret,
            expires_at=expires_at,
            last_used_at=last_used_at,
        )

        create_api_key_response.additional_properties = d
        return create_api_key_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
