from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="MerchantProfileDto")


@_attrs_define
class MerchantProfileDto:
    """
    Attributes:
        business_name (str):
        created_at (datetime.datetime):
        directory_category (list[str]):
        directory_visibility (str):
        id (UUID):
        kyb_status (str):
        kyb_threshold_usdc (int): The per-jurisdiction whole-USDC volume threshold above which an unverified
            merchant must verify to keep paying out. Same source as the tax-id gate.
        live_settlement_usdc (str): Gross rolling-12-month live settlement (whole+fraction USDC) — drives the
            verification limit meter. Always present (zero when no live volume yet).
        mode (str):
        org_id (UUID):
        payout_hold_seconds (int):
        payout_min_amount (str):
        payout_schedule (str):
        state (str):
        tax_id_present (bool): Whether a business Tax ID is on file (the value itself is never exposed).
        updated_at (datetime.datetime):
        agent_fee_bps (int | None | Unset):
        api_base_url (None | str | Unset): Base URL the merchant's priced endpoints live on.
        brand_color (None | str | Unset): `#rrggbb` accent for the directory card.
        brand_display_name (None | str | Unset): Public brand name; falls back to `business_name` when unset.
        chain (None | str | Unset): Chain of the linked payout wallet, e.g. `"base"` | `"polygon"` | `"tron"`.
        directory_description (None | str | Unset):
        jurisdiction (None | str | Unset): Resolved from the latest KYB attestation.
        kyb_required_since (datetime.datetime | None | Unset): When the live-payout volume gate first tripped for this
            unverified
            merchant (sticky). `None` once verified or never crossed.
        logo_url (None | str | Unset): Short-lived presigned URL for the brand logo, or `None` when no logo is
            set. Derived from the stored object key at read time — never persisted.
        merchant_fee_bps (int | None | Unset):
        payout_wallet_address (None | str | Unset): Payout wallet address (on `chain`).
        payout_wallet_id (None | Unset | UUID):
        sanctions_screened_at (datetime.datetime | None | Unset):
        support_email (None | str | Unset):
        support_url (None | str | Unset):
        tax_id_required_since (datetime.datetime | None | Unset): Set when the merchant crossed the settlement threshold
            without a Tax ID;
            drives the dashboard prompt. Cleared when a Tax ID is added.
        tos_accepted_at (datetime.datetime | None | Unset):
        tos_version (None | str | Unset):
        verified_at (datetime.datetime | None | Unset): When the merchant first reached the `verified` tier. Drives the
            "Verified since" line in the verification popover; `None` until verified.
    """

    business_name: str
    created_at: datetime.datetime
    directory_category: list[str]
    directory_visibility: str
    id: UUID
    kyb_status: str
    kyb_threshold_usdc: int
    live_settlement_usdc: str
    mode: str
    org_id: UUID
    payout_hold_seconds: int
    payout_min_amount: str
    payout_schedule: str
    state: str
    tax_id_present: bool
    updated_at: datetime.datetime
    agent_fee_bps: int | None | Unset = UNSET
    api_base_url: None | str | Unset = UNSET
    brand_color: None | str | Unset = UNSET
    brand_display_name: None | str | Unset = UNSET
    chain: None | str | Unset = UNSET
    directory_description: None | str | Unset = UNSET
    jurisdiction: None | str | Unset = UNSET
    kyb_required_since: datetime.datetime | None | Unset = UNSET
    logo_url: None | str | Unset = UNSET
    merchant_fee_bps: int | None | Unset = UNSET
    payout_wallet_address: None | str | Unset = UNSET
    payout_wallet_id: None | Unset | UUID = UNSET
    sanctions_screened_at: datetime.datetime | None | Unset = UNSET
    support_email: None | str | Unset = UNSET
    support_url: None | str | Unset = UNSET
    tax_id_required_since: datetime.datetime | None | Unset = UNSET
    tos_accepted_at: datetime.datetime | None | Unset = UNSET
    tos_version: None | str | Unset = UNSET
    verified_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        business_name = self.business_name

        created_at = self.created_at.isoformat()

        directory_category = self.directory_category

        directory_visibility = self.directory_visibility

        id = str(self.id)

        kyb_status = self.kyb_status

        kyb_threshold_usdc = self.kyb_threshold_usdc

        live_settlement_usdc = self.live_settlement_usdc

        mode = self.mode

        org_id = str(self.org_id)

        payout_hold_seconds = self.payout_hold_seconds

        payout_min_amount = self.payout_min_amount

        payout_schedule = self.payout_schedule

        state = self.state

        tax_id_present = self.tax_id_present

        updated_at = self.updated_at.isoformat()

        agent_fee_bps: int | None | Unset
        if isinstance(self.agent_fee_bps, Unset):
            agent_fee_bps = UNSET
        else:
            agent_fee_bps = self.agent_fee_bps

        api_base_url: None | str | Unset
        if isinstance(self.api_base_url, Unset):
            api_base_url = UNSET
        else:
            api_base_url = self.api_base_url

        brand_color: None | str | Unset
        if isinstance(self.brand_color, Unset):
            brand_color = UNSET
        else:
            brand_color = self.brand_color

        brand_display_name: None | str | Unset
        if isinstance(self.brand_display_name, Unset):
            brand_display_name = UNSET
        else:
            brand_display_name = self.brand_display_name

        chain: None | str | Unset
        if isinstance(self.chain, Unset):
            chain = UNSET
        else:
            chain = self.chain

        directory_description: None | str | Unset
        if isinstance(self.directory_description, Unset):
            directory_description = UNSET
        else:
            directory_description = self.directory_description

        jurisdiction: None | str | Unset
        if isinstance(self.jurisdiction, Unset):
            jurisdiction = UNSET
        else:
            jurisdiction = self.jurisdiction

        kyb_required_since: None | str | Unset
        if isinstance(self.kyb_required_since, Unset):
            kyb_required_since = UNSET
        elif isinstance(self.kyb_required_since, datetime.datetime):
            kyb_required_since = self.kyb_required_since.isoformat()
        else:
            kyb_required_since = self.kyb_required_since

        logo_url: None | str | Unset
        if isinstance(self.logo_url, Unset):
            logo_url = UNSET
        else:
            logo_url = self.logo_url

        merchant_fee_bps: int | None | Unset
        if isinstance(self.merchant_fee_bps, Unset):
            merchant_fee_bps = UNSET
        else:
            merchant_fee_bps = self.merchant_fee_bps

        payout_wallet_address: None | str | Unset
        if isinstance(self.payout_wallet_address, Unset):
            payout_wallet_address = UNSET
        else:
            payout_wallet_address = self.payout_wallet_address

        payout_wallet_id: None | str | Unset
        if isinstance(self.payout_wallet_id, Unset):
            payout_wallet_id = UNSET
        elif isinstance(self.payout_wallet_id, UUID):
            payout_wallet_id = str(self.payout_wallet_id)
        else:
            payout_wallet_id = self.payout_wallet_id

        sanctions_screened_at: None | str | Unset
        if isinstance(self.sanctions_screened_at, Unset):
            sanctions_screened_at = UNSET
        elif isinstance(self.sanctions_screened_at, datetime.datetime):
            sanctions_screened_at = self.sanctions_screened_at.isoformat()
        else:
            sanctions_screened_at = self.sanctions_screened_at

        support_email: None | str | Unset
        if isinstance(self.support_email, Unset):
            support_email = UNSET
        else:
            support_email = self.support_email

        support_url: None | str | Unset
        if isinstance(self.support_url, Unset):
            support_url = UNSET
        else:
            support_url = self.support_url

        tax_id_required_since: None | str | Unset
        if isinstance(self.tax_id_required_since, Unset):
            tax_id_required_since = UNSET
        elif isinstance(self.tax_id_required_since, datetime.datetime):
            tax_id_required_since = self.tax_id_required_since.isoformat()
        else:
            tax_id_required_since = self.tax_id_required_since

        tos_accepted_at: None | str | Unset
        if isinstance(self.tos_accepted_at, Unset):
            tos_accepted_at = UNSET
        elif isinstance(self.tos_accepted_at, datetime.datetime):
            tos_accepted_at = self.tos_accepted_at.isoformat()
        else:
            tos_accepted_at = self.tos_accepted_at

        tos_version: None | str | Unset
        if isinstance(self.tos_version, Unset):
            tos_version = UNSET
        else:
            tos_version = self.tos_version

        verified_at: None | str | Unset
        if isinstance(self.verified_at, Unset):
            verified_at = UNSET
        elif isinstance(self.verified_at, datetime.datetime):
            verified_at = self.verified_at.isoformat()
        else:
            verified_at = self.verified_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "business_name": business_name,
                "created_at": created_at,
                "directory_category": directory_category,
                "directory_visibility": directory_visibility,
                "id": id,
                "kyb_status": kyb_status,
                "kyb_threshold_usdc": kyb_threshold_usdc,
                "live_settlement_usdc": live_settlement_usdc,
                "mode": mode,
                "org_id": org_id,
                "payout_hold_seconds": payout_hold_seconds,
                "payout_min_amount": payout_min_amount,
                "payout_schedule": payout_schedule,
                "state": state,
                "tax_id_present": tax_id_present,
                "updated_at": updated_at,
            }
        )
        if agent_fee_bps is not UNSET:
            field_dict["agent_fee_bps"] = agent_fee_bps
        if api_base_url is not UNSET:
            field_dict["api_base_url"] = api_base_url
        if brand_color is not UNSET:
            field_dict["brand_color"] = brand_color
        if brand_display_name is not UNSET:
            field_dict["brand_display_name"] = brand_display_name
        if chain is not UNSET:
            field_dict["chain"] = chain
        if directory_description is not UNSET:
            field_dict["directory_description"] = directory_description
        if jurisdiction is not UNSET:
            field_dict["jurisdiction"] = jurisdiction
        if kyb_required_since is not UNSET:
            field_dict["kyb_required_since"] = kyb_required_since
        if logo_url is not UNSET:
            field_dict["logo_url"] = logo_url
        if merchant_fee_bps is not UNSET:
            field_dict["merchant_fee_bps"] = merchant_fee_bps
        if payout_wallet_address is not UNSET:
            field_dict["payout_wallet_address"] = payout_wallet_address
        if payout_wallet_id is not UNSET:
            field_dict["payout_wallet_id"] = payout_wallet_id
        if sanctions_screened_at is not UNSET:
            field_dict["sanctions_screened_at"] = sanctions_screened_at
        if support_email is not UNSET:
            field_dict["support_email"] = support_email
        if support_url is not UNSET:
            field_dict["support_url"] = support_url
        if tax_id_required_since is not UNSET:
            field_dict["tax_id_required_since"] = tax_id_required_since
        if tos_accepted_at is not UNSET:
            field_dict["tos_accepted_at"] = tos_accepted_at
        if tos_version is not UNSET:
            field_dict["tos_version"] = tos_version
        if verified_at is not UNSET:
            field_dict["verified_at"] = verified_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        business_name = d.pop("business_name")

        created_at = isoparse(d.pop("created_at"))

        directory_category = cast(list[str], d.pop("directory_category"))

        directory_visibility = d.pop("directory_visibility")

        id = UUID(d.pop("id"))

        kyb_status = d.pop("kyb_status")

        kyb_threshold_usdc = d.pop("kyb_threshold_usdc")

        live_settlement_usdc = d.pop("live_settlement_usdc")

        mode = d.pop("mode")

        org_id = UUID(d.pop("org_id"))

        payout_hold_seconds = d.pop("payout_hold_seconds")

        payout_min_amount = d.pop("payout_min_amount")

        payout_schedule = d.pop("payout_schedule")

        state = d.pop("state")

        tax_id_present = d.pop("tax_id_present")

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_agent_fee_bps(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        agent_fee_bps = _parse_agent_fee_bps(d.pop("agent_fee_bps", UNSET))

        def _parse_api_base_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_base_url = _parse_api_base_url(d.pop("api_base_url", UNSET))

        def _parse_brand_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        brand_color = _parse_brand_color(d.pop("brand_color", UNSET))

        def _parse_brand_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        brand_display_name = _parse_brand_display_name(d.pop("brand_display_name", UNSET))

        def _parse_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chain = _parse_chain(d.pop("chain", UNSET))

        def _parse_directory_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        directory_description = _parse_directory_description(d.pop("directory_description", UNSET))

        def _parse_jurisdiction(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        jurisdiction = _parse_jurisdiction(d.pop("jurisdiction", UNSET))

        def _parse_kyb_required_since(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                kyb_required_since_type_0 = isoparse(data)

                return kyb_required_since_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        kyb_required_since = _parse_kyb_required_since(d.pop("kyb_required_since", UNSET))

        def _parse_logo_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        logo_url = _parse_logo_url(d.pop("logo_url", UNSET))

        def _parse_merchant_fee_bps(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        merchant_fee_bps = _parse_merchant_fee_bps(d.pop("merchant_fee_bps", UNSET))

        def _parse_payout_wallet_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payout_wallet_address = _parse_payout_wallet_address(d.pop("payout_wallet_address", UNSET))

        def _parse_payout_wallet_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                payout_wallet_id_type_0 = UUID(data)

                return payout_wallet_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        payout_wallet_id = _parse_payout_wallet_id(d.pop("payout_wallet_id", UNSET))

        def _parse_sanctions_screened_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                sanctions_screened_at_type_0 = isoparse(data)

                return sanctions_screened_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        sanctions_screened_at = _parse_sanctions_screened_at(d.pop("sanctions_screened_at", UNSET))

        def _parse_support_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        support_email = _parse_support_email(d.pop("support_email", UNSET))

        def _parse_support_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        support_url = _parse_support_url(d.pop("support_url", UNSET))

        def _parse_tax_id_required_since(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                tax_id_required_since_type_0 = isoparse(data)

                return tax_id_required_since_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        tax_id_required_since = _parse_tax_id_required_since(d.pop("tax_id_required_since", UNSET))

        def _parse_tos_accepted_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                tos_accepted_at_type_0 = isoparse(data)

                return tos_accepted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        tos_accepted_at = _parse_tos_accepted_at(d.pop("tos_accepted_at", UNSET))

        def _parse_tos_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tos_version = _parse_tos_version(d.pop("tos_version", UNSET))

        def _parse_verified_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                verified_at_type_0 = isoparse(data)

                return verified_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        verified_at = _parse_verified_at(d.pop("verified_at", UNSET))

        merchant_profile_dto = cls(
            business_name=business_name,
            created_at=created_at,
            directory_category=directory_category,
            directory_visibility=directory_visibility,
            id=id,
            kyb_status=kyb_status,
            kyb_threshold_usdc=kyb_threshold_usdc,
            live_settlement_usdc=live_settlement_usdc,
            mode=mode,
            org_id=org_id,
            payout_hold_seconds=payout_hold_seconds,
            payout_min_amount=payout_min_amount,
            payout_schedule=payout_schedule,
            state=state,
            tax_id_present=tax_id_present,
            updated_at=updated_at,
            agent_fee_bps=agent_fee_bps,
            api_base_url=api_base_url,
            brand_color=brand_color,
            brand_display_name=brand_display_name,
            chain=chain,
            directory_description=directory_description,
            jurisdiction=jurisdiction,
            kyb_required_since=kyb_required_since,
            logo_url=logo_url,
            merchant_fee_bps=merchant_fee_bps,
            payout_wallet_address=payout_wallet_address,
            payout_wallet_id=payout_wallet_id,
            sanctions_screened_at=sanctions_screened_at,
            support_email=support_email,
            support_url=support_url,
            tax_id_required_since=tax_id_required_since,
            tos_accepted_at=tos_accepted_at,
            tos_version=tos_version,
            verified_at=verified_at,
        )

        merchant_profile_dto.additional_properties = d
        return merchant_profile_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
