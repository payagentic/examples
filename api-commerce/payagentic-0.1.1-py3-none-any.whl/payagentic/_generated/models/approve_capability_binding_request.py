from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="ApproveCapabilityBindingRequest")


@_attrs_define
class ApproveCapabilityBindingRequest:
    """
    Attributes:
        authority_confirmed (bool):
    """

    authority_confirmed: bool

    def to_dict(self) -> dict[str, Any]:
        authority_confirmed = self.authority_confirmed

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "authorityConfirmed": authority_confirmed,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        authority_confirmed = d.pop("authorityConfirmed")

        approve_capability_binding_request = cls(
            authority_confirmed=authority_confirmed,
        )

        return approve_capability_binding_request
