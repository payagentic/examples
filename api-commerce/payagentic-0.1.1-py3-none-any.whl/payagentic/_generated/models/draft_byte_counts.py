from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="DraftByteCounts")


@_attrs_define
class DraftByteCounts:
    """
    Attributes:
        private_knowledge (int):
        provider_instructions (int):
        structured_examples (int):
    """

    private_knowledge: int
    provider_instructions: int
    structured_examples: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        private_knowledge = self.private_knowledge

        provider_instructions = self.provider_instructions

        structured_examples = self.structured_examples

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "privateKnowledge": private_knowledge,
                "providerInstructions": provider_instructions,
                "structuredExamples": structured_examples,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        private_knowledge = d.pop("privateKnowledge")

        provider_instructions = d.pop("providerInstructions")

        structured_examples = d.pop("structuredExamples")

        draft_byte_counts = cls(
            private_knowledge=private_knowledge,
            provider_instructions=provider_instructions,
            structured_examples=structured_examples,
        )

        draft_byte_counts.additional_properties = d
        return draft_byte_counts

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
