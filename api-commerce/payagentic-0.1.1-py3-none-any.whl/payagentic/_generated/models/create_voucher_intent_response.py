from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="CreateVoucherIntentResponse")


@_attrs_define
class CreateVoucherIntentResponse:
    """
    Attributes:
        approval_mode (str):
        approval_required (bool):
        checkout_intent_id (UUID):
        status (str):
        voucher_order_id (UUID):
    """

    approval_mode: str
    approval_required: bool
    checkout_intent_id: UUID
    status: str
    voucher_order_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        approval_mode = self.approval_mode

        approval_required = self.approval_required

        checkout_intent_id = str(self.checkout_intent_id)

        status = self.status

        voucher_order_id = str(self.voucher_order_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "approvalMode": approval_mode,
                "approvalRequired": approval_required,
                "checkoutIntentId": checkout_intent_id,
                "status": status,
                "voucherOrderId": voucher_order_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        approval_mode = d.pop("approvalMode")

        approval_required = d.pop("approvalRequired")

        checkout_intent_id = UUID(d.pop("checkoutIntentId"))

        status = d.pop("status")

        voucher_order_id = UUID(d.pop("voucherOrderId"))

        create_voucher_intent_response = cls(
            approval_mode=approval_mode,
            approval_required=approval_required,
            checkout_intent_id=checkout_intent_id,
            status=status,
            voucher_order_id=voucher_order_id,
        )

        create_voucher_intent_response.additional_properties = d
        return create_voucher_intent_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
