from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.blueprint_guardrails import BlueprintGuardrails


T = TypeVar("T", bound="BlueprintProfile")


@_attrs_define
class BlueprintProfile:
    """
    Attributes:
        description (str):
        guardrails (BlueprintGuardrails):
        id (str):
        name (str):
    """

    description: str
    guardrails: BlueprintGuardrails
    id: str
    name: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.blueprint_guardrails import BlueprintGuardrails

        description = self.description

        guardrails = self.guardrails.to_dict()

        id = self.id

        name = self.name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "description": description,
                "guardrails": guardrails,
                "id": id,
                "name": name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blueprint_guardrails import BlueprintGuardrails

        d = dict(src_dict)
        description = d.pop("description")

        guardrails = BlueprintGuardrails.from_dict(d.pop("guardrails"))

        id = d.pop("id")

        name = d.pop("name")

        blueprint_profile = cls(
            description=description,
            guardrails=guardrails,
            id=id,
            name=name,
        )

        blueprint_profile.additional_properties = d
        return blueprint_profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
