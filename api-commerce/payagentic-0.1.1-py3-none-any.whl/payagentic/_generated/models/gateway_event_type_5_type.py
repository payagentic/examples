from enum import Enum


class GatewayEventType5Type(str, Enum):
    APPROVAL_RESOLVED = "approval_resolved"

    def __str__(self) -> str:
        return str(self.value)
