from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.checkout_amounts import CheckoutAmounts
    from ..models.checkout_constraints import CheckoutConstraints
    from ..models.checkout_item_input import CheckoutItemInput
    from ..models.checkout_merchant import CheckoutMerchant


T = TypeVar("T", bound="CreateCheckoutIntentRequest")


@_attrs_define
class CreateCheckoutIntentRequest:
    """
    Attributes:
        amounts (CheckoutAmounts):
        idempotency_key (str):
        items (list[CheckoutItemInput]):
        merchant (CheckoutMerchant):
        wallet_id (UUID):
        agent_id (None | Unset | UUID):
        constraints (CheckoutConstraints | None | Unset):
        metadata (Any | Unset):
        purpose (None | str | Unset):
    """

    amounts: CheckoutAmounts
    idempotency_key: str
    items: list[CheckoutItemInput]
    merchant: CheckoutMerchant
    wallet_id: UUID
    agent_id: None | Unset | UUID = UNSET
    constraints: CheckoutConstraints | None | Unset = UNSET
    metadata: Any | Unset = UNSET
    purpose: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.checkout_amounts import CheckoutAmounts
        from ..models.checkout_constraints import CheckoutConstraints
        from ..models.checkout_item_input import CheckoutItemInput
        from ..models.checkout_merchant import CheckoutMerchant

        amounts = self.amounts.to_dict()

        idempotency_key = self.idempotency_key

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)

        merchant = self.merchant.to_dict()

        wallet_id = str(self.wallet_id)

        agent_id: None | str | Unset
        if isinstance(self.agent_id, Unset):
            agent_id = UNSET
        elif isinstance(self.agent_id, UUID):
            agent_id = str(self.agent_id)
        else:
            agent_id = self.agent_id

        constraints: dict[str, Any] | None | Unset
        if isinstance(self.constraints, Unset):
            constraints = UNSET
        elif isinstance(self.constraints, CheckoutConstraints):
            constraints = self.constraints.to_dict()
        else:
            constraints = self.constraints

        metadata = self.metadata

        purpose: None | str | Unset
        if isinstance(self.purpose, Unset):
            purpose = UNSET
        else:
            purpose = self.purpose

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amounts": amounts,
                "idempotencyKey": idempotency_key,
                "items": items,
                "merchant": merchant,
                "walletId": wallet_id,
            }
        )
        if agent_id is not UNSET:
            field_dict["agentId"] = agent_id
        if constraints is not UNSET:
            field_dict["constraints"] = constraints
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if purpose is not UNSET:
            field_dict["purpose"] = purpose

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.checkout_amounts import CheckoutAmounts
        from ..models.checkout_constraints import CheckoutConstraints
        from ..models.checkout_item_input import CheckoutItemInput
        from ..models.checkout_merchant import CheckoutMerchant

        d = dict(src_dict)
        amounts = CheckoutAmounts.from_dict(d.pop("amounts"))

        idempotency_key = d.pop("idempotencyKey")

        items = []
        _items = d.pop("items")
        for items_item_data in _items:
            items_item = CheckoutItemInput.from_dict(items_item_data)

            items.append(items_item)

        merchant = CheckoutMerchant.from_dict(d.pop("merchant"))

        wallet_id = UUID(d.pop("walletId"))

        def _parse_agent_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                agent_id_type_0 = UUID(data)

                return agent_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        agent_id = _parse_agent_id(d.pop("agentId", UNSET))

        def _parse_constraints(data: object) -> CheckoutConstraints | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                constraints_type_1 = CheckoutConstraints.from_dict(data)

                return constraints_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CheckoutConstraints | None | Unset, data)

        constraints = _parse_constraints(d.pop("constraints", UNSET))

        metadata = d.pop("metadata", UNSET)

        def _parse_purpose(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        purpose = _parse_purpose(d.pop("purpose", UNSET))

        create_checkout_intent_request = cls(
            amounts=amounts,
            idempotency_key=idempotency_key,
            items=items,
            merchant=merchant,
            wallet_id=wallet_id,
            agent_id=agent_id,
            constraints=constraints,
            metadata=metadata,
            purpose=purpose,
        )

        create_checkout_intent_request.additional_properties = d
        return create_checkout_intent_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
