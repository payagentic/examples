from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="WalletResponse")


@_attrs_define
class WalletResponse:
    """Wallet resource returned by the API.

    Attributes:
        address (str): On-chain address on the selected network. EVM wallets use hex addresses;
            Solana and Tron wallets use their native address formats. Example: 0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18.
        balance (str): Current supported stablecoin balance. Example: 1250.50.
        chain (str): Blockchain network. Example: base.
        created_at (datetime.datetime): When the wallet was created (ISO 8601). Example: 2025-01-15T12:00:00Z.
        currency (str): Currency. Example: USDC.
        id (UUID): Unique wallet identifier (`UUIDv7`). Example: 019433e0-1b3c-7d0a-8e4f-000000000010.
        label (str): Human-readable label. Example: Production stablecoin wallet.
        organization_id (UUID): Organization ID this wallet belongs to.
        status (str): Wallet status. Example: active.
        type_ (str): Wallet type: `managed_account` for chain-key wallets, `smart_account` for EVM smart accounts.
            Example: managed_account.
        updated_at (datetime.datetime): When the wallet was last updated (ISO 8601). Example: 2025-01-15T12:00:00Z.
    """

    address: str
    balance: str
    chain: str
    created_at: datetime.datetime
    currency: str
    id: UUID
    label: str
    organization_id: UUID
    status: str
    type_: str
    updated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        address = self.address

        balance = self.balance

        chain = self.chain

        created_at = self.created_at.isoformat()

        currency = self.currency

        id = str(self.id)

        label = self.label

        organization_id = str(self.organization_id)

        status = self.status

        type_ = self.type_

        updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "address": address,
                "balance": balance,
                "chain": chain,
                "createdAt": created_at,
                "currency": currency,
                "id": id,
                "label": label,
                "organizationId": organization_id,
                "status": status,
                "type": type_,
                "updatedAt": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address = d.pop("address")

        balance = d.pop("balance")

        chain = d.pop("chain")

        created_at = isoparse(d.pop("createdAt"))

        currency = d.pop("currency")

        id = UUID(d.pop("id"))

        label = d.pop("label")

        organization_id = UUID(d.pop("organizationId"))

        status = d.pop("status")

        type_ = d.pop("type")

        updated_at = isoparse(d.pop("updatedAt"))

        wallet_response = cls(
            address=address,
            balance=balance,
            chain=chain,
            created_at=created_at,
            currency=currency,
            id=id,
            label=label,
            organization_id=organization_id,
            status=status,
            type_=type_,
            updated_at=updated_at,
        )

        wallet_response.additional_properties = d
        return wallet_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
