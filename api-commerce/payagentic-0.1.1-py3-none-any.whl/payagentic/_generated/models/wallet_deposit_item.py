from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="WalletDepositItem")


@_attrs_define
class WalletDepositItem:
    """
    Attributes:
        amount (str):
        block_number (int):
        chain (str):
        currency (str):
        from_address (str):
        id (UUID):
        observed_at (datetime.datetime):
        to_address (str):
        tx_hash (str):
        explorer_url (None | str | Unset):
    """

    amount: str
    block_number: int
    chain: str
    currency: str
    from_address: str
    id: UUID
    observed_at: datetime.datetime
    to_address: str
    tx_hash: str
    explorer_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        block_number = self.block_number

        chain = self.chain

        currency = self.currency

        from_address = self.from_address

        id = str(self.id)

        observed_at = self.observed_at.isoformat()

        to_address = self.to_address

        tx_hash = self.tx_hash

        explorer_url: None | str | Unset
        if isinstance(self.explorer_url, Unset):
            explorer_url = UNSET
        else:
            explorer_url = self.explorer_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "blockNumber": block_number,
                "chain": chain,
                "currency": currency,
                "fromAddress": from_address,
                "id": id,
                "observedAt": observed_at,
                "toAddress": to_address,
                "txHash": tx_hash,
            }
        )
        if explorer_url is not UNSET:
            field_dict["explorerUrl"] = explorer_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        block_number = d.pop("blockNumber")

        chain = d.pop("chain")

        currency = d.pop("currency")

        from_address = d.pop("fromAddress")

        id = UUID(d.pop("id"))

        observed_at = isoparse(d.pop("observedAt"))

        to_address = d.pop("toAddress")

        tx_hash = d.pop("txHash")

        def _parse_explorer_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        explorer_url = _parse_explorer_url(d.pop("explorerUrl", UNSET))

        wallet_deposit_item = cls(
            amount=amount,
            block_number=block_number,
            chain=chain,
            currency=currency,
            from_address=from_address,
            id=id,
            observed_at=observed_at,
            to_address=to_address,
            tx_hash=tx_hash,
            explorer_url=explorer_url,
        )

        wallet_deposit_item.additional_properties = d
        return wallet_deposit_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
