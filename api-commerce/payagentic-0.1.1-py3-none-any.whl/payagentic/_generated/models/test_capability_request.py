from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.test_capability_request_input import TestCapabilityRequestInput


T = TypeVar("T", bound="TestCapabilityRequest")


@_attrs_define
class TestCapabilityRequest:
    """
    Attributes:
        draft_revision_id (UUID):
        implementation_checksum (str):
        input_ (TestCapabilityRequestInput):
        revision_checksum (str):
    """

    draft_revision_id: UUID
    implementation_checksum: str
    input_: TestCapabilityRequestInput
    revision_checksum: str

    def to_dict(self) -> dict[str, Any]:
        from ..models.test_capability_request_input import TestCapabilityRequestInput

        draft_revision_id = str(self.draft_revision_id)

        implementation_checksum = self.implementation_checksum

        input_ = self.input_.to_dict()

        revision_checksum = self.revision_checksum

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "draftRevisionId": draft_revision_id,
                "implementationChecksum": implementation_checksum,
                "input": input_,
                "revisionChecksum": revision_checksum,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_capability_request_input import TestCapabilityRequestInput

        d = dict(src_dict)
        draft_revision_id = UUID(d.pop("draftRevisionId"))

        implementation_checksum = d.pop("implementationChecksum")

        input_ = TestCapabilityRequestInput.from_dict(d.pop("input"))

        revision_checksum = d.pop("revisionChecksum")

        test_capability_request = cls(
            draft_revision_id=draft_revision_id,
            implementation_checksum=implementation_checksum,
            input_=input_,
            revision_checksum=revision_checksum,
        )

        return test_capability_request
