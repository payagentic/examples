from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field
import json
from .. import types

from ..types import UNSET, Unset

from ..types import File, FileTypes
from io import BytesIO


T = TypeVar("T", bound="UploadKybDocumentForm")


@_attrs_define
class UploadKybDocumentForm:
    """Multipart form body for `POST /v1/merchants/me/kyb/documents`.

    Documentation-only marker type — the actual handler streams the multipart
    payload directly via `axum::extract::Multipart`. Fields: `document_type`
    (one of `incorporation`, `owner_id`, `proof_of_address`) and `file`
    (binary upload).

        Attributes:
            document_type (str): Document category (`incorporation`, `owner_id`, or `proof_of_address`).
            file (File): Binary file contents.
    """

    document_type: str
    file: File
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        document_type = self.document_type

        file = self.file.to_tuple()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "document_type": document_type,
                "file": file,
            }
        )

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("document_type", (None, str(self.document_type).encode(), "text/plain")))

        files.append(("file", self.file.to_tuple()))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        document_type = d.pop("document_type")

        file = File(payload=BytesIO(d.pop("file")))

        upload_kyb_document_form = cls(
            document_type=document_type,
            file=file,
        )

        upload_kyb_document_form.additional_properties = d
        return upload_kyb_document_form

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
