from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.capability_price_response import CapabilityPriceResponse
    from ..models.capability_version_response_manifest import CapabilityVersionResponseManifest


T = TypeVar("T", bound="CapabilityVersionResponse")


@_attrs_define
class CapabilityVersionResponse:
    """
    Attributes:
        capability_id (UUID):
        id (UUID):
        input_schema_checksum (str):
        manifest (CapabilityVersionResponseManifest):
        manifest_checksum (str):
        output_schema_checksum (str):
        price (CapabilityPriceResponse):
        provider_slug (str):
        published_at (datetime.datetime):
        semantic_version (str):
        deprecated_at (datetime.datetime | None | Unset):
        deprecation_reason (None | str | Unset):
        suspended_at (datetime.datetime | None | Unset):
        suspension_reason (None | str | Unset):
    """

    capability_id: UUID
    id: UUID
    input_schema_checksum: str
    manifest: CapabilityVersionResponseManifest
    manifest_checksum: str
    output_schema_checksum: str
    price: CapabilityPriceResponse
    provider_slug: str
    published_at: datetime.datetime
    semantic_version: str
    deprecated_at: datetime.datetime | None | Unset = UNSET
    deprecation_reason: None | str | Unset = UNSET
    suspended_at: datetime.datetime | None | Unset = UNSET
    suspension_reason: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_price_response import CapabilityPriceResponse
        from ..models.capability_version_response_manifest import CapabilityVersionResponseManifest

        capability_id = str(self.capability_id)

        id = str(self.id)

        input_schema_checksum = self.input_schema_checksum

        manifest = self.manifest.to_dict()

        manifest_checksum = self.manifest_checksum

        output_schema_checksum = self.output_schema_checksum

        price = self.price.to_dict()

        provider_slug = self.provider_slug

        published_at = self.published_at.isoformat()

        semantic_version = self.semantic_version

        deprecated_at: None | str | Unset
        if isinstance(self.deprecated_at, Unset):
            deprecated_at = UNSET
        elif isinstance(self.deprecated_at, datetime.datetime):
            deprecated_at = self.deprecated_at.isoformat()
        else:
            deprecated_at = self.deprecated_at

        deprecation_reason: None | str | Unset
        if isinstance(self.deprecation_reason, Unset):
            deprecation_reason = UNSET
        else:
            deprecation_reason = self.deprecation_reason

        suspended_at: None | str | Unset
        if isinstance(self.suspended_at, Unset):
            suspended_at = UNSET
        elif isinstance(self.suspended_at, datetime.datetime):
            suspended_at = self.suspended_at.isoformat()
        else:
            suspended_at = self.suspended_at

        suspension_reason: None | str | Unset
        if isinstance(self.suspension_reason, Unset):
            suspension_reason = UNSET
        else:
            suspension_reason = self.suspension_reason

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "capabilityId": capability_id,
                "id": id,
                "inputSchemaChecksum": input_schema_checksum,
                "manifest": manifest,
                "manifestChecksum": manifest_checksum,
                "outputSchemaChecksum": output_schema_checksum,
                "price": price,
                "providerSlug": provider_slug,
                "publishedAt": published_at,
                "semanticVersion": semantic_version,
            }
        )
        if deprecated_at is not UNSET:
            field_dict["deprecatedAt"] = deprecated_at
        if deprecation_reason is not UNSET:
            field_dict["deprecationReason"] = deprecation_reason
        if suspended_at is not UNSET:
            field_dict["suspendedAt"] = suspended_at
        if suspension_reason is not UNSET:
            field_dict["suspensionReason"] = suspension_reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_price_response import CapabilityPriceResponse
        from ..models.capability_version_response_manifest import CapabilityVersionResponseManifest

        d = dict(src_dict)
        capability_id = UUID(d.pop("capabilityId"))

        id = UUID(d.pop("id"))

        input_schema_checksum = d.pop("inputSchemaChecksum")

        manifest = CapabilityVersionResponseManifest.from_dict(d.pop("manifest"))

        manifest_checksum = d.pop("manifestChecksum")

        output_schema_checksum = d.pop("outputSchemaChecksum")

        price = CapabilityPriceResponse.from_dict(d.pop("price"))

        provider_slug = d.pop("providerSlug")

        published_at = isoparse(d.pop("publishedAt"))

        semantic_version = d.pop("semanticVersion")

        def _parse_deprecated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                deprecated_at_type_0 = isoparse(data)

                return deprecated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        deprecated_at = _parse_deprecated_at(d.pop("deprecatedAt", UNSET))

        def _parse_deprecation_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        deprecation_reason = _parse_deprecation_reason(d.pop("deprecationReason", UNSET))

        def _parse_suspended_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                suspended_at_type_0 = isoparse(data)

                return suspended_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        suspended_at = _parse_suspended_at(d.pop("suspendedAt", UNSET))

        def _parse_suspension_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        suspension_reason = _parse_suspension_reason(d.pop("suspensionReason", UNSET))

        capability_version_response = cls(
            capability_id=capability_id,
            id=id,
            input_schema_checksum=input_schema_checksum,
            manifest=manifest,
            manifest_checksum=manifest_checksum,
            output_schema_checksum=output_schema_checksum,
            price=price,
            provider_slug=provider_slug,
            published_at=published_at,
            semantic_version=semantic_version,
            deprecated_at=deprecated_at,
            deprecation_reason=deprecation_reason,
            suspended_at=suspended_at,
            suspension_reason=suspension_reason,
        )

        capability_version_response.additional_properties = d
        return capability_version_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
