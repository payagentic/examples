from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="AgentResponse")


@_attrs_define
class AgentResponse:
    """Agent resource returned by the API.

    Attributes:
        api_key_prefix (str): API key prefix (first 8 chars) for identification. Example: rp_live_.
        created_at (datetime.datetime): When the agent was created (ISO 8601). Example: 2025-01-15T12:00:00Z.
        id (UUID): Unique agent identifier (`UUIDv7`). Example: 019433e0-1b3c-7d0a-8e4f-000000000002.
        metadata (Any): Arbitrary metadata.
        name (str): Agent name. Example: price-checker-bot.
        organization_id (UUID): Organization ID this agent belongs to.
        passport_subject (str): Stable opaque Agent Passport subject identifier ("ap_" + 32 hex
            chars). Independent of `id` by design -- this is the `sub` claim a
            verifier sees in the agent's passport JWT, never the internal UUID. Example:
            ap_0123456789abcdef0123456789abcdef.
        policy_ids (list[str]): Policy IDs attached to this agent.
        status (str): Agent status. Example: active.
        updated_at (datetime.datetime): When the agent was last updated (ISO 8601). Example: 2025-01-15T12:00:00Z.
        wallet_ids (list[str]): Wallet IDs this agent is allowed to spend from.
        description (None | str | Unset): Agent description. Example: Fetches commodity prices from third-party APIs.
        kya_tier (int | None | Unset): Know-Your-Agent trust tier (0-3), derived from the owning org's
            KYC/mandate state at read time. `null` when the tier wasn't
            computed for this response (only `GET /v1/agents/{id}` populates
            it) or when the org row is missing. Example: 2.
        wallet_id (None | Unset | UUID): Primary wallet the agent pays from by default, or `null` when the agent
            has no linked wallet yet. Populated from the `agent_wallets` primary link. Example:
            019433e0-1b3c-7d0a-8e4f-000000000010.
    """

    api_key_prefix: str
    created_at: datetime.datetime
    id: UUID
    metadata: Any
    name: str
    organization_id: UUID
    passport_subject: str
    policy_ids: list[str]
    status: str
    updated_at: datetime.datetime
    wallet_ids: list[str]
    description: None | str | Unset = UNSET
    kya_tier: int | None | Unset = UNSET
    wallet_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        api_key_prefix = self.api_key_prefix

        created_at = self.created_at.isoformat()

        id = str(self.id)

        metadata = self.metadata

        name = self.name

        organization_id = str(self.organization_id)

        passport_subject = self.passport_subject

        policy_ids = self.policy_ids

        status = self.status

        updated_at = self.updated_at.isoformat()

        wallet_ids = self.wallet_ids

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        kya_tier: int | None | Unset
        if isinstance(self.kya_tier, Unset):
            kya_tier = UNSET
        else:
            kya_tier = self.kya_tier

        wallet_id: None | str | Unset
        if isinstance(self.wallet_id, Unset):
            wallet_id = UNSET
        elif isinstance(self.wallet_id, UUID):
            wallet_id = str(self.wallet_id)
        else:
            wallet_id = self.wallet_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "apiKeyPrefix": api_key_prefix,
                "createdAt": created_at,
                "id": id,
                "metadata": metadata,
                "name": name,
                "organizationId": organization_id,
                "passportSubject": passport_subject,
                "policyIds": policy_ids,
                "status": status,
                "updatedAt": updated_at,
                "walletIds": wallet_ids,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if kya_tier is not UNSET:
            field_dict["kyaTier"] = kya_tier
        if wallet_id is not UNSET:
            field_dict["walletId"] = wallet_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api_key_prefix = d.pop("apiKeyPrefix")

        created_at = isoparse(d.pop("createdAt"))

        id = UUID(d.pop("id"))

        metadata = d.pop("metadata")

        name = d.pop("name")

        organization_id = UUID(d.pop("organizationId"))

        passport_subject = d.pop("passportSubject")

        policy_ids = cast(list[str], d.pop("policyIds"))

        status = d.pop("status")

        updated_at = isoparse(d.pop("updatedAt"))

        wallet_ids = cast(list[str], d.pop("walletIds"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_kya_tier(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        kya_tier = _parse_kya_tier(d.pop("kyaTier", UNSET))

        def _parse_wallet_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                wallet_id_type_0 = UUID(data)

                return wallet_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        wallet_id = _parse_wallet_id(d.pop("walletId", UNSET))

        agent_response = cls(
            api_key_prefix=api_key_prefix,
            created_at=created_at,
            id=id,
            metadata=metadata,
            name=name,
            organization_id=organization_id,
            passport_subject=passport_subject,
            policy_ids=policy_ids,
            status=status,
            updated_at=updated_at,
            wallet_ids=wallet_ids,
            description=description,
            kya_tier=kya_tier,
            wallet_id=wallet_id,
        )

        agent_response.additional_properties = d
        return agent_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
