from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="LinkWalletRequest")


@_attrs_define
class LinkWalletRequest:
    """
    Attributes:
        address (str):
        chain_id (str):
        ens_name (None | str | Unset):
    """

    address: str
    chain_id: str
    ens_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        address = self.address

        chain_id = self.chain_id

        ens_name: None | str | Unset
        if isinstance(self.ens_name, Unset):
            ens_name = UNSET
        else:
            ens_name = self.ens_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "address": address,
                "chain_id": chain_id,
            }
        )
        if ens_name is not UNSET:
            field_dict["ens_name"] = ens_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address = d.pop("address")

        chain_id = d.pop("chain_id")

        def _parse_ens_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ens_name = _parse_ens_name(d.pop("ens_name", UNSET))

        link_wallet_request = cls(
            address=address,
            chain_id=chain_id,
            ens_name=ens_name,
        )

        link_wallet_request.additional_properties = d
        return link_wallet_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
