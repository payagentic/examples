from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="ProposePaymentRequest")


@_attrs_define
class ProposePaymentRequest:
    """Request body for proposing an x402 payment.

    The agent sends this after receiving a 402 response from a resource
    server. The gateway forwards it to the payments orchestrator for
    policy evaluation, signing, and on-chain settlement.

        Attributes:
            idempotency_key (str): Client-generated idempotency key scoped to the caller and request body. Example:
                019433e0-1b3c-7d0a-8e4f-000000000099.
            payment_requirements (str): The x402 `PaymentRequirements` header value from the upstream 402. Example:
                base64-encoded-payment-requirements.
            resource_url (str): The resource URL that returned 402. Example: https://api.example.com/v1/data.
            mandate_geo (None | str | Unset): Optional mandate geo claim, normally ISO 3166-1 alpha-2. Example: US.
            mandate_mcc (None | str | Unset): Optional mandate MCC claim used by mandate enforcement. Example: 5732.
            mandate_merchant_id (None | str | Unset): Optional merchant identifier for mandate scope checks. Example:
                merchant_amazon.
            max_amount (None | str | Unset): Maximum amount the caller is willing to pay (optional cap). Example: 10.00.
            wallet_id (None | Unset | UUID): Source wallet ID. Optional: when omitted, the payments orchestrator uses
                the calling agent's primary linked wallet. Example: 019433e0-1b3c-7d0a-8e4f-000000000010.
    """

    idempotency_key: str
    payment_requirements: str
    resource_url: str
    mandate_geo: None | str | Unset = UNSET
    mandate_mcc: None | str | Unset = UNSET
    mandate_merchant_id: None | str | Unset = UNSET
    max_amount: None | str | Unset = UNSET
    wallet_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        idempotency_key = self.idempotency_key

        payment_requirements = self.payment_requirements

        resource_url = self.resource_url

        mandate_geo: None | str | Unset
        if isinstance(self.mandate_geo, Unset):
            mandate_geo = UNSET
        else:
            mandate_geo = self.mandate_geo

        mandate_mcc: None | str | Unset
        if isinstance(self.mandate_mcc, Unset):
            mandate_mcc = UNSET
        else:
            mandate_mcc = self.mandate_mcc

        mandate_merchant_id: None | str | Unset
        if isinstance(self.mandate_merchant_id, Unset):
            mandate_merchant_id = UNSET
        else:
            mandate_merchant_id = self.mandate_merchant_id

        max_amount: None | str | Unset
        if isinstance(self.max_amount, Unset):
            max_amount = UNSET
        else:
            max_amount = self.max_amount

        wallet_id: None | str | Unset
        if isinstance(self.wallet_id, Unset):
            wallet_id = UNSET
        elif isinstance(self.wallet_id, UUID):
            wallet_id = str(self.wallet_id)
        else:
            wallet_id = self.wallet_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "idempotency_key": idempotency_key,
                "payment_requirements": payment_requirements,
                "resource_url": resource_url,
            }
        )
        if mandate_geo is not UNSET:
            field_dict["mandate_geo"] = mandate_geo
        if mandate_mcc is not UNSET:
            field_dict["mandate_mcc"] = mandate_mcc
        if mandate_merchant_id is not UNSET:
            field_dict["mandate_merchant_id"] = mandate_merchant_id
        if max_amount is not UNSET:
            field_dict["max_amount"] = max_amount
        if wallet_id is not UNSET:
            field_dict["wallet_id"] = wallet_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        idempotency_key = d.pop("idempotency_key")

        payment_requirements = d.pop("payment_requirements")

        resource_url = d.pop("resource_url")

        def _parse_mandate_geo(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mandate_geo = _parse_mandate_geo(d.pop("mandate_geo", UNSET))

        def _parse_mandate_mcc(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mandate_mcc = _parse_mandate_mcc(d.pop("mandate_mcc", UNSET))

        def _parse_mandate_merchant_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mandate_merchant_id = _parse_mandate_merchant_id(d.pop("mandate_merchant_id", UNSET))

        def _parse_max_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        max_amount = _parse_max_amount(d.pop("max_amount", UNSET))

        def _parse_wallet_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                wallet_id_type_0 = UUID(data)

                return wallet_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        wallet_id = _parse_wallet_id(d.pop("wallet_id", UNSET))

        propose_payment_request = cls(
            idempotency_key=idempotency_key,
            payment_requirements=payment_requirements,
            resource_url=resource_url,
            mandate_geo=mandate_geo,
            mandate_mcc=mandate_mcc,
            mandate_merchant_id=mandate_merchant_id,
            max_amount=max_amount,
            wallet_id=wallet_id,
        )

        propose_payment_request.additional_properties = d
        return propose_payment_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
