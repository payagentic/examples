from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.policy_response_rules import PolicyResponseRules


T = TypeVar("T", bound="PolicyResponse")


@_attrs_define
class PolicyResponse:
    """Policy resource returned by the API.

    Attributes:
        active (bool): Whether this policy is currently active. Example: True.
        agent_ids (list[str]): IDs of agents bound to this policy.
        created_at (datetime.datetime): When the policy was created (ISO 8601). Example: 2025-01-15T12:00:00Z.
        id (UUID): Policy identifier (`UUIDv7`). Example: 019433e0-1b3c-7d0a-8e4f-000000000040.
        name (str): Policy name. Example: Daily spend cap.
        rules (PolicyResponseRules): Policy rules.
        description (None | str | Unset): Policy description. Example: Limit agent spending to 100 stablecoin units per
            day.
    """

    active: bool
    agent_ids: list[str]
    created_at: datetime.datetime
    id: UUID
    name: str
    rules: PolicyResponseRules
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.policy_response_rules import PolicyResponseRules

        active = self.active

        agent_ids = self.agent_ids

        created_at = self.created_at.isoformat()

        id = str(self.id)

        name = self.name

        rules = self.rules.to_dict()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "active": active,
                "agent_ids": agent_ids,
                "created_at": created_at,
                "id": id,
                "name": name,
                "rules": rules,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.policy_response_rules import PolicyResponseRules

        d = dict(src_dict)
        active = d.pop("active")

        agent_ids = cast(list[str], d.pop("agent_ids"))

        created_at = isoparse(d.pop("created_at"))

        id = UUID(d.pop("id"))

        name = d.pop("name")

        rules = PolicyResponseRules.from_dict(d.pop("rules"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        policy_response = cls(
            active=active,
            agent_ids=agent_ids,
            created_at=created_at,
            id=id,
            name=name,
            rules=rules,
            description=description,
        )

        policy_response.additional_properties = d
        return policy_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
