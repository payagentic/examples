from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.gateway_event_type_0_type import GatewayEventType0Type
from uuid import UUID


T = TypeVar("T", bound="GatewayEventType0")


@_attrs_define
class GatewayEventType0:
    """
    Attributes:
        approval_id (UUID):
        organization_id (UUID):
        type_ (GatewayEventType0Type):
    """

    approval_id: UUID
    organization_id: UUID
    type_: GatewayEventType0Type
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        approval_id = str(self.approval_id)

        organization_id = str(self.organization_id)

        type_ = self.type_.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "approval_id": approval_id,
                "organization_id": organization_id,
                "type": type_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        approval_id = UUID(d.pop("approval_id"))

        organization_id = UUID(d.pop("organization_id"))

        type_ = GatewayEventType0Type(d.pop("type"))

        gateway_event_type_0 = cls(
            approval_id=approval_id,
            organization_id=organization_id,
            type_=type_,
        )

        gateway_event_type_0.additional_properties = d
        return gateway_event_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
