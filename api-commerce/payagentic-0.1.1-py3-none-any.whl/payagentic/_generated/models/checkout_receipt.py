from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="CheckoutReceipt")


@_attrs_define
class CheckoutReceipt:
    """
    Attributes:
        created_at (datetime.datetime):
        currency (str):
        id (UUID):
        total (str):
        merchant_receipt_ref (None | str | Unset):
        order_id (None | str | Unset):
        receipt_url (None | str | Unset):
    """

    created_at: datetime.datetime
    currency: str
    id: UUID
    total: str
    merchant_receipt_ref: None | str | Unset = UNSET
    order_id: None | str | Unset = UNSET
    receipt_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        created_at = self.created_at.isoformat()

        currency = self.currency

        id = str(self.id)

        total = self.total

        merchant_receipt_ref: None | str | Unset
        if isinstance(self.merchant_receipt_ref, Unset):
            merchant_receipt_ref = UNSET
        else:
            merchant_receipt_ref = self.merchant_receipt_ref

        order_id: None | str | Unset
        if isinstance(self.order_id, Unset):
            order_id = UNSET
        else:
            order_id = self.order_id

        receipt_url: None | str | Unset
        if isinstance(self.receipt_url, Unset):
            receipt_url = UNSET
        else:
            receipt_url = self.receipt_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "createdAt": created_at,
                "currency": currency,
                "id": id,
                "total": total,
            }
        )
        if merchant_receipt_ref is not UNSET:
            field_dict["merchantReceiptRef"] = merchant_receipt_ref
        if order_id is not UNSET:
            field_dict["orderId"] = order_id
        if receipt_url is not UNSET:
            field_dict["receiptUrl"] = receipt_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        created_at = isoparse(d.pop("createdAt"))

        currency = d.pop("currency")

        id = UUID(d.pop("id"))

        total = d.pop("total")

        def _parse_merchant_receipt_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        merchant_receipt_ref = _parse_merchant_receipt_ref(d.pop("merchantReceiptRef", UNSET))

        def _parse_order_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        order_id = _parse_order_id(d.pop("orderId", UNSET))

        def _parse_receipt_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        receipt_url = _parse_receipt_url(d.pop("receiptUrl", UNSET))

        checkout_receipt = cls(
            created_at=created_at,
            currency=currency,
            id=id,
            total=total,
            merchant_receipt_ref=merchant_receipt_ref,
            order_id=order_id,
            receipt_url=receipt_url,
        )

        checkout_receipt.additional_properties = d
        return checkout_receipt

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
