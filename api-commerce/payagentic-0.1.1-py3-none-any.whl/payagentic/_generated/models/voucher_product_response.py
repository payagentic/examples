from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="VoucherProductResponse")


@_attrs_define
class VoucherProductResponse:
    """
    Attributes:
        category (str):
        country (str):
        currency (str):
        fixed_denominations (list[str]):
        merchant_name (str):
        provider (str):
        provider_product_id (str):
        recipient_type (str):
        redemption_type (str):
        status (str):
        warnings (list[str]):
        max_amount (None | str | Unset):
        merchant_domain (None | str | Unset):
        min_amount (None | str | Unset):
    """

    category: str
    country: str
    currency: str
    fixed_denominations: list[str]
    merchant_name: str
    provider: str
    provider_product_id: str
    recipient_type: str
    redemption_type: str
    status: str
    warnings: list[str]
    max_amount: None | str | Unset = UNSET
    merchant_domain: None | str | Unset = UNSET
    min_amount: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        category = self.category

        country = self.country

        currency = self.currency

        fixed_denominations = self.fixed_denominations

        merchant_name = self.merchant_name

        provider = self.provider

        provider_product_id = self.provider_product_id

        recipient_type = self.recipient_type

        redemption_type = self.redemption_type

        status = self.status

        warnings = self.warnings

        max_amount: None | str | Unset
        if isinstance(self.max_amount, Unset):
            max_amount = UNSET
        else:
            max_amount = self.max_amount

        merchant_domain: None | str | Unset
        if isinstance(self.merchant_domain, Unset):
            merchant_domain = UNSET
        else:
            merchant_domain = self.merchant_domain

        min_amount: None | str | Unset
        if isinstance(self.min_amount, Unset):
            min_amount = UNSET
        else:
            min_amount = self.min_amount

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "category": category,
                "country": country,
                "currency": currency,
                "fixedDenominations": fixed_denominations,
                "merchantName": merchant_name,
                "provider": provider,
                "providerProductId": provider_product_id,
                "recipientType": recipient_type,
                "redemptionType": redemption_type,
                "status": status,
                "warnings": warnings,
            }
        )
        if max_amount is not UNSET:
            field_dict["maxAmount"] = max_amount
        if merchant_domain is not UNSET:
            field_dict["merchantDomain"] = merchant_domain
        if min_amount is not UNSET:
            field_dict["minAmount"] = min_amount

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        category = d.pop("category")

        country = d.pop("country")

        currency = d.pop("currency")

        fixed_denominations = cast(list[str], d.pop("fixedDenominations"))

        merchant_name = d.pop("merchantName")

        provider = d.pop("provider")

        provider_product_id = d.pop("providerProductId")

        recipient_type = d.pop("recipientType")

        redemption_type = d.pop("redemptionType")

        status = d.pop("status")

        warnings = cast(list[str], d.pop("warnings"))

        def _parse_max_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        max_amount = _parse_max_amount(d.pop("maxAmount", UNSET))

        def _parse_merchant_domain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        merchant_domain = _parse_merchant_domain(d.pop("merchantDomain", UNSET))

        def _parse_min_amount(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        min_amount = _parse_min_amount(d.pop("minAmount", UNSET))

        voucher_product_response = cls(
            category=category,
            country=country,
            currency=currency,
            fixed_denominations=fixed_denominations,
            merchant_name=merchant_name,
            provider=provider,
            provider_product_id=provider_product_id,
            recipient_type=recipient_type,
            redemption_type=redemption_type,
            status=status,
            warnings=warnings,
            max_amount=max_amount,
            merchant_domain=merchant_domain,
            min_amount=min_amount,
        )

        voucher_product_response.additional_properties = d
        return voucher_product_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
