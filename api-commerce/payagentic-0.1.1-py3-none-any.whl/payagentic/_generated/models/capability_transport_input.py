from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CapabilityTransportInput")


@_attrs_define
class CapabilityTransportInput:
    """
    Attributes:
        http (bool):
        mcp (bool):
    """

    http: bool
    mcp: bool

    def to_dict(self) -> dict[str, Any]:
        http = self.http

        mcp = self.mcp

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "http": http,
                "mcp": mcp,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        http = d.pop("http")

        mcp = d.pop("mcp")

        capability_transport_input = cls(
            http=http,
            mcp=mcp,
        )

        return capability_transport_input
