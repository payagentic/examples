from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="ProviderSettingsResponse")


@_attrs_define
class ProviderSettingsResponse:
    """
    Attributes:
        configured (bool):
        editable_fields (list[str]):
        enabled (bool):
        provider_key (str):
        base_url (None | str | Unset):
        config_source (None | str | Unset):
    """

    configured: bool
    editable_fields: list[str]
    enabled: bool
    provider_key: str
    base_url: None | str | Unset = UNSET
    config_source: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        configured = self.configured

        editable_fields = self.editable_fields

        enabled = self.enabled

        provider_key = self.provider_key

        base_url: None | str | Unset
        if isinstance(self.base_url, Unset):
            base_url = UNSET
        else:
            base_url = self.base_url

        config_source: None | str | Unset
        if isinstance(self.config_source, Unset):
            config_source = UNSET
        else:
            config_source = self.config_source

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "configured": configured,
                "editableFields": editable_fields,
                "enabled": enabled,
                "providerKey": provider_key,
            }
        )
        if base_url is not UNSET:
            field_dict["baseUrl"] = base_url
        if config_source is not UNSET:
            field_dict["configSource"] = config_source

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        configured = d.pop("configured")

        editable_fields = cast(list[str], d.pop("editableFields"))

        enabled = d.pop("enabled")

        provider_key = d.pop("providerKey")

        def _parse_base_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        base_url = _parse_base_url(d.pop("baseUrl", UNSET))

        def _parse_config_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_source = _parse_config_source(d.pop("configSource", UNSET))

        provider_settings_response = cls(
            configured=configured,
            editable_fields=editable_fields,
            enabled=enabled,
            provider_key=provider_key,
            base_url=base_url,
            config_source=config_source,
        )

        provider_settings_response.additional_properties = d
        return provider_settings_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
