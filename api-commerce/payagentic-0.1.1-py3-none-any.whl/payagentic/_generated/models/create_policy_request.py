from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.create_policy_request_rules import CreatePolicyRequestRules


T = TypeVar("T", bound="CreatePolicyRequest")


@_attrs_define
class CreatePolicyRequest:
    """Request body for creating a spend policy.

    Attributes:
        agent_ids (list[str]): IDs of agents this policy applies to.
        name (str): Human-readable policy name. Example: Daily spend cap.
        rules (CreatePolicyRequestRules): Policy rules encoded as JSON.

            Supports: `max_per_tx`, `daily_limit`, `allowed_destinations`,
            `time_window`, `velocity`.
        description (None | str | Unset): Policy description. Example: Limit agent spending to 100 stablecoin units per
            day.
    """

    agent_ids: list[str]
    name: str
    rules: CreatePolicyRequestRules
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.create_policy_request_rules import CreatePolicyRequestRules

        agent_ids = self.agent_ids

        name = self.name

        rules = self.rules.to_dict()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_ids": agent_ids,
                "name": name,
                "rules": rules,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_policy_request_rules import CreatePolicyRequestRules

        d = dict(src_dict)
        agent_ids = cast(list[str], d.pop("agent_ids"))

        name = d.pop("name")

        rules = CreatePolicyRequestRules.from_dict(d.pop("rules"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        create_policy_request = cls(
            agent_ids=agent_ids,
            name=name,
            rules=rules,
            description=description,
        )

        create_policy_request.additional_properties = d
        return create_policy_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
