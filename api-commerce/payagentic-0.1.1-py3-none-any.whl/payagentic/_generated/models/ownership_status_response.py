from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="OwnershipStatusResponse")


@_attrs_define
class OwnershipStatusResponse:
    """
    Attributes:
        renewal_required (bool):
        state (str):
        canonical_base_url (None | str | Unset):
        payout_wallet_address (None | str | Unset):
        proof_url (None | str | Unset):
        verified_at (None | str | Unset):
        verified_until (None | str | Unset):
    """

    renewal_required: bool
    state: str
    canonical_base_url: None | str | Unset = UNSET
    payout_wallet_address: None | str | Unset = UNSET
    proof_url: None | str | Unset = UNSET
    verified_at: None | str | Unset = UNSET
    verified_until: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        renewal_required = self.renewal_required

        state = self.state

        canonical_base_url: None | str | Unset
        if isinstance(self.canonical_base_url, Unset):
            canonical_base_url = UNSET
        else:
            canonical_base_url = self.canonical_base_url

        payout_wallet_address: None | str | Unset
        if isinstance(self.payout_wallet_address, Unset):
            payout_wallet_address = UNSET
        else:
            payout_wallet_address = self.payout_wallet_address

        proof_url: None | str | Unset
        if isinstance(self.proof_url, Unset):
            proof_url = UNSET
        else:
            proof_url = self.proof_url

        verified_at: None | str | Unset
        if isinstance(self.verified_at, Unset):
            verified_at = UNSET
        else:
            verified_at = self.verified_at

        verified_until: None | str | Unset
        if isinstance(self.verified_until, Unset):
            verified_until = UNSET
        else:
            verified_until = self.verified_until

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "renewal_required": renewal_required,
                "state": state,
            }
        )
        if canonical_base_url is not UNSET:
            field_dict["canonical_base_url"] = canonical_base_url
        if payout_wallet_address is not UNSET:
            field_dict["payout_wallet_address"] = payout_wallet_address
        if proof_url is not UNSET:
            field_dict["proof_url"] = proof_url
        if verified_at is not UNSET:
            field_dict["verified_at"] = verified_at
        if verified_until is not UNSET:
            field_dict["verified_until"] = verified_until

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        renewal_required = d.pop("renewal_required")

        state = d.pop("state")

        def _parse_canonical_base_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        canonical_base_url = _parse_canonical_base_url(d.pop("canonical_base_url", UNSET))

        def _parse_payout_wallet_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payout_wallet_address = _parse_payout_wallet_address(d.pop("payout_wallet_address", UNSET))

        def _parse_proof_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        proof_url = _parse_proof_url(d.pop("proof_url", UNSET))

        def _parse_verified_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        verified_at = _parse_verified_at(d.pop("verified_at", UNSET))

        def _parse_verified_until(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        verified_until = _parse_verified_until(d.pop("verified_until", UNSET))

        ownership_status_response = cls(
            renewal_required=renewal_required,
            state=state,
            canonical_base_url=canonical_base_url,
            payout_wallet_address=payout_wallet_address,
            proof_url=proof_url,
            verified_at=verified_at,
            verified_until=verified_until,
        )

        ownership_status_response.additional_properties = d
        return ownership_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
