from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="RefreshWalletDepositsBody")


@_attrs_define
class RefreshWalletDepositsBody:
    """
    Attributes:
        from_block (int | None | Unset):
        lookback_blocks (int | None | Unset):
    """

    from_block: int | None | Unset = UNSET
    lookback_blocks: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from_block: int | None | Unset
        if isinstance(self.from_block, Unset):
            from_block = UNSET
        else:
            from_block = self.from_block

        lookback_blocks: int | None | Unset
        if isinstance(self.lookback_blocks, Unset):
            lookback_blocks = UNSET
        else:
            lookback_blocks = self.lookback_blocks

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if from_block is not UNSET:
            field_dict["fromBlock"] = from_block
        if lookback_blocks is not UNSET:
            field_dict["lookbackBlocks"] = lookback_blocks

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_from_block(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        from_block = _parse_from_block(d.pop("fromBlock", UNSET))

        def _parse_lookback_blocks(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        lookback_blocks = _parse_lookback_blocks(d.pop("lookbackBlocks", UNSET))

        refresh_wallet_deposits_body = cls(
            from_block=from_block,
            lookback_blocks=lookback_blocks,
        )

        refresh_wallet_deposits_body.additional_properties = d
        return refresh_wallet_deposits_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
