from enum import Enum


class GatewayEventType0Type(str, Enum):
    APPROVAL_CREATED = "approval_created"

    def __str__(self) -> str:
        return str(self.value)
