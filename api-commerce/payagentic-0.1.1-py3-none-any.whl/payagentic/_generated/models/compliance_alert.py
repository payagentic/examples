from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="ComplianceAlert")


@_attrs_define
class ComplianceAlert:
    """
    Attributes:
        created_at (datetime.datetime):
        description (str):
        id (UUID):
        organization_id (UUID):
        related_transaction_ids (list[UUID]):
        severity (str):
        status (str):
        type_ (str):
        updated_at (datetime.datetime):
    """

    created_at: datetime.datetime
    description: str
    id: UUID
    organization_id: UUID
    related_transaction_ids: list[UUID]
    severity: str
    status: str
    type_: str
    updated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        created_at = self.created_at.isoformat()

        description = self.description

        id = str(self.id)

        organization_id = str(self.organization_id)

        related_transaction_ids = []
        for related_transaction_ids_item_data in self.related_transaction_ids:
            related_transaction_ids_item = str(related_transaction_ids_item_data)
            related_transaction_ids.append(related_transaction_ids_item)

        severity = self.severity

        status = self.status

        type_ = self.type_

        updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "createdAt": created_at,
                "description": description,
                "id": id,
                "organizationId": organization_id,
                "relatedTransactionIds": related_transaction_ids,
                "severity": severity,
                "status": status,
                "type": type_,
                "updatedAt": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        created_at = isoparse(d.pop("createdAt"))

        description = d.pop("description")

        id = UUID(d.pop("id"))

        organization_id = UUID(d.pop("organizationId"))

        related_transaction_ids = []
        _related_transaction_ids = d.pop("relatedTransactionIds")
        for related_transaction_ids_item_data in _related_transaction_ids:
            related_transaction_ids_item = UUID(related_transaction_ids_item_data)

            related_transaction_ids.append(related_transaction_ids_item)

        severity = d.pop("severity")

        status = d.pop("status")

        type_ = d.pop("type")

        updated_at = isoparse(d.pop("updatedAt"))

        compliance_alert = cls(
            created_at=created_at,
            description=description,
            id=id,
            organization_id=organization_id,
            related_transaction_ids=related_transaction_ids,
            severity=severity,
            status=status,
            type_=type_,
            updated_at=updated_at,
        )

        compliance_alert.additional_properties = d
        return compliance_alert

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
