from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.webhook_event_payload import WebhookEventPayload


T = TypeVar("T", bound="WebhookEvent")


@_attrs_define
class WebhookEvent:
    """A webhook event delivered to the platform from an external vendor.

    Attributes:
        event_type (str): Event type as reported by the vendor. Example: charge.success.
        id (UUID): Unique event identifier assigned by the platform. Example: 019433e0-1b3c-7d0a-8e4f-000000000050.
        payload (WebhookEventPayload): Raw event payload.
        received_at (datetime.datetime): When the event was received (ISO 8601). Example: 2025-01-15T12:00:00Z.
        vendor (str): Vendor that sent the webhook (e.g., "paystack", "mpesa", "stitch"). Example: paystack.
    """

    event_type: str
    id: UUID
    payload: WebhookEventPayload
    received_at: datetime.datetime
    vendor: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_event_payload import WebhookEventPayload

        event_type = self.event_type

        id = str(self.id)

        payload = self.payload.to_dict()

        received_at = self.received_at.isoformat()

        vendor = self.vendor

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_type": event_type,
                "id": id,
                "payload": payload,
                "received_at": received_at,
                "vendor": vendor,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_event_payload import WebhookEventPayload

        d = dict(src_dict)
        event_type = d.pop("event_type")

        id = UUID(d.pop("id"))

        payload = WebhookEventPayload.from_dict(d.pop("payload"))

        received_at = isoparse(d.pop("received_at"))

        vendor = d.pop("vendor")

        webhook_event = cls(
            event_type=event_type,
            id=id,
            payload=payload,
            received_at=received_at,
            vendor=vendor,
        )

        webhook_event.additional_properties = d
        return webhook_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
