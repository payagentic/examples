from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.earning_row import EarningRow


T = TypeVar("T", bound="EarningsResponse")


@_attrs_define
class EarningsResponse:
    """
    Attributes:
        earnings (list[EarningRow]):
        next_cursor (None | str | Unset):
    """

    earnings: list[EarningRow]
    next_cursor: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.earning_row import EarningRow

        earnings = []
        for earnings_item_data in self.earnings:
            earnings_item = earnings_item_data.to_dict()
            earnings.append(earnings_item)

        next_cursor: None | str | Unset
        if isinstance(self.next_cursor, Unset):
            next_cursor = UNSET
        else:
            next_cursor = self.next_cursor

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "earnings": earnings,
            }
        )
        if next_cursor is not UNSET:
            field_dict["next_cursor"] = next_cursor

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.earning_row import EarningRow

        d = dict(src_dict)
        earnings = []
        _earnings = d.pop("earnings")
        for earnings_item_data in _earnings:
            earnings_item = EarningRow.from_dict(earnings_item_data)

            earnings.append(earnings_item)

        def _parse_next_cursor(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        next_cursor = _parse_next_cursor(d.pop("next_cursor", UNSET))

        earnings_response = cls(
            earnings=earnings,
            next_cursor=next_cursor,
        )

        earnings_response.additional_properties = d
        return earnings_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
