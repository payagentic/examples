from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.structured_example_dto_input import StructuredExampleDtoInput
    from ..models.structured_example_dto_output import StructuredExampleDtoOutput


T = TypeVar("T", bound="StructuredExampleDto")


@_attrs_define
class StructuredExampleDto:
    """
    Attributes:
        input_ (StructuredExampleDtoInput):
        output (StructuredExampleDtoOutput):
    """

    input_: StructuredExampleDtoInput
    output: StructuredExampleDtoOutput

    def to_dict(self) -> dict[str, Any]:
        from ..models.structured_example_dto_input import StructuredExampleDtoInput
        from ..models.structured_example_dto_output import StructuredExampleDtoOutput

        input_ = self.input_.to_dict()

        output = self.output.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "input": input_,
                "output": output,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.structured_example_dto_input import StructuredExampleDtoInput
        from ..models.structured_example_dto_output import StructuredExampleDtoOutput

        d = dict(src_dict)
        input_ = StructuredExampleDtoInput.from_dict(d.pop("input"))

        output = StructuredExampleDtoOutput.from_dict(d.pop("output"))

        structured_example_dto = cls(
            input_=input_,
            output=output,
        )

        return structured_example_dto
