from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="RefundResponse")


@_attrs_define
class RefundResponse:
    """
    Attributes:
        amount (str):
        currency (str):
        id (UUID):
        merchant_id (UUID):
        mode (str):
        payment_id (UUID):
        requested_at (datetime.datetime):
        status (str):
        applied_at (datetime.datetime | None | Unset):
        reason (None | str | Unset):
    """

    amount: str
    currency: str
    id: UUID
    merchant_id: UUID
    mode: str
    payment_id: UUID
    requested_at: datetime.datetime
    status: str
    applied_at: datetime.datetime | None | Unset = UNSET
    reason: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        currency = self.currency

        id = str(self.id)

        merchant_id = str(self.merchant_id)

        mode = self.mode

        payment_id = str(self.payment_id)

        requested_at = self.requested_at.isoformat()

        status = self.status

        applied_at: None | str | Unset
        if isinstance(self.applied_at, Unset):
            applied_at = UNSET
        elif isinstance(self.applied_at, datetime.datetime):
            applied_at = self.applied_at.isoformat()
        else:
            applied_at = self.applied_at

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "currency": currency,
                "id": id,
                "merchant_id": merchant_id,
                "mode": mode,
                "payment_id": payment_id,
                "requested_at": requested_at,
                "status": status,
            }
        )
        if applied_at is not UNSET:
            field_dict["applied_at"] = applied_at
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        currency = d.pop("currency")

        id = UUID(d.pop("id"))

        merchant_id = UUID(d.pop("merchant_id"))

        mode = d.pop("mode")

        payment_id = UUID(d.pop("payment_id"))

        requested_at = isoparse(d.pop("requested_at"))

        status = d.pop("status")

        def _parse_applied_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                applied_at_type_0 = isoparse(data)

                return applied_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        applied_at = _parse_applied_at(d.pop("applied_at", UNSET))

        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))

        refund_response = cls(
            amount=amount,
            currency=currency,
            id=id,
            merchant_id=merchant_id,
            mode=mode,
            payment_id=payment_id,
            requested_at=requested_at,
            status=status,
            applied_at=applied_at,
            reason=reason,
        )

        refund_response.additional_properties = d
        return refund_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
