from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="DashboardStats")


@_attrs_define
class DashboardStats:
    """
    Attributes:
        active_agents (int):
        agent_change_24_h (int):
        balance_change_24_h (float):
        pending_approvals (int):
        total_balance (float):
        transactions_today (int):
    """

    active_agents: int
    agent_change_24_h: int
    balance_change_24_h: float
    pending_approvals: int
    total_balance: float
    transactions_today: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        active_agents = self.active_agents

        agent_change_24_h = self.agent_change_24_h

        balance_change_24_h = self.balance_change_24_h

        pending_approvals = self.pending_approvals

        total_balance = self.total_balance

        transactions_today = self.transactions_today

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "activeAgents": active_agents,
                "agentChange24h": agent_change_24_h,
                "balanceChange24h": balance_change_24_h,
                "pendingApprovals": pending_approvals,
                "totalBalance": total_balance,
                "transactionsToday": transactions_today,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        active_agents = d.pop("activeAgents")

        agent_change_24_h = d.pop("agentChange24h")

        balance_change_24_h = d.pop("balanceChange24h")

        pending_approvals = d.pop("pendingApprovals")

        total_balance = d.pop("totalBalance")

        transactions_today = d.pop("transactionsToday")

        dashboard_stats = cls(
            active_agents=active_agents,
            agent_change_24_h=agent_change_24_h,
            balance_change_24_h=balance_change_24_h,
            pending_approvals=pending_approvals,
            total_balance=total_balance,
            transactions_today=transactions_today,
        )

        dashboard_stats.additional_properties = d
        return dashboard_stats

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
