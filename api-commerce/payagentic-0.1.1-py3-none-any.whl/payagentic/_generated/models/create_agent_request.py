from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="CreateAgentRequest")


@_attrs_define
class CreateAgentRequest:
    """Request body for creating a new AI agent.

    Field names mirror the handler's `CreateAgentBody` (camelCase). Previously
    this schema advertised a required snake_case `wallet_id`, which the handler
    (camelCase, optional) silently ignored, so SDK callers created agents with
    no wallet linked.

        Attributes:
            name (str): Human-readable name for the agent. Example: price-checker-bot.
            description (None | str | Unset): Optional description of the agent's purpose. Example: Fetches commodity prices
                from third-party APIs.
            policy_ids (list[UUID] | Unset): Existing policy IDs to attach to the agent at creation.
            wallet_id (None | Unset | UUID): ID of a wallet this agent is authorized to use. Optional: the gateway
                links the org's primary wallet when omitted. Example: 019433e0-1b3c-7d0a-8e4f-000000000010.
            wallet_ids (list[UUID] | Unset): Additional wallet IDs to link to the agent at creation.
    """

    name: str
    description: None | str | Unset = UNSET
    policy_ids: list[UUID] | Unset = UNSET
    wallet_id: None | Unset | UUID = UNSET
    wallet_ids: list[UUID] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        policy_ids: list[str] | Unset = UNSET
        if not isinstance(self.policy_ids, Unset):
            policy_ids = []
            for policy_ids_item_data in self.policy_ids:
                policy_ids_item = str(policy_ids_item_data)
                policy_ids.append(policy_ids_item)

        wallet_id: None | str | Unset
        if isinstance(self.wallet_id, Unset):
            wallet_id = UNSET
        elif isinstance(self.wallet_id, UUID):
            wallet_id = str(self.wallet_id)
        else:
            wallet_id = self.wallet_id

        wallet_ids: list[str] | Unset = UNSET
        if not isinstance(self.wallet_ids, Unset):
            wallet_ids = []
            for wallet_ids_item_data in self.wallet_ids:
                wallet_ids_item = str(wallet_ids_item_data)
                wallet_ids.append(wallet_ids_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if policy_ids is not UNSET:
            field_dict["policyIds"] = policy_ids
        if wallet_id is not UNSET:
            field_dict["walletId"] = wallet_id
        if wallet_ids is not UNSET:
            field_dict["walletIds"] = wallet_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _policy_ids = d.pop("policyIds", UNSET)
        policy_ids: list[UUID] | Unset = UNSET
        if _policy_ids is not UNSET:
            policy_ids = []
            for policy_ids_item_data in _policy_ids:
                policy_ids_item = UUID(policy_ids_item_data)

                policy_ids.append(policy_ids_item)

        def _parse_wallet_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                wallet_id_type_0 = UUID(data)

                return wallet_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        wallet_id = _parse_wallet_id(d.pop("walletId", UNSET))

        _wallet_ids = d.pop("walletIds", UNSET)
        wallet_ids: list[UUID] | Unset = UNSET
        if _wallet_ids is not UNSET:
            wallet_ids = []
            for wallet_ids_item_data in _wallet_ids:
                wallet_ids_item = UUID(wallet_ids_item_data)

                wallet_ids.append(wallet_ids_item)

        create_agent_request = cls(
            name=name,
            description=description,
            policy_ids=policy_ids,
            wallet_id=wallet_id,
            wallet_ids=wallet_ids,
        )

        create_agent_request.additional_properties = d
        return create_agent_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
