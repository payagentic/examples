from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.x402_verify_request_payment_requirements import (
        X402VerifyRequestPaymentRequirements,
    )


T = TypeVar("T", bound="X402VerifyRequest")


@_attrs_define
class X402VerifyRequest:
    """Request body for verifying an x402 payment.

    Attributes:
        payment_requirements (X402VerifyRequestPaymentRequirements): The payment requirements from the 402 response.
        payment_signature (str): The raw payment credential the client attached to the vendor request.

            For x402 legacy this is the base64 `X-Payment` value; for x402 v2 it
            is the `PAYMENT-SIGNATURE` value.  The verify endpoint uses it to look
            up and confirm the on-chain settlement. Example: base64-encoded-payment-credential.
        resource_url (str): The original resource URL that returned HTTP 402. Example: https://api.example.com/v1/data.
    """

    payment_requirements: X402VerifyRequestPaymentRequirements
    payment_signature: str
    resource_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.x402_verify_request_payment_requirements import (
            X402VerifyRequestPaymentRequirements,
        )

        payment_requirements = self.payment_requirements.to_dict()

        payment_signature = self.payment_signature

        resource_url = self.resource_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "payment_requirements": payment_requirements,
                "payment_signature": payment_signature,
                "resource_url": resource_url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.x402_verify_request_payment_requirements import (
            X402VerifyRequestPaymentRequirements,
        )

        d = dict(src_dict)
        payment_requirements = X402VerifyRequestPaymentRequirements.from_dict(
            d.pop("payment_requirements")
        )

        payment_signature = d.pop("payment_signature")

        resource_url = d.pop("resource_url")

        x402_verify_request = cls(
            payment_requirements=payment_requirements,
            payment_signature=payment_signature,
            resource_url=resource_url,
        )

        x402_verify_request.additional_properties = d
        return x402_verify_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
