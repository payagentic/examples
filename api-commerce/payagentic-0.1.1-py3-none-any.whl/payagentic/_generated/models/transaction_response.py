from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="TransactionResponse")


@_attrs_define
class TransactionResponse:
    """Transaction resource returned by the API.

    Attributes:
        amount (str): Transfer amount. Example: 25.00.
        chain (str): Blockchain network. Example: base.
        created_at (datetime.datetime): When the transaction was created (ISO 8601). Example: 2025-01-15T12:00:00Z.
        currency (str): Currency. Example: USDC.
        direction (str): Money direction relative to the org: "incoming" or "outgoing". Example: outgoing.
        from_address (str): Sender address. Example: 0x742d35Cc6634C0532925a3b844Bc9e7595f2bD18.
        id (UUID): Transaction identifier (`UUIDv7`). Example: 019433e0-1b3c-7d0a-8e4f-000000000030.
        metadata (Any): Arbitrary metadata.
        organization_id (UUID): Organization ID.
        status (str): Transaction status ("pending", "processing", "completed", "failed", "cancelled"). Example:
            completed.
        to_address (str): Recipient address. Example: 0x1234567890abcdef1234567890abcdef12345678.
        type_ (str): Transaction type. Example: payment.
        updated_at (datetime.datetime): When the transaction was last updated (ISO 8601). Example: 2025-01-15T12:00:00Z.
        wallet_id (UUID): Wallet ID.
        agent_id (None | Unset | UUID): Agent ID (if initiated by an agent).
        counterparty (None | str | Unset): The other party's raw address (recipient for outgoing, sender for
            incoming). May be empty when unknown. Example: 0x1234567890abcdef1234567890abcdef12345678.
        counterparty_name (None | str | Unset): Resolved counterparty name (own-wallet label or merchant name), else
            null. Example: Wallet 2.
        policy_evaluation_id (None | Unset | UUID): Policy evaluation ID.
        tx_hash (None | str | Unset): On-chain transaction hash. Example: 0xabc123....
    """

    amount: str
    chain: str
    created_at: datetime.datetime
    currency: str
    direction: str
    from_address: str
    id: UUID
    metadata: Any
    organization_id: UUID
    status: str
    to_address: str
    type_: str
    updated_at: datetime.datetime
    wallet_id: UUID
    agent_id: None | Unset | UUID = UNSET
    counterparty: None | str | Unset = UNSET
    counterparty_name: None | str | Unset = UNSET
    policy_evaluation_id: None | Unset | UUID = UNSET
    tx_hash: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        chain = self.chain

        created_at = self.created_at.isoformat()

        currency = self.currency

        direction = self.direction

        from_address = self.from_address

        id = str(self.id)

        metadata = self.metadata

        organization_id = str(self.organization_id)

        status = self.status

        to_address = self.to_address

        type_ = self.type_

        updated_at = self.updated_at.isoformat()

        wallet_id = str(self.wallet_id)

        agent_id: None | str | Unset
        if isinstance(self.agent_id, Unset):
            agent_id = UNSET
        elif isinstance(self.agent_id, UUID):
            agent_id = str(self.agent_id)
        else:
            agent_id = self.agent_id

        counterparty: None | str | Unset
        if isinstance(self.counterparty, Unset):
            counterparty = UNSET
        else:
            counterparty = self.counterparty

        counterparty_name: None | str | Unset
        if isinstance(self.counterparty_name, Unset):
            counterparty_name = UNSET
        else:
            counterparty_name = self.counterparty_name

        policy_evaluation_id: None | str | Unset
        if isinstance(self.policy_evaluation_id, Unset):
            policy_evaluation_id = UNSET
        elif isinstance(self.policy_evaluation_id, UUID):
            policy_evaluation_id = str(self.policy_evaluation_id)
        else:
            policy_evaluation_id = self.policy_evaluation_id

        tx_hash: None | str | Unset
        if isinstance(self.tx_hash, Unset):
            tx_hash = UNSET
        else:
            tx_hash = self.tx_hash

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "chain": chain,
                "createdAt": created_at,
                "currency": currency,
                "direction": direction,
                "fromAddress": from_address,
                "id": id,
                "metadata": metadata,
                "organizationId": organization_id,
                "status": status,
                "toAddress": to_address,
                "type": type_,
                "updatedAt": updated_at,
                "walletId": wallet_id,
            }
        )
        if agent_id is not UNSET:
            field_dict["agentId"] = agent_id
        if counterparty is not UNSET:
            field_dict["counterparty"] = counterparty
        if counterparty_name is not UNSET:
            field_dict["counterpartyName"] = counterparty_name
        if policy_evaluation_id is not UNSET:
            field_dict["policyEvaluationId"] = policy_evaluation_id
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        chain = d.pop("chain")

        created_at = isoparse(d.pop("createdAt"))

        currency = d.pop("currency")

        direction = d.pop("direction")

        from_address = d.pop("fromAddress")

        id = UUID(d.pop("id"))

        metadata = d.pop("metadata")

        organization_id = UUID(d.pop("organizationId"))

        status = d.pop("status")

        to_address = d.pop("toAddress")

        type_ = d.pop("type")

        updated_at = isoparse(d.pop("updatedAt"))

        wallet_id = UUID(d.pop("walletId"))

        def _parse_agent_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                agent_id_type_0 = UUID(data)

                return agent_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        agent_id = _parse_agent_id(d.pop("agentId", UNSET))

        def _parse_counterparty(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        counterparty = _parse_counterparty(d.pop("counterparty", UNSET))

        def _parse_counterparty_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        counterparty_name = _parse_counterparty_name(d.pop("counterpartyName", UNSET))

        def _parse_policy_evaluation_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                policy_evaluation_id_type_0 = UUID(data)

                return policy_evaluation_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        policy_evaluation_id = _parse_policy_evaluation_id(d.pop("policyEvaluationId", UNSET))

        def _parse_tx_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tx_hash = _parse_tx_hash(d.pop("txHash", UNSET))

        transaction_response = cls(
            amount=amount,
            chain=chain,
            created_at=created_at,
            currency=currency,
            direction=direction,
            from_address=from_address,
            id=id,
            metadata=metadata,
            organization_id=organization_id,
            status=status,
            to_address=to_address,
            type_=type_,
            updated_at=updated_at,
            wallet_id=wallet_id,
            agent_id=agent_id,
            counterparty=counterparty,
            counterparty_name=counterparty_name,
            policy_evaluation_id=policy_evaluation_id,
            tx_hash=tx_hash,
        )

        transaction_response.additional_properties = d
        return transaction_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
