from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.compliance_alert import ComplianceAlert


T = TypeVar("T", bound="PaginatedComplianceAlerts")


@_attrs_define
class PaginatedComplianceAlerts:
    """Paginated list of compliance alerts. Placeholder until the AML pipeline
    lands — returns an empty page today.

        Attributes:
            has_more (bool):
            items (list[ComplianceAlert]):
            next_cursor (None | str | Unset):
    """

    has_more: bool
    items: list[ComplianceAlert]
    next_cursor: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.compliance_alert import ComplianceAlert

        has_more = self.has_more

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)

        next_cursor: None | str | Unset
        if isinstance(self.next_cursor, Unset):
            next_cursor = UNSET
        else:
            next_cursor = self.next_cursor

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hasMore": has_more,
                "items": items,
            }
        )
        if next_cursor is not UNSET:
            field_dict["nextCursor"] = next_cursor

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.compliance_alert import ComplianceAlert

        d = dict(src_dict)
        has_more = d.pop("hasMore")

        items = []
        _items = d.pop("items")
        for items_item_data in _items:
            items_item = ComplianceAlert.from_dict(items_item_data)

            items.append(items_item)

        def _parse_next_cursor(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        next_cursor = _parse_next_cursor(d.pop("nextCursor", UNSET))

        paginated_compliance_alerts = cls(
            has_more=has_more,
            items=items,
            next_cursor=next_cursor,
        )

        paginated_compliance_alerts.additional_properties = d
        return paginated_compliance_alerts

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
