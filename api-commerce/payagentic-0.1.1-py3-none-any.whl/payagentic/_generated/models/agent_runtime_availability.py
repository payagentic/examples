from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.runtime_model_response import RuntimeModelResponse


T = TypeVar("T", bound="AgentRuntimeAvailability")


@_attrs_define
class AgentRuntimeAvailability:
    """
    Attributes:
        available (bool):
        capabilities (list[str]):
        configured (bool):
        connection_mode (str):
        editable_fields (list[str]):
        key (str):
        kind (str):
        label (str):
        models (list[RuntimeModelResponse]):
        reason (str):
        setup_command (str):
        setup_label (str):
        setup_url (str):
        auth_ok (bool | None | Unset):
        config_source (None | str | Unset):
    """

    available: bool
    capabilities: list[str]
    configured: bool
    connection_mode: str
    editable_fields: list[str]
    key: str
    kind: str
    label: str
    models: list[RuntimeModelResponse]
    reason: str
    setup_command: str
    setup_label: str
    setup_url: str
    auth_ok: bool | None | Unset = UNSET
    config_source: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.runtime_model_response import RuntimeModelResponse

        available = self.available

        capabilities = self.capabilities

        configured = self.configured

        connection_mode = self.connection_mode

        editable_fields = self.editable_fields

        key = self.key

        kind = self.kind

        label = self.label

        models = []
        for models_item_data in self.models:
            models_item = models_item_data.to_dict()
            models.append(models_item)

        reason = self.reason

        setup_command = self.setup_command

        setup_label = self.setup_label

        setup_url = self.setup_url

        auth_ok: bool | None | Unset
        if isinstance(self.auth_ok, Unset):
            auth_ok = UNSET
        else:
            auth_ok = self.auth_ok

        config_source: None | str | Unset
        if isinstance(self.config_source, Unset):
            config_source = UNSET
        else:
            config_source = self.config_source

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "available": available,
                "capabilities": capabilities,
                "configured": configured,
                "connectionMode": connection_mode,
                "editableFields": editable_fields,
                "key": key,
                "kind": kind,
                "label": label,
                "models": models,
                "reason": reason,
                "setupCommand": setup_command,
                "setupLabel": setup_label,
                "setupUrl": setup_url,
            }
        )
        if auth_ok is not UNSET:
            field_dict["authOk"] = auth_ok
        if config_source is not UNSET:
            field_dict["configSource"] = config_source

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.runtime_model_response import RuntimeModelResponse

        d = dict(src_dict)
        available = d.pop("available")

        capabilities = cast(list[str], d.pop("capabilities"))

        configured = d.pop("configured")

        connection_mode = d.pop("connectionMode")

        editable_fields = cast(list[str], d.pop("editableFields"))

        key = d.pop("key")

        kind = d.pop("kind")

        label = d.pop("label")

        models = []
        _models = d.pop("models")
        for models_item_data in _models:
            models_item = RuntimeModelResponse.from_dict(models_item_data)

            models.append(models_item)

        reason = d.pop("reason")

        setup_command = d.pop("setupCommand")

        setup_label = d.pop("setupLabel")

        setup_url = d.pop("setupUrl")

        def _parse_auth_ok(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        auth_ok = _parse_auth_ok(d.pop("authOk", UNSET))

        def _parse_config_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_source = _parse_config_source(d.pop("configSource", UNSET))

        agent_runtime_availability = cls(
            available=available,
            capabilities=capabilities,
            configured=configured,
            connection_mode=connection_mode,
            editable_fields=editable_fields,
            key=key,
            kind=kind,
            label=label,
            models=models,
            reason=reason,
            setup_command=setup_command,
            setup_label=setup_label,
            setup_url=setup_url,
            auth_ok=auth_ok,
            config_source=config_source,
        )

        agent_runtime_availability.additional_properties = d
        return agent_runtime_availability

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
