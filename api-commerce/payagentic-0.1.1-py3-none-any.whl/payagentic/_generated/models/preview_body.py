from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="PreviewBody")


@_attrs_define
class PreviewBody:
    """Inbound shape for `POST /v1/policies/preview`. Mirrors
    `web/src/app/_hooks/right/use-policy-preview.ts#PolicyPreviewIntent`
    — every field is camelCase coming from the dashboard's `api.post`.

    `source_id` is deserialized for parity with the wallet-id contract but
    not yet used — wallet org-membership is enforced server-side at
    `POST /v1/transfers` time. `#[allow(dead_code)]` keeps the field
    visible in the API surface without tripping the unused-field lint.

        Attributes:
            amount (str): Stringified decimal (e.g. "0.01"). Parsed lazily — we only need
                it to short-circuit the obviously-empty case.
            source_id (UUID):
            currency (None | str | Unset):
            destination_address (None | str | Unset):
            destination_id (None | Unset | UUID):
    """

    amount: str
    source_id: UUID
    currency: None | str | Unset = UNSET
    destination_address: None | str | Unset = UNSET
    destination_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        source_id = str(self.source_id)

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        destination_address: None | str | Unset
        if isinstance(self.destination_address, Unset):
            destination_address = UNSET
        else:
            destination_address = self.destination_address

        destination_id: None | str | Unset
        if isinstance(self.destination_id, Unset):
            destination_id = UNSET
        elif isinstance(self.destination_id, UUID):
            destination_id = str(self.destination_id)
        else:
            destination_id = self.destination_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "sourceId": source_id,
            }
        )
        if currency is not UNSET:
            field_dict["currency"] = currency
        if destination_address is not UNSET:
            field_dict["destinationAddress"] = destination_address
        if destination_id is not UNSET:
            field_dict["destinationId"] = destination_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        source_id = UUID(d.pop("sourceId"))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_destination_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        destination_address = _parse_destination_address(d.pop("destinationAddress", UNSET))

        def _parse_destination_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                destination_id_type_0 = UUID(data)

                return destination_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        destination_id = _parse_destination_id(d.pop("destinationId", UNSET))

        preview_body = cls(
            amount=amount,
            source_id=source_id,
            currency=currency,
            destination_address=destination_address,
            destination_id=destination_id,
        )

        preview_body.additional_properties = d
        return preview_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
