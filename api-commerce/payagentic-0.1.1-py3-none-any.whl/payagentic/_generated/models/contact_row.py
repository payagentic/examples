from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


T = TypeVar("T", bound="ContactRow")


@_attrs_define
class ContactRow:
    """
    Attributes:
        address (str):
        chain (str):
        created_at (datetime.datetime):
        id (UUID):
        name (str):
        status (str):
        updated_at (datetime.datetime):
        note (None | str | Unset):
    """

    address: str
    chain: str
    created_at: datetime.datetime
    id: UUID
    name: str
    status: str
    updated_at: datetime.datetime
    note: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        address = self.address

        chain = self.chain

        created_at = self.created_at.isoformat()

        id = str(self.id)

        name = self.name

        status = self.status

        updated_at = self.updated_at.isoformat()

        note: None | str | Unset
        if isinstance(self.note, Unset):
            note = UNSET
        else:
            note = self.note

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "address": address,
                "chain": chain,
                "createdAt": created_at,
                "id": id,
                "name": name,
                "status": status,
                "updatedAt": updated_at,
            }
        )
        if note is not UNSET:
            field_dict["note"] = note

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address = d.pop("address")

        chain = d.pop("chain")

        created_at = isoparse(d.pop("createdAt"))

        id = UUID(d.pop("id"))

        name = d.pop("name")

        status = d.pop("status")

        updated_at = isoparse(d.pop("updatedAt"))

        def _parse_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        note = _parse_note(d.pop("note", UNSET))

        contact_row = cls(
            address=address,
            chain=chain,
            created_at=created_at,
            id=id,
            name=name,
            status=status,
            updated_at=updated_at,
            note=note,
        )

        contact_row.additional_properties = d
        return contact_row

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
