from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.capability_test_response_output import CapabilityTestResponseOutput


T = TypeVar("T", bound="CapabilityTestResponse")


@_attrs_define
class CapabilityTestResponse:
    """
    Attributes:
        output (CapabilityTestResponseOutput):
        status (str):
        test_run_id (UUID):
    """

    output: CapabilityTestResponseOutput
    status: str
    test_run_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_test_response_output import CapabilityTestResponseOutput

        output = self.output.to_dict()

        status = self.status

        test_run_id = str(self.test_run_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "output": output,
                "status": status,
                "testRunId": test_run_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_test_response_output import CapabilityTestResponseOutput

        d = dict(src_dict)
        output = CapabilityTestResponseOutput.from_dict(d.pop("output"))

        status = d.pop("status")

        test_run_id = UUID(d.pop("testRunId"))

        capability_test_response = cls(
            output=output,
            status=status,
            test_run_id=test_run_id,
        )

        capability_test_response.additional_properties = d
        return capability_test_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
