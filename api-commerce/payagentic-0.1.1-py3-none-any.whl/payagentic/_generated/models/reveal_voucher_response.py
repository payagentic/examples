from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="RevealVoucherResponse")


@_attrs_define
class RevealVoucherResponse:
    """
    Attributes:
        code (str):
        delivery_format (str):
        redemption_instructions (str):
        voucher_order_id (UUID):
    """

    code: str
    delivery_format: str
    redemption_instructions: str
    voucher_order_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        code = self.code

        delivery_format = self.delivery_format

        redemption_instructions = self.redemption_instructions

        voucher_order_id = str(self.voucher_order_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "code": code,
                "deliveryFormat": delivery_format,
                "redemptionInstructions": redemption_instructions,
                "voucherOrderId": voucher_order_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        code = d.pop("code")

        delivery_format = d.pop("deliveryFormat")

        redemption_instructions = d.pop("redemptionInstructions")

        voucher_order_id = UUID(d.pop("voucherOrderId"))

        reveal_voucher_response = cls(
            code=code,
            delivery_format=delivery_format,
            redemption_instructions=redemption_instructions,
            voucher_order_id=voucher_order_id,
        )

        reveal_voucher_response.additional_properties = d
        return reveal_voucher_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
