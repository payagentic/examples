from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.capability_price_response import CapabilityPriceResponse


T = TypeVar("T", bound="CapabilityInvocationMetadata")


@_attrs_define
class CapabilityInvocationMetadata:
    """
    Attributes:
        agent_id (UUID):
        capability_id (UUID):
        capability_version_id (UUID):
        created_at (datetime.datetime):
        id (UUID):
        input_bytes (str):
        input_tokens (str):
        output_tokens (str):
        price (CapabilityPriceResponse):
        role (str):
        state (str):
        transport (str):
        failure_code (None | str | Unset):
        latency_ms (None | str | Unset):
        output_bytes (None | str | Unset):
        receipt_id (None | Unset | UUID):
        settled_at (datetime.datetime | None | Unset):
    """

    agent_id: UUID
    capability_id: UUID
    capability_version_id: UUID
    created_at: datetime.datetime
    id: UUID
    input_bytes: str
    input_tokens: str
    output_tokens: str
    price: CapabilityPriceResponse
    role: str
    state: str
    transport: str
    failure_code: None | str | Unset = UNSET
    latency_ms: None | str | Unset = UNSET
    output_bytes: None | str | Unset = UNSET
    receipt_id: None | Unset | UUID = UNSET
    settled_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_price_response import CapabilityPriceResponse

        agent_id = str(self.agent_id)

        capability_id = str(self.capability_id)

        capability_version_id = str(self.capability_version_id)

        created_at = self.created_at.isoformat()

        id = str(self.id)

        input_bytes = self.input_bytes

        input_tokens = self.input_tokens

        output_tokens = self.output_tokens

        price = self.price.to_dict()

        role = self.role

        state = self.state

        transport = self.transport

        failure_code: None | str | Unset
        if isinstance(self.failure_code, Unset):
            failure_code = UNSET
        else:
            failure_code = self.failure_code

        latency_ms: None | str | Unset
        if isinstance(self.latency_ms, Unset):
            latency_ms = UNSET
        else:
            latency_ms = self.latency_ms

        output_bytes: None | str | Unset
        if isinstance(self.output_bytes, Unset):
            output_bytes = UNSET
        else:
            output_bytes = self.output_bytes

        receipt_id: None | str | Unset
        if isinstance(self.receipt_id, Unset):
            receipt_id = UNSET
        elif isinstance(self.receipt_id, UUID):
            receipt_id = str(self.receipt_id)
        else:
            receipt_id = self.receipt_id

        settled_at: None | str | Unset
        if isinstance(self.settled_at, Unset):
            settled_at = UNSET
        elif isinstance(self.settled_at, datetime.datetime):
            settled_at = self.settled_at.isoformat()
        else:
            settled_at = self.settled_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agentId": agent_id,
                "capabilityId": capability_id,
                "capabilityVersionId": capability_version_id,
                "createdAt": created_at,
                "id": id,
                "inputBytes": input_bytes,
                "inputTokens": input_tokens,
                "outputTokens": output_tokens,
                "price": price,
                "role": role,
                "state": state,
                "transport": transport,
            }
        )
        if failure_code is not UNSET:
            field_dict["failureCode"] = failure_code
        if latency_ms is not UNSET:
            field_dict["latencyMs"] = latency_ms
        if output_bytes is not UNSET:
            field_dict["outputBytes"] = output_bytes
        if receipt_id is not UNSET:
            field_dict["receiptId"] = receipt_id
        if settled_at is not UNSET:
            field_dict["settledAt"] = settled_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_price_response import CapabilityPriceResponse

        d = dict(src_dict)
        agent_id = UUID(d.pop("agentId"))

        capability_id = UUID(d.pop("capabilityId"))

        capability_version_id = UUID(d.pop("capabilityVersionId"))

        created_at = isoparse(d.pop("createdAt"))

        id = UUID(d.pop("id"))

        input_bytes = d.pop("inputBytes")

        input_tokens = d.pop("inputTokens")

        output_tokens = d.pop("outputTokens")

        price = CapabilityPriceResponse.from_dict(d.pop("price"))

        role = d.pop("role")

        state = d.pop("state")

        transport = d.pop("transport")

        def _parse_failure_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_code = _parse_failure_code(d.pop("failureCode", UNSET))

        def _parse_latency_ms(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        latency_ms = _parse_latency_ms(d.pop("latencyMs", UNSET))

        def _parse_output_bytes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output_bytes = _parse_output_bytes(d.pop("outputBytes", UNSET))

        def _parse_receipt_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                receipt_id_type_0 = UUID(data)

                return receipt_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        receipt_id = _parse_receipt_id(d.pop("receiptId", UNSET))

        def _parse_settled_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                settled_at_type_0 = isoparse(data)

                return settled_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        settled_at = _parse_settled_at(d.pop("settledAt", UNSET))

        capability_invocation_metadata = cls(
            agent_id=agent_id,
            capability_id=capability_id,
            capability_version_id=capability_version_id,
            created_at=created_at,
            id=id,
            input_bytes=input_bytes,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            price=price,
            role=role,
            state=state,
            transport=transport,
            failure_code=failure_code,
            latency_ms=latency_ms,
            output_bytes=output_bytes,
            receipt_id=receipt_id,
            settled_at=settled_at,
        )

        capability_invocation_metadata.additional_properties = d
        return capability_invocation_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
