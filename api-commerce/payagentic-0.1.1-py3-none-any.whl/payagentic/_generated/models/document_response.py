from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="DocumentResponse")


@_attrs_define
class DocumentResponse:
    """
    Attributes:
        document_type (str):
        id (UUID):
        reviewer_status (str):
        reviewer_note (None | str | Unset): Reviewer's note — the rejection reason, surfaced so the merchant knows
            what to fix. `None` for pending/approved documents.
    """

    document_type: str
    id: UUID
    reviewer_status: str
    reviewer_note: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        document_type = self.document_type

        id = str(self.id)

        reviewer_status = self.reviewer_status

        reviewer_note: None | str | Unset
        if isinstance(self.reviewer_note, Unset):
            reviewer_note = UNSET
        else:
            reviewer_note = self.reviewer_note

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "document_type": document_type,
                "id": id,
                "reviewer_status": reviewer_status,
            }
        )
        if reviewer_note is not UNSET:
            field_dict["reviewer_note"] = reviewer_note

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        document_type = d.pop("document_type")

        id = UUID(d.pop("id"))

        reviewer_status = d.pop("reviewer_status")

        def _parse_reviewer_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reviewer_note = _parse_reviewer_note(d.pop("reviewer_note", UNSET))

        document_response = cls(
            document_type=document_type,
            id=id,
            reviewer_status=reviewer_status,
            reviewer_note=reviewer_note,
        )

        document_response.additional_properties = d
        return document_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
