from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID


T = TypeVar("T", bound="AllocationItem")


@_attrs_define
class AllocationItem:
    """
    Attributes:
        balance (float):
        chain (str):
        currency (str):
        label (str):
        percent_of_total (float):
        wallet_id (UUID):
    """

    balance: float
    chain: str
    currency: str
    label: str
    percent_of_total: float
    wallet_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        balance = self.balance

        chain = self.chain

        currency = self.currency

        label = self.label

        percent_of_total = self.percent_of_total

        wallet_id = str(self.wallet_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "balance": balance,
                "chain": chain,
                "currency": currency,
                "label": label,
                "percentOfTotal": percent_of_total,
                "walletId": wallet_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        balance = d.pop("balance")

        chain = d.pop("chain")

        currency = d.pop("currency")

        label = d.pop("label")

        percent_of_total = d.pop("percentOfTotal")

        wallet_id = UUID(d.pop("walletId"))

        allocation_item = cls(
            balance=balance,
            chain=chain,
            currency=currency,
            label=label,
            percent_of_total=percent_of_total,
            wallet_id=wallet_id,
        )

        allocation_item.additional_properties = d
        return allocation_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
