from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="CreateWebhookRequest")


@_attrs_define
class CreateWebhookRequest:
    """
    Attributes:
        event_types (list[str]): Event types to subscribe to. Send `["*"]` for all events.

            Subscribable event types (non-exhaustive; the delivery worker uses
            dynamic `event_type` match against the subscription's `event_types`
            array — see `payments/src/webhooks.rs::fanout_batch`):
              - `payment.submitted`, `payment.confirming`, `payment.settled`,
                `payment.denied`, `payment.pending_approval`, `payment.approved`,
                `payment.refunded`
              - `merchant.*` (`signed_up`, `activated`, `suspended`, ...)
              - `payout.initiated`   (P6)
              - `payout.settled`     (P6)
              - `payout.failed`      (P6)

            Note: this list is documentation only — the worker matches
            `event_types` as a string allow-list, so customers can also
            subscribe to types we add later without a code change.
        url (str): HTTPS URL we POST to on each matching event. http:// allowed in
            dev but logged with a warning.
        description (None | str | Unset): Optional human label so customers can identify webhooks in the UI.
    """

    event_types: list[str]
    url: str
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        event_types = self.event_types

        url = self.url

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_types": event_types,
                "url": url,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        event_types = cast(list[str], d.pop("event_types"))

        url = d.pop("url")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        create_webhook_request = cls(
            event_types=event_types,
            url=url,
            description=description,
        )

        create_webhook_request.additional_properties = d
        return create_webhook_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
