from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.merchant_origin_proof import MerchantOriginProof


T = TypeVar("T", bound="OwnershipChallengeResponse")


@_attrs_define
class OwnershipChallengeResponse:
    """
    Attributes:
        challenge_id (str):
        expires_at (str):
        message (str):
        nonce (str):
        proof (MerchantOriginProof):
        proof_url (str):
    """

    challenge_id: str
    expires_at: str
    message: str
    nonce: str
    proof: MerchantOriginProof
    proof_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.merchant_origin_proof import MerchantOriginProof

        challenge_id = self.challenge_id

        expires_at = self.expires_at

        message = self.message

        nonce = self.nonce

        proof = self.proof.to_dict()

        proof_url = self.proof_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "challenge_id": challenge_id,
                "expires_at": expires_at,
                "message": message,
                "nonce": nonce,
                "proof": proof,
                "proof_url": proof_url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.merchant_origin_proof import MerchantOriginProof

        d = dict(src_dict)
        challenge_id = d.pop("challenge_id")

        expires_at = d.pop("expires_at")

        message = d.pop("message")

        nonce = d.pop("nonce")

        proof = MerchantOriginProof.from_dict(d.pop("proof"))

        proof_url = d.pop("proof_url")

        ownership_challenge_response = cls(
            challenge_id=challenge_id,
            expires_at=expires_at,
            message=message,
            nonce=nonce,
            proof=proof,
            proof_url=proof_url,
        )

        ownership_challenge_response.additional_properties = d
        return ownership_challenge_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
