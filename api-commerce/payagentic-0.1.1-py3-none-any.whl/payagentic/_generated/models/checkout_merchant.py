from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="CheckoutMerchant")


@_attrs_define
class CheckoutMerchant:
    """
    Attributes:
        domain (str):
        marketplace (None | str | Unset):
        mcc (None | str | Unset):
        merchant_id (None | str | Unset):
        name (None | str | Unset):
    """

    domain: str
    marketplace: None | str | Unset = UNSET
    mcc: None | str | Unset = UNSET
    merchant_id: None | str | Unset = UNSET
    name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        domain = self.domain

        marketplace: None | str | Unset
        if isinstance(self.marketplace, Unset):
            marketplace = UNSET
        else:
            marketplace = self.marketplace

        mcc: None | str | Unset
        if isinstance(self.mcc, Unset):
            mcc = UNSET
        else:
            mcc = self.mcc

        merchant_id: None | str | Unset
        if isinstance(self.merchant_id, Unset):
            merchant_id = UNSET
        else:
            merchant_id = self.merchant_id

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "domain": domain,
            }
        )
        if marketplace is not UNSET:
            field_dict["marketplace"] = marketplace
        if mcc is not UNSET:
            field_dict["mcc"] = mcc
        if merchant_id is not UNSET:
            field_dict["merchantId"] = merchant_id
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        domain = d.pop("domain")

        def _parse_marketplace(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        marketplace = _parse_marketplace(d.pop("marketplace", UNSET))

        def _parse_mcc(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mcc = _parse_mcc(d.pop("mcc", UNSET))

        def _parse_merchant_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        merchant_id = _parse_merchant_id(d.pop("merchantId", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        checkout_merchant = cls(
            domain=domain,
            marketplace=marketplace,
            mcc=mcc,
            merchant_id=merchant_id,
            name=name,
        )

        checkout_merchant.additional_properties = d
        return checkout_merchant

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
