from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="ActivateRequest")


@_attrs_define
class ActivateRequest:
    """
    Attributes:
        business_type (str): `"sole_prop"` | `"llc"` | `"corp"` | `"dao"` | `"other"`
        jurisdiction (str):
        payout_wallet_address (str):
        token (str):
        tos_version (str):
        chain (None | str | Unset): Settlement chain for the payout wallet. Must be a member of
            `merchants::LIVE_CHAINS`; non-live chains are rejected with a hint to
            use the waitlist endpoint. It may be omitted only while a single
            settlement chain is live.
        ip_address (None | str | Unset):
        legal_name (None | str | Unset):
        website (None | str | Unset):
    """

    business_type: str
    jurisdiction: str
    payout_wallet_address: str
    token: str
    tos_version: str
    chain: None | str | Unset = UNSET
    ip_address: None | str | Unset = UNSET
    legal_name: None | str | Unset = UNSET
    website: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        business_type = self.business_type

        jurisdiction = self.jurisdiction

        payout_wallet_address = self.payout_wallet_address

        token = self.token

        tos_version = self.tos_version

        chain: None | str | Unset
        if isinstance(self.chain, Unset):
            chain = UNSET
        else:
            chain = self.chain

        ip_address: None | str | Unset
        if isinstance(self.ip_address, Unset):
            ip_address = UNSET
        else:
            ip_address = self.ip_address

        legal_name: None | str | Unset
        if isinstance(self.legal_name, Unset):
            legal_name = UNSET
        else:
            legal_name = self.legal_name

        website: None | str | Unset
        if isinstance(self.website, Unset):
            website = UNSET
        else:
            website = self.website

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "business_type": business_type,
                "jurisdiction": jurisdiction,
                "payout_wallet_address": payout_wallet_address,
                "token": token,
                "tos_version": tos_version,
            }
        )
        if chain is not UNSET:
            field_dict["chain"] = chain
        if ip_address is not UNSET:
            field_dict["ip_address"] = ip_address
        if legal_name is not UNSET:
            field_dict["legal_name"] = legal_name
        if website is not UNSET:
            field_dict["website"] = website

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        business_type = d.pop("business_type")

        jurisdiction = d.pop("jurisdiction")

        payout_wallet_address = d.pop("payout_wallet_address")

        token = d.pop("token")

        tos_version = d.pop("tos_version")

        def _parse_chain(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chain = _parse_chain(d.pop("chain", UNSET))

        def _parse_ip_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ip_address = _parse_ip_address(d.pop("ip_address", UNSET))

        def _parse_legal_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        legal_name = _parse_legal_name(d.pop("legal_name", UNSET))

        def _parse_website(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        website = _parse_website(d.pop("website", UNSET))

        activate_request = cls(
            business_type=business_type,
            jurisdiction=jurisdiction,
            payout_wallet_address=payout_wallet_address,
            token=token,
            tos_version=tos_version,
            chain=chain,
            ip_address=ip_address,
            legal_name=legal_name,
            website=website,
        )

        activate_request.additional_properties = d
        return activate_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
