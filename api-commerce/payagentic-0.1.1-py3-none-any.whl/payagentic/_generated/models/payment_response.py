from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.payment_response_credential_type_0 import PaymentResponseCredentialType0


T = TypeVar("T", bound="PaymentResponse")


@_attrs_define
class PaymentResponse:
    """Payment resource returned by the API.

    Attributes:
        credential (None | PaymentResponseCredentialType0): Rail-formatted credential header returned on approve/settled
            success.

            An object with `header_name` and `header_value` keys.  The header name
            is rail-specific: `X-Payment` for x402 legacy, `Authorization` (with a
            `Payment <base64>` value) for MPP, `PAYMENT-SIGNATURE` for x402 v2.
            The SDK sets `header_name: header_value` verbatim when retrying the
            upstream vendor request.  Present on 200; absent (null) on
            pending-approval (202) or failure.
        id (UUID): Payment intent identifier (`UUIDv7`). Example: 019433e0-1b3c-7d0a-8e4f-000000000020.
        status (str): Current payment status ("proposed", "approved", "signed", "settled", "failed"). Example: settled.
        latency_ms (int | None | Unset): Processing latency in milliseconds. Example: 42.
        payment_signature (None | str | Unset): Legacy EIP-3009 signature string (present when approved/settled for
            backwards-compat; prefer `credential` for the rail-formatted header). Example: sig_base64encodedvalue.
    """

    credential: None | PaymentResponseCredentialType0
    id: UUID
    status: str
    latency_ms: int | None | Unset = UNSET
    payment_signature: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.payment_response_credential_type_0 import PaymentResponseCredentialType0

        credential: dict[str, Any] | None
        if isinstance(self.credential, PaymentResponseCredentialType0):
            credential = self.credential.to_dict()
        else:
            credential = self.credential

        id = str(self.id)

        status = self.status

        latency_ms: int | None | Unset
        if isinstance(self.latency_ms, Unset):
            latency_ms = UNSET
        else:
            latency_ms = self.latency_ms

        payment_signature: None | str | Unset
        if isinstance(self.payment_signature, Unset):
            payment_signature = UNSET
        else:
            payment_signature = self.payment_signature

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "credential": credential,
                "id": id,
                "status": status,
            }
        )
        if latency_ms is not UNSET:
            field_dict["latency_ms"] = latency_ms
        if payment_signature is not UNSET:
            field_dict["payment_signature"] = payment_signature

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.payment_response_credential_type_0 import PaymentResponseCredentialType0

        d = dict(src_dict)

        def _parse_credential(data: object) -> None | PaymentResponseCredentialType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                credential_type_0 = PaymentResponseCredentialType0.from_dict(data)

                return credential_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PaymentResponseCredentialType0, data)

        credential = _parse_credential(d.pop("credential"))

        id = UUID(d.pop("id"))

        status = d.pop("status")

        def _parse_latency_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        latency_ms = _parse_latency_ms(d.pop("latency_ms", UNSET))

        def _parse_payment_signature(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        payment_signature = _parse_payment_signature(d.pop("payment_signature", UNSET))

        payment_response = cls(
            credential=credential,
            id=id,
            status=status,
            latency_ms=latency_ms,
            payment_signature=payment_signature,
        )

        payment_response.additional_properties = d
        return payment_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
