from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
    from ..models.capability_draft_response_manifest import CapabilityDraftResponseManifest
    from ..models.draft_byte_counts import DraftByteCounts
    from ..models.draft_checksums import DraftChecksums


T = TypeVar("T", bound="CapabilityDraftResponse")


@_attrs_define
class CapabilityDraftResponse:
    """
    Attributes:
        byte_counts (DraftByteCounts):
        categories (list[str]):
        checksums (DraftChecksums):
        created_at (datetime.datetime):
        description (str):
        draft_revision_id (UUID):
        has_private_knowledge (bool):
        id (UUID):
        lifecycle (str):
        manifest (CapabilityDraftResponseManifest):
        name (str):
        revision (int):
        slug (str):
        tags (list[str]):
        updated_at (datetime.datetime):
    """

    byte_counts: DraftByteCounts
    categories: list[str]
    checksums: DraftChecksums
    created_at: datetime.datetime
    description: str
    draft_revision_id: UUID
    has_private_knowledge: bool
    id: UUID
    lifecycle: str
    manifest: CapabilityDraftResponseManifest
    name: str
    revision: int
    slug: str
    tags: list[str]
    updated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.capability_draft_response_manifest import CapabilityDraftResponseManifest
        from ..models.draft_byte_counts import DraftByteCounts
        from ..models.draft_checksums import DraftChecksums

        byte_counts = self.byte_counts.to_dict()

        categories = self.categories

        checksums = self.checksums.to_dict()

        created_at = self.created_at.isoformat()

        description = self.description

        draft_revision_id = str(self.draft_revision_id)

        has_private_knowledge = self.has_private_knowledge

        id = str(self.id)

        lifecycle = self.lifecycle

        manifest = self.manifest.to_dict()

        name = self.name

        revision = self.revision

        slug = self.slug

        tags = self.tags

        updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "byteCounts": byte_counts,
                "categories": categories,
                "checksums": checksums,
                "createdAt": created_at,
                "description": description,
                "draftRevisionId": draft_revision_id,
                "hasPrivateKnowledge": has_private_knowledge,
                "id": id,
                "lifecycle": lifecycle,
                "manifest": manifest,
                "name": name,
                "revision": revision,
                "slug": slug,
                "tags": tags,
                "updatedAt": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.capability_draft_response_manifest import CapabilityDraftResponseManifest
        from ..models.draft_byte_counts import DraftByteCounts
        from ..models.draft_checksums import DraftChecksums

        d = dict(src_dict)
        byte_counts = DraftByteCounts.from_dict(d.pop("byteCounts"))

        categories = cast(list[str], d.pop("categories"))

        checksums = DraftChecksums.from_dict(d.pop("checksums"))

        created_at = isoparse(d.pop("createdAt"))

        description = d.pop("description")

        draft_revision_id = UUID(d.pop("draftRevisionId"))

        has_private_knowledge = d.pop("hasPrivateKnowledge")

        id = UUID(d.pop("id"))

        lifecycle = d.pop("lifecycle")

        manifest = CapabilityDraftResponseManifest.from_dict(d.pop("manifest"))

        name = d.pop("name")

        revision = d.pop("revision")

        slug = d.pop("slug")

        tags = cast(list[str], d.pop("tags"))

        updated_at = isoparse(d.pop("updatedAt"))

        capability_draft_response = cls(
            byte_counts=byte_counts,
            categories=categories,
            checksums=checksums,
            created_at=created_at,
            description=description,
            draft_revision_id=draft_revision_id,
            has_private_knowledge=has_private_knowledge,
            id=id,
            lifecycle=lifecycle,
            manifest=manifest,
            name=name,
            revision=revision,
            slug=slug,
            tags=tags,
            updated_at=updated_at,
        )

        capability_draft_response.additional_properties = d
        return capability_draft_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
