from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="BlueprintGuardrails")


@_attrs_define
class BlueprintGuardrails:
    """
    Attributes:
        approval_above (str):
        currency (str):
        per_transaction (str):
        rolling_24_hours (str):
        rolling_30_days (str):
        velocity_per_24_hours (int):
    """

    approval_above: str
    currency: str
    per_transaction: str
    rolling_24_hours: str
    rolling_30_days: str
    velocity_per_24_hours: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        approval_above = self.approval_above

        currency = self.currency

        per_transaction = self.per_transaction

        rolling_24_hours = self.rolling_24_hours

        rolling_30_days = self.rolling_30_days

        velocity_per_24_hours = self.velocity_per_24_hours

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "approvalAbove": approval_above,
                "currency": currency,
                "perTransaction": per_transaction,
                "rolling24Hours": rolling_24_hours,
                "rolling30Days": rolling_30_days,
                "velocityPer24Hours": velocity_per_24_hours,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        approval_above = d.pop("approvalAbove")

        currency = d.pop("currency")

        per_transaction = d.pop("perTransaction")

        rolling_24_hours = d.pop("rolling24Hours")

        rolling_30_days = d.pop("rolling30Days")

        velocity_per_24_hours = d.pop("velocityPer24Hours")

        blueprint_guardrails = cls(
            approval_above=approval_above,
            currency=currency,
            per_transaction=per_transaction,
            rolling_24_hours=rolling_24_hours,
            rolling_30_days=rolling_30_days,
            velocity_per_24_hours=velocity_per_24_hours,
        )

        blueprint_guardrails.additional_properties = d
        return blueprint_guardrails

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
