from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="CheckoutItem")


@_attrs_define
class CheckoutItem:
    """
    Attributes:
        currency (str):
        id (UUID):
        metadata (Any):
        quantity (int):
        risk_flags (list[str]):
        title (str):
        unit_price (str):
        category (None | str | Unset):
        sku (None | str | Unset):
        url (None | str | Unset):
    """

    currency: str
    id: UUID
    metadata: Any
    quantity: int
    risk_flags: list[str]
    title: str
    unit_price: str
    category: None | str | Unset = UNSET
    sku: None | str | Unset = UNSET
    url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        currency = self.currency

        id = str(self.id)

        metadata = self.metadata

        quantity = self.quantity

        risk_flags = self.risk_flags

        title = self.title

        unit_price = self.unit_price

        category: None | str | Unset
        if isinstance(self.category, Unset):
            category = UNSET
        else:
            category = self.category

        sku: None | str | Unset
        if isinstance(self.sku, Unset):
            sku = UNSET
        else:
            sku = self.sku

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "currency": currency,
                "id": id,
                "metadata": metadata,
                "quantity": quantity,
                "riskFlags": risk_flags,
                "title": title,
                "unitPrice": unit_price,
            }
        )
        if category is not UNSET:
            field_dict["category"] = category
        if sku is not UNSET:
            field_dict["sku"] = sku
        if url is not UNSET:
            field_dict["url"] = url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        currency = d.pop("currency")

        id = UUID(d.pop("id"))

        metadata = d.pop("metadata")

        quantity = d.pop("quantity")

        risk_flags = cast(list[str], d.pop("riskFlags"))

        title = d.pop("title")

        unit_price = d.pop("unitPrice")

        def _parse_category(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        category = _parse_category(d.pop("category", UNSET))

        def _parse_sku(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sku = _parse_sku(d.pop("sku", UNSET))

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        checkout_item = cls(
            currency=currency,
            id=id,
            metadata=metadata,
            quantity=quantity,
            risk_flags=risk_flags,
            title=title,
            unit_price=unit_price,
            category=category,
            sku=sku,
            url=url,
        )

        checkout_item.additional_properties = d
        return checkout_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
