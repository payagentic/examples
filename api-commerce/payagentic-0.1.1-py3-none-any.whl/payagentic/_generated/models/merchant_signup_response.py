from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime


T = TypeVar("T", bound="MerchantSignupResponse")


@_attrs_define
class MerchantSignupResponse:
    """
    Attributes:
        expires_at (datetime.datetime):
        next_steps (str):
        signup_token (None | str | Unset): Raw signup token. Only returned when `APP_RETURN_SIGNUP_TOKEN=true`
            (dev convenience). In production, the token only reaches the user
            via the activation email.
    """

    expires_at: datetime.datetime
    next_steps: str
    signup_token: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        expires_at = self.expires_at.isoformat()

        next_steps = self.next_steps

        signup_token: None | str | Unset
        if isinstance(self.signup_token, Unset):
            signup_token = UNSET
        else:
            signup_token = self.signup_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "expires_at": expires_at,
                "next_steps": next_steps,
            }
        )
        if signup_token is not UNSET:
            field_dict["signup_token"] = signup_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        expires_at = isoparse(d.pop("expires_at"))

        next_steps = d.pop("next_steps")

        def _parse_signup_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        signup_token = _parse_signup_token(d.pop("signup_token", UNSET))

        merchant_signup_response = cls(
            expires_at=expires_at,
            next_steps=next_steps,
            signup_token=signup_token,
        )

        merchant_signup_response.additional_properties = d
        return merchant_signup_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
