from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_refunds_response import ListRefundsResponse
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime


def _get_kwargs(
    *,
    payment_id: UUID | Unset = UNSET,
    limit: int | Unset = UNSET,
    cursor: datetime.datetime | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_payment_id: str | Unset = UNSET
    if not isinstance(payment_id, Unset):
        json_payment_id = str(payment_id)
    params["payment_id"] = json_payment_id

    params["limit"] = limit

    json_cursor: str | Unset = UNSET
    if not isinstance(cursor, Unset):
        json_cursor = cursor.isoformat()
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/refunds",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListRefundsResponse | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = ListRefundsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListRefundsResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    payment_id: UUID | Unset = UNSET,
    limit: int | Unset = UNSET,
    cursor: datetime.datetime | Unset = UNSET,
) -> Response[ListRefundsResponse | ProblemDetails]:
    """List the caller merchant's refunds (cursor-paginated by `requested_at`).

     Always filtered by the calling merchant key's `merchant_id` — no
    merchant can read another merchant's refunds. Optional `?payment_id`
    filter narrows to a single payment. Default page size 50, max 200.

    Args:
        payment_id (UUID | Unset):
        limit (int | Unset):
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListRefundsResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        payment_id=payment_id,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    payment_id: UUID | Unset = UNSET,
    limit: int | Unset = UNSET,
    cursor: datetime.datetime | Unset = UNSET,
) -> ListRefundsResponse | ProblemDetails | None:
    """List the caller merchant's refunds (cursor-paginated by `requested_at`).

     Always filtered by the calling merchant key's `merchant_id` — no
    merchant can read another merchant's refunds. Optional `?payment_id`
    filter narrows to a single payment. Default page size 50, max 200.

    Args:
        payment_id (UUID | Unset):
        limit (int | Unset):
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListRefundsResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        payment_id=payment_id,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    payment_id: UUID | Unset = UNSET,
    limit: int | Unset = UNSET,
    cursor: datetime.datetime | Unset = UNSET,
) -> Response[ListRefundsResponse | ProblemDetails]:
    """List the caller merchant's refunds (cursor-paginated by `requested_at`).

     Always filtered by the calling merchant key's `merchant_id` — no
    merchant can read another merchant's refunds. Optional `?payment_id`
    filter narrows to a single payment. Default page size 50, max 200.

    Args:
        payment_id (UUID | Unset):
        limit (int | Unset):
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListRefundsResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        payment_id=payment_id,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    payment_id: UUID | Unset = UNSET,
    limit: int | Unset = UNSET,
    cursor: datetime.datetime | Unset = UNSET,
) -> ListRefundsResponse | ProblemDetails | None:
    """List the caller merchant's refunds (cursor-paginated by `requested_at`).

     Always filtered by the calling merchant key's `merchant_id` — no
    merchant can read another merchant's refunds. Optional `?payment_id`
    filter narrows to a single payment. Default page size 50, max 200.

    Args:
        payment_id (UUID | Unset):
        limit (int | Unset):
        cursor (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListRefundsResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            payment_id=payment_id,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
