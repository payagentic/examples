from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.linked_wallet_row import LinkedWalletRow
from ...models.problem_details import ProblemDetails
from ...models.register_linked_wallet_request import RegisterLinkedWalletRequest
from typing import cast


def _get_kwargs(
    *,
    body: RegisterLinkedWalletRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/linked-wallets",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> LinkedWalletRow | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = LinkedWalletRow.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = ProblemDetails.from_dict(response.json())

        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[LinkedWalletRow | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: RegisterLinkedWalletRequest,
) -> Response[LinkedWalletRow | ProblemDetails]:
    """Register a new linked wallet with an ownership proof.

     Accepts two proof methods: `privy_linked_account` (address attested by
    Privy) or `challenge_signature` (EIP-191 `personal_sign` over the issued
    challenge message). Runs a sanctions screen before inserting; flagged
    wallets are stored frozen and the request returns 403.

    Args:
        body (RegisterLinkedWalletRequest): Request body for `POST /v1/linked-wallets`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LinkedWalletRow | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: RegisterLinkedWalletRequest,
) -> LinkedWalletRow | ProblemDetails | None:
    """Register a new linked wallet with an ownership proof.

     Accepts two proof methods: `privy_linked_account` (address attested by
    Privy) or `challenge_signature` (EIP-191 `personal_sign` over the issued
    challenge message). Runs a sanctions screen before inserting; flagged
    wallets are stored frozen and the request returns 403.

    Args:
        body (RegisterLinkedWalletRequest): Request body for `POST /v1/linked-wallets`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LinkedWalletRow | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: RegisterLinkedWalletRequest,
) -> Response[LinkedWalletRow | ProblemDetails]:
    """Register a new linked wallet with an ownership proof.

     Accepts two proof methods: `privy_linked_account` (address attested by
    Privy) or `challenge_signature` (EIP-191 `personal_sign` over the issued
    challenge message). Runs a sanctions screen before inserting; flagged
    wallets are stored frozen and the request returns 403.

    Args:
        body (RegisterLinkedWalletRequest): Request body for `POST /v1/linked-wallets`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LinkedWalletRow | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: RegisterLinkedWalletRequest,
) -> LinkedWalletRow | ProblemDetails | None:
    """Register a new linked wallet with an ownership proof.

     Accepts two proof methods: `privy_linked_account` (address attested by
    Privy) or `challenge_signature` (EIP-191 `personal_sign` over the issued
    challenge message). Runs a sanctions screen before inserting; flagged
    wallets are stored frozen and the request returns 403.

    Args:
        body (RegisterLinkedWalletRequest): Request body for `POST /v1/linked-wallets`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LinkedWalletRow | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
