from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.challenge_request import ChallengeRequest
from ...models.issued_challenge import IssuedChallenge
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: ChallengeRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/linked-wallets/challenge",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> IssuedChallenge | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = IssuedChallenge.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[IssuedChallenge | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ChallengeRequest,
) -> Response[IssuedChallenge | ProblemDetails]:
    """Issue a signing challenge for an Ethereum address.

     Returns a message the caller must sign with the target wallet and submit
    to `POST /v1/linked-wallets` with `proof_method = challenge_signature`.
    The challenge expires after 10 minutes and is single-use.

    Args:
        body (ChallengeRequest): Request body for `POST /v1/linked-wallets/challenge`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IssuedChallenge | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ChallengeRequest,
) -> IssuedChallenge | ProblemDetails | None:
    """Issue a signing challenge for an Ethereum address.

     Returns a message the caller must sign with the target wallet and submit
    to `POST /v1/linked-wallets` with `proof_method = challenge_signature`.
    The challenge expires after 10 minutes and is single-use.

    Args:
        body (ChallengeRequest): Request body for `POST /v1/linked-wallets/challenge`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IssuedChallenge | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ChallengeRequest,
) -> Response[IssuedChallenge | ProblemDetails]:
    """Issue a signing challenge for an Ethereum address.

     Returns a message the caller must sign with the target wallet and submit
    to `POST /v1/linked-wallets` with `proof_method = challenge_signature`.
    The challenge expires after 10 minutes and is single-use.

    Args:
        body (ChallengeRequest): Request body for `POST /v1/linked-wallets/challenge`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IssuedChallenge | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ChallengeRequest,
) -> IssuedChallenge | ProblemDetails | None:
    """Issue a signing challenge for an Ethereum address.

     Returns a message the caller must sign with the target wallet and submit
    to `POST /v1/linked-wallets` with `proof_method = challenge_signature`.
    The challenge expires after 10 minutes and is single-use.

    Args:
        body (ChallengeRequest): Request body for `POST /v1/linked-wallets/challenge`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IssuedChallenge | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
