from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.signup_request import SignupRequest
from ...models.signup_response import SignupResponse
from typing import cast


def _get_kwargs(
    *,
    body: SignupRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/signup",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | SignupResponse | None:
    if response.status_code == 201:
        response_201 = SignupResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 409:
        response_409 = ProblemDetails.from_dict(response.json())

        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | SignupResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: SignupRequest,
) -> Response[ProblemDetails | SignupResponse]:
    """Self-service signup -- provision an org + default agent + default wallet.

     Open (no auth). Returns the agent's API key (shown once) and the
    wallet's on-chain address. Fund the wallet with the supported
    stablecoin for the selected network before calling `/v1/payments/propose`;
    some networks also require a small native gas balance.

    Args:
        body (SignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | SignupResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: SignupRequest,
) -> ProblemDetails | SignupResponse | None:
    """Self-service signup -- provision an org + default agent + default wallet.

     Open (no auth). Returns the agent's API key (shown once) and the
    wallet's on-chain address. Fund the wallet with the supported
    stablecoin for the selected network before calling `/v1/payments/propose`;
    some networks also require a small native gas balance.

    Args:
        body (SignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | SignupResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: SignupRequest,
) -> Response[ProblemDetails | SignupResponse]:
    """Self-service signup -- provision an org + default agent + default wallet.

     Open (no auth). Returns the agent's API key (shown once) and the
    wallet's on-chain address. Fund the wallet with the supported
    stablecoin for the selected network before calling `/v1/payments/propose`;
    some networks also require a small native gas balance.

    Args:
        body (SignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | SignupResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: SignupRequest,
) -> ProblemDetails | SignupResponse | None:
    """Self-service signup -- provision an org + default agent + default wallet.

     Open (no auth). Returns the agent's API key (shown once) and the
    wallet's on-chain address. Fund the wallet with the supported
    stablecoin for the selected network before calling `/v1/payments/propose`;
    some networks also require a small native gas balance.

    Args:
        body (SignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | SignupResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
