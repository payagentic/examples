from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.paginated_audit import PaginatedAudit
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    limit: int | Unset = UNSET,
    cursor: str | Unset = UNSET,
    resource_id: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["cursor"] = cursor

    params["resourceId"] = resource_id

    params["resourceType"] = resource_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/audit",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedAudit | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = PaginatedAudit.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedAudit | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    cursor: str | Unset = UNSET,
    resource_id: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
) -> Response[PaginatedAudit | ProblemDetails]:
    """List org-scoped audit entries (cursor-paginated by `created_at`).

     Backed by `event_outbox` so domain events appear without a separate
    audit-log table. `cursor` is an RFC3339 timestamp from a prior page.

    Args:
        limit (int | Unset):
        cursor (str | Unset):
        resource_id (str | Unset):
        resource_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedAudit | ProblemDetails]
    """

    kwargs = _get_kwargs(
        limit=limit,
        cursor=cursor,
        resource_id=resource_id,
        resource_type=resource_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    cursor: str | Unset = UNSET,
    resource_id: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
) -> PaginatedAudit | ProblemDetails | None:
    """List org-scoped audit entries (cursor-paginated by `created_at`).

     Backed by `event_outbox` so domain events appear without a separate
    audit-log table. `cursor` is an RFC3339 timestamp from a prior page.

    Args:
        limit (int | Unset):
        cursor (str | Unset):
        resource_id (str | Unset):
        resource_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedAudit | ProblemDetails
    """

    return sync_detailed(
        client=client,
        limit=limit,
        cursor=cursor,
        resource_id=resource_id,
        resource_type=resource_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    cursor: str | Unset = UNSET,
    resource_id: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
) -> Response[PaginatedAudit | ProblemDetails]:
    """List org-scoped audit entries (cursor-paginated by `created_at`).

     Backed by `event_outbox` so domain events appear without a separate
    audit-log table. `cursor` is an RFC3339 timestamp from a prior page.

    Args:
        limit (int | Unset):
        cursor (str | Unset):
        resource_id (str | Unset):
        resource_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedAudit | ProblemDetails]
    """

    kwargs = _get_kwargs(
        limit=limit,
        cursor=cursor,
        resource_id=resource_id,
        resource_type=resource_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    cursor: str | Unset = UNSET,
    resource_id: str | Unset = UNSET,
    resource_type: str | Unset = UNSET,
) -> PaginatedAudit | ProblemDetails | None:
    """List org-scoped audit entries (cursor-paginated by `created_at`).

     Backed by `event_outbox` so domain events appear without a separate
    audit-log table. `cursor` is an RFC3339 timestamp from a prior page.

    Args:
        limit (int | Unset):
        cursor (str | Unset):
        resource_id (str | Unset):
        resource_type (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedAudit | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            cursor=cursor,
            resource_id=resource_id,
            resource_type=resource_type,
        )
    ).parsed
