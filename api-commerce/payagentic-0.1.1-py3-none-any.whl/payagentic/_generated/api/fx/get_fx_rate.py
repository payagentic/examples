from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.fx_rate import FxRate
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    from_: str,
    to: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["from"] = from_

    params["to"] = to

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/fx/rate",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FxRate | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = FxRate.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FxRate | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
) -> Response[FxRate | ProblemDetails]:
    """Get the current rate for a (from, to) currency pair.

     Stablecoin pairs against USD return `1.0` with `updatedAt = now()`.
    A real price oracle (Chainlink, `CoinGecko`) is on the v1.1 roadmap;
    for now this endpoint exists to give the dashboard a stable JSON
    shape instead of a 404.

    Args:
        from_ (str):
        to (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FxRate | ProblemDetails]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
) -> FxRate | ProblemDetails | None:
    """Get the current rate for a (from, to) currency pair.

     Stablecoin pairs against USD return `1.0` with `updatedAt = now()`.
    A real price oracle (Chainlink, `CoinGecko`) is on the v1.1 roadmap;
    for now this endpoint exists to give the dashboard a stable JSON
    shape instead of a 404.

    Args:
        from_ (str):
        to (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FxRate | ProblemDetails
    """

    return sync_detailed(
        client=client,
        from_=from_,
        to=to,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
) -> Response[FxRate | ProblemDetails]:
    """Get the current rate for a (from, to) currency pair.

     Stablecoin pairs against USD return `1.0` with `updatedAt = now()`.
    A real price oracle (Chainlink, `CoinGecko`) is on the v1.1 roadmap;
    for now this endpoint exists to give the dashboard a stable JSON
    shape instead of a 404.

    Args:
        from_ (str):
        to (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FxRate | ProblemDetails]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
) -> FxRate | ProblemDetails | None:
    """Get the current rate for a (from, to) currency pair.

     Stablecoin pairs against USD return `1.0` with `updatedAt = now()`.
    A real price oracle (Chainlink, `CoinGecko`) is on the v1.1 roadmap;
    for now this endpoint exists to give the dashboard a stable JSON
    shape instead of a 404.

    Args:
        from_ (str):
        to (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FxRate | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            from_=from_,
            to=to,
        )
    ).parsed
