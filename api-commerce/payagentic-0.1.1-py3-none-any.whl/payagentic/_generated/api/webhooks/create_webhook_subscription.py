from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_webhook_request import CreateWebhookRequest
from ...models.problem_details import ProblemDetails
from ...models.webhook_response import WebhookResponse
from typing import cast


def _get_kwargs(
    *,
    body: CreateWebhookRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/webhooks",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | WebhookResponse | None:
    if response.status_code == 201:
        response_201 = WebhookResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | WebhookResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateWebhookRequest,
) -> Response[ProblemDetails | WebhookResponse]:
    r"""Create a webhook subscription.

     The signing `secret` is returned exactly once in the response body
    — store it client-side immediately. The server keeps only a
    SHA-256 hash. `event_types` accepts `[\"*\"]` for all events or an
    explicit allow-list (`payment.settled`, `payout.failed`, etc.).

    Args:
        body (CreateWebhookRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | WebhookResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: CreateWebhookRequest,
) -> ProblemDetails | WebhookResponse | None:
    r"""Create a webhook subscription.

     The signing `secret` is returned exactly once in the response body
    — store it client-side immediately. The server keeps only a
    SHA-256 hash. `event_types` accepts `[\"*\"]` for all events or an
    explicit allow-list (`payment.settled`, `payout.failed`, etc.).

    Args:
        body (CreateWebhookRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | WebhookResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateWebhookRequest,
) -> Response[ProblemDetails | WebhookResponse]:
    r"""Create a webhook subscription.

     The signing `secret` is returned exactly once in the response body
    — store it client-side immediately. The server keeps only a
    SHA-256 hash. `event_types` accepts `[\"*\"]` for all events or an
    explicit allow-list (`payment.settled`, `payout.failed`, etc.).

    Args:
        body (CreateWebhookRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | WebhookResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateWebhookRequest,
) -> ProblemDetails | WebhookResponse | None:
    r"""Create a webhook subscription.

     The signing `secret` is returned exactly once in the response body
    — store it client-side immediately. The server keeps only a
    SHA-256 hash. `event_types` accepts `[\"*\"]` for all events or an
    explicit allow-list (`payment.settled`, `payout.failed`, etc.).

    Args:
        body (CreateWebhookRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | WebhookResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
