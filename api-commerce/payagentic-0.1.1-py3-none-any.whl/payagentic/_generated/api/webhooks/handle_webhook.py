from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    vendor: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/webhooks/{vendor}".format(
            vendor=quote(str(vendor), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = cast(Any, None)
        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    vendor: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | ProblemDetails]:
    """Receive a webhook from an external vendor.

     Supported vendors: `paystack`, `mpesa`, `yellow_card`, `stitch`, `smile_id`.
    Each vendor's signature is validated before processing.

    Args:
        vendor (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetails]
    """

    kwargs = _get_kwargs(
        vendor=vendor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    vendor: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | ProblemDetails | None:
    """Receive a webhook from an external vendor.

     Supported vendors: `paystack`, `mpesa`, `yellow_card`, `stitch`, `smile_id`.
    Each vendor's signature is validated before processing.

    Args:
        vendor (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ProblemDetails
    """

    return sync_detailed(
        vendor=vendor,
        client=client,
    ).parsed


async def asyncio_detailed(
    vendor: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | ProblemDetails]:
    """Receive a webhook from an external vendor.

     Supported vendors: `paystack`, `mpesa`, `yellow_card`, `stitch`, `smile_id`.
    Each vendor's signature is validated before processing.

    Args:
        vendor (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetails]
    """

    kwargs = _get_kwargs(
        vendor=vendor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    vendor: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | ProblemDetails | None:
    """Receive a webhook from an external vendor.

     Supported vendors: `paystack`, `mpesa`, `yellow_card`, `stitch`, `smile_id`.
    Each vendor's signature is validated before processing.

    Args:
        vendor (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ProblemDetails
    """

    return (
        await asyncio_detailed(
            vendor=vendor,
            client=client,
        )
    ).parsed
