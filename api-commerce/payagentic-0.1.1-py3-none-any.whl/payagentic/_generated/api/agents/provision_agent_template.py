from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.provision_agent_template_request import ProvisionAgentTemplateRequest
from ...models.provision_agent_template_response import ProvisionAgentTemplateResponse
from typing import cast


def _get_kwargs(
    slug: str,
    *,
    body: ProvisionAgentTemplateRequest,
    idempotency_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["Idempotency-Key"] = idempotency_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/agent-templates/{slug}/provision".format(
            slug=quote(str(slug), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | ProvisionAgentTemplateResponse | None:
    if response.status_code == 200:
        response_200 = ProvisionAgentTemplateResponse.from_dict(response.json())

        return response_200

    if response.status_code == 201:
        response_201 = ProvisionAgentTemplateResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = ProblemDetails.from_dict(response.json())

        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | ProvisionAgentTemplateResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: ProvisionAgentTemplateRequest,
    idempotency_key: str,
) -> Response[ProblemDetails | ProvisionAgentTemplateResponse]:
    """Atomically provision an agent, wallet authority, policy, and credential from a blueprint.

    Args:
        slug (str):
        idempotency_key (str):
        body (ProvisionAgentTemplateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ProvisionAgentTemplateResponse]
    """

    kwargs = _get_kwargs(
        slug=slug,
        body=body,
        idempotency_key=idempotency_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: ProvisionAgentTemplateRequest,
    idempotency_key: str,
) -> ProblemDetails | ProvisionAgentTemplateResponse | None:
    """Atomically provision an agent, wallet authority, policy, and credential from a blueprint.

    Args:
        slug (str):
        idempotency_key (str):
        body (ProvisionAgentTemplateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ProvisionAgentTemplateResponse
    """

    return sync_detailed(
        slug=slug,
        client=client,
        body=body,
        idempotency_key=idempotency_key,
    ).parsed


async def asyncio_detailed(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: ProvisionAgentTemplateRequest,
    idempotency_key: str,
) -> Response[ProblemDetails | ProvisionAgentTemplateResponse]:
    """Atomically provision an agent, wallet authority, policy, and credential from a blueprint.

    Args:
        slug (str):
        idempotency_key (str):
        body (ProvisionAgentTemplateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ProvisionAgentTemplateResponse]
    """

    kwargs = _get_kwargs(
        slug=slug,
        body=body,
        idempotency_key=idempotency_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: ProvisionAgentTemplateRequest,
    idempotency_key: str,
) -> ProblemDetails | ProvisionAgentTemplateResponse | None:
    """Atomically provision an agent, wallet authority, policy, and credential from a blueprint.

    Args:
        slug (str):
        idempotency_key (str):
        body (ProvisionAgentTemplateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ProvisionAgentTemplateResponse
    """

    return (
        await asyncio_detailed(
            slug=slug,
            client=client,
            body=body,
            idempotency_key=idempotency_key,
        )
    ).parsed
