from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.agent_response import AgentResponse
from ...models.create_agent_request import CreateAgentRequest
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: CreateAgentRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/agents",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentResponse | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = AgentResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateAgentRequest,
) -> Response[AgentResponse | ProblemDetails]:
    """Create a new AI agent.

    Args:
        body (CreateAgentRequest): Request body for creating a new AI agent.

            Field names mirror the handler's `CreateAgentBody` (camelCase). Previously
            this schema advertised a required snake_case `wallet_id`, which the handler
            (camelCase, optional) silently ignored, so SDK callers created agents with
            no wallet linked.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: CreateAgentRequest,
) -> AgentResponse | ProblemDetails | None:
    """Create a new AI agent.

    Args:
        body (CreateAgentRequest): Request body for creating a new AI agent.

            Field names mirror the handler's `CreateAgentBody` (camelCase). Previously
            this schema advertised a required snake_case `wallet_id`, which the handler
            (camelCase, optional) silently ignored, so SDK callers created agents with
            no wallet linked.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateAgentRequest,
) -> Response[AgentResponse | ProblemDetails]:
    """Create a new AI agent.

    Args:
        body (CreateAgentRequest): Request body for creating a new AI agent.

            Field names mirror the handler's `CreateAgentBody` (camelCase). Previously
            this schema advertised a required snake_case `wallet_id`, which the handler
            (camelCase, optional) silently ignored, so SDK callers created agents with
            no wallet linked.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateAgentRequest,
) -> AgentResponse | ProblemDetails | None:
    """Create a new AI agent.

    Args:
        body (CreateAgentRequest): Request body for creating a new AI agent.

            Field names mirror the handler's `CreateAgentBody` (camelCase). Previously
            this schema advertised a required snake_case `wallet_id`, which the handler
            (camelCase, optional) silently ignored, so SDK callers created agents with
            no wallet linked.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
