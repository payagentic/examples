from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.paginated_approvals import PaginatedApprovals
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    status: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["status"] = status

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/approvals",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedApprovals | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = PaginatedApprovals.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedApprovals | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    status: str | Unset = UNSET,
) -> Response[PaginatedApprovals | ProblemDetails]:
    """List approvals (transactions awaiting human review) for the org.

     Default filter is `status=pending`. The approve/reject actions
    themselves go through `POST /v1/payments/{id}/approve`.

    Args:
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedApprovals | ProblemDetails]
    """

    kwargs = _get_kwargs(
        status=status,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    status: str | Unset = UNSET,
) -> PaginatedApprovals | ProblemDetails | None:
    """List approvals (transactions awaiting human review) for the org.

     Default filter is `status=pending`. The approve/reject actions
    themselves go through `POST /v1/payments/{id}/approve`.

    Args:
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedApprovals | ProblemDetails
    """

    return sync_detailed(
        client=client,
        status=status,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    status: str | Unset = UNSET,
) -> Response[PaginatedApprovals | ProblemDetails]:
    """List approvals (transactions awaiting human review) for the org.

     Default filter is `status=pending`. The approve/reject actions
    themselves go through `POST /v1/payments/{id}/approve`.

    Args:
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedApprovals | ProblemDetails]
    """

    kwargs = _get_kwargs(
        status=status,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    status: str | Unset = UNSET,
) -> PaginatedApprovals | ProblemDetails | None:
    """List approvals (transactions awaiting human review) for the org.

     Default filter is `status=pending`. The approve/reject actions
    themselves go through `POST /v1/payments/{id}/approve`.

    Args:
        status (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedApprovals | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            status=status,
        )
    ).parsed
