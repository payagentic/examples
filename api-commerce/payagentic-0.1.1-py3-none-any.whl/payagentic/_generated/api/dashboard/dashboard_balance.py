from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.org_balance import OrgBalance
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    range_: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["range"] = range_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/dashboard/balance",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> OrgBalance | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = OrgBalance.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OrgBalance | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> Response[OrgBalance | ProblemDetails]:
    """Get the organization balance time series for the requested range.

     Returns the current total, absolute and percentage delta over the
    window, and a bucketed history series for the balance chart.
    Accepts `range` query param: `1H`, `1D`, `1W`, `1M` (default), `1Y`.

    Args:
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrgBalance | ProblemDetails]
    """

    kwargs = _get_kwargs(
        range_=range_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> OrgBalance | ProblemDetails | None:
    """Get the organization balance time series for the requested range.

     Returns the current total, absolute and percentage delta over the
    window, and a bucketed history series for the balance chart.
    Accepts `range` query param: `1H`, `1D`, `1W`, `1M` (default), `1Y`.

    Args:
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrgBalance | ProblemDetails
    """

    return sync_detailed(
        client=client,
        range_=range_,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> Response[OrgBalance | ProblemDetails]:
    """Get the organization balance time series for the requested range.

     Returns the current total, absolute and percentage delta over the
    window, and a bucketed history series for the balance chart.
    Accepts `range` query param: `1H`, `1D`, `1W`, `1M` (default), `1Y`.

    Args:
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OrgBalance | ProblemDetails]
    """

    kwargs = _get_kwargs(
        range_=range_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> OrgBalance | ProblemDetails | None:
    """Get the organization balance time series for the requested range.

     Returns the current total, absolute and percentage delta over the
    window, and a bucketed history series for the balance chart.
    Accepts `range` query param: `1H`, `1D`, `1W`, `1M` (default), `1Y`.

    Args:
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OrgBalance | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            range_=range_,
        )
    ).parsed
