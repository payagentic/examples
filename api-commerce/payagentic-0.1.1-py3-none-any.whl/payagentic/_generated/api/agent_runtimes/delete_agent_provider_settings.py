from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.provider_settings_response import ProviderSettingsResponse
from typing import cast


def _get_kwargs(
    provider_key: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/agent-runtimes/{provider_key}/settings".format(
            provider_key=quote(str(provider_key), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | ProviderSettingsResponse | None:
    if response.status_code == 200:
        response_200 = ProviderSettingsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | ProviderSettingsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider_key: str,
    *,
    client: AuthenticatedClient,
) -> Response[ProblemDetails | ProviderSettingsResponse]:
    """Delete provider settings for an agent runtime.

    Args:
        provider_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ProviderSettingsResponse]
    """

    kwargs = _get_kwargs(
        provider_key=provider_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider_key: str,
    *,
    client: AuthenticatedClient,
) -> ProblemDetails | ProviderSettingsResponse | None:
    """Delete provider settings for an agent runtime.

    Args:
        provider_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ProviderSettingsResponse
    """

    return sync_detailed(
        provider_key=provider_key,
        client=client,
    ).parsed


async def asyncio_detailed(
    provider_key: str,
    *,
    client: AuthenticatedClient,
) -> Response[ProblemDetails | ProviderSettingsResponse]:
    """Delete provider settings for an agent runtime.

    Args:
        provider_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ProviderSettingsResponse]
    """

    kwargs = _get_kwargs(
        provider_key=provider_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider_key: str,
    *,
    client: AuthenticatedClient,
) -> ProblemDetails | ProviderSettingsResponse | None:
    """Delete provider settings for an agent runtime.

    Args:
        provider_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ProviderSettingsResponse
    """

    return (
        await asyncio_detailed(
            provider_key=provider_key,
            client=client,
        )
    ).parsed
