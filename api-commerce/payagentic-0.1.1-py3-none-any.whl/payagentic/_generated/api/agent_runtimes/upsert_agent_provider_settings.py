from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.provider_settings_response import ProviderSettingsResponse
from ...models.update_provider_settings_request import UpdateProviderSettingsRequest
from typing import cast


def _get_kwargs(
    provider_key: str,
    *,
    body: UpdateProviderSettingsRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/agent-runtimes/{provider_key}/settings".format(
            provider_key=quote(str(provider_key), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | ProviderSettingsResponse | None:
    if response.status_code == 200:
        response_200 = ProviderSettingsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | ProviderSettingsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider_key: str,
    *,
    client: AuthenticatedClient,
    body: UpdateProviderSettingsRequest,
) -> Response[ProblemDetails | ProviderSettingsResponse]:
    """Create or update provider settings for an agent runtime.

    Args:
        provider_key (str):
        body (UpdateProviderSettingsRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ProviderSettingsResponse]
    """

    kwargs = _get_kwargs(
        provider_key=provider_key,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider_key: str,
    *,
    client: AuthenticatedClient,
    body: UpdateProviderSettingsRequest,
) -> ProblemDetails | ProviderSettingsResponse | None:
    """Create or update provider settings for an agent runtime.

    Args:
        provider_key (str):
        body (UpdateProviderSettingsRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ProviderSettingsResponse
    """

    return sync_detailed(
        provider_key=provider_key,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    provider_key: str,
    *,
    client: AuthenticatedClient,
    body: UpdateProviderSettingsRequest,
) -> Response[ProblemDetails | ProviderSettingsResponse]:
    """Create or update provider settings for an agent runtime.

    Args:
        provider_key (str):
        body (UpdateProviderSettingsRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ProviderSettingsResponse]
    """

    kwargs = _get_kwargs(
        provider_key=provider_key,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider_key: str,
    *,
    client: AuthenticatedClient,
    body: UpdateProviderSettingsRequest,
) -> ProblemDetails | ProviderSettingsResponse | None:
    """Create or update provider settings for an agent runtime.

    Args:
        provider_key (str):
        body (UpdateProviderSettingsRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ProviderSettingsResponse
    """

    return (
        await asyncio_detailed(
            provider_key=provider_key,
            client=client,
            body=body,
        )
    ).parsed
