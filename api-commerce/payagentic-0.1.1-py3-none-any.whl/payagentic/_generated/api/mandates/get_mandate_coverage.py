from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.mandate_coverage import MandateCoverage
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    window_days: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["window_days"] = window_days

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/mandates/coverage",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> MandateCoverage | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = MandateCoverage.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[MandateCoverage | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    window_days: int | Unset = UNSET,
) -> Response[MandateCoverage | ProblemDetails]:
    """Mandate coverage metric over a recent settled-transaction window.

     Returns `total` settled charges and the subset `with_mandate` over
    the last `window_days` (default 7, range 1..=365). The web client
    computes the percentage.

    Args:
        window_days (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MandateCoverage | ProblemDetails]
    """

    kwargs = _get_kwargs(
        window_days=window_days,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    window_days: int | Unset = UNSET,
) -> MandateCoverage | ProblemDetails | None:
    """Mandate coverage metric over a recent settled-transaction window.

     Returns `total` settled charges and the subset `with_mandate` over
    the last `window_days` (default 7, range 1..=365). The web client
    computes the percentage.

    Args:
        window_days (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MandateCoverage | ProblemDetails
    """

    return sync_detailed(
        client=client,
        window_days=window_days,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    window_days: int | Unset = UNSET,
) -> Response[MandateCoverage | ProblemDetails]:
    """Mandate coverage metric over a recent settled-transaction window.

     Returns `total` settled charges and the subset `with_mandate` over
    the last `window_days` (default 7, range 1..=365). The web client
    computes the percentage.

    Args:
        window_days (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MandateCoverage | ProblemDetails]
    """

    kwargs = _get_kwargs(
        window_days=window_days,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    window_days: int | Unset = UNSET,
) -> MandateCoverage | ProblemDetails | None:
    """Mandate coverage metric over a recent settled-transaction window.

     Returns `total` settled charges and the subset `with_mandate` over
    the last `window_days` (default 7, range 1..=365). The web client
    computes the percentage.

    Args:
        window_days (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MandateCoverage | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            window_days=window_days,
        )
    ).parsed
