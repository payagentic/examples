from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.x402_verify_request import X402VerifyRequest
from ...models.x402_verify_response import X402VerifyResponse
from typing import cast


def _get_kwargs(
    *,
    body: X402VerifyRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/x402/verify",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | X402VerifyResponse | None:
    if response.status_code == 200:
        response_200 = X402VerifyResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | X402VerifyResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: X402VerifyRequest,
) -> Response[ProblemDetails | X402VerifyResponse]:
    """Verify an x402 payment signature.

     Called by resource servers that received a payment from a client.
    Verifies the payment signature is valid and that funds have settled
    on-chain.

    Args:
        body (X402VerifyRequest): Request body for verifying an x402 payment.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | X402VerifyResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: X402VerifyRequest,
) -> ProblemDetails | X402VerifyResponse | None:
    """Verify an x402 payment signature.

     Called by resource servers that received a payment from a client.
    Verifies the payment signature is valid and that funds have settled
    on-chain.

    Args:
        body (X402VerifyRequest): Request body for verifying an x402 payment.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | X402VerifyResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: X402VerifyRequest,
) -> Response[ProblemDetails | X402VerifyResponse]:
    """Verify an x402 payment signature.

     Called by resource servers that received a payment from a client.
    Verifies the payment signature is valid and that funds have settled
    on-chain.

    Args:
        body (X402VerifyRequest): Request body for verifying an x402 payment.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | X402VerifyResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: X402VerifyRequest,
) -> ProblemDetails | X402VerifyResponse | None:
    """Verify an x402 payment signature.

     Called by resource servers that received a payment from a client.
    Verifies the payment signature is valid and that funds have settled
    on-chain.

    Args:
        body (X402VerifyRequest): Request body for verifying an x402 payment.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | X402VerifyResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
