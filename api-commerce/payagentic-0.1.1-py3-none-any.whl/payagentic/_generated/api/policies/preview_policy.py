from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.preview_body import PreviewBody
from ...models.preview_response import PreviewResponse
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: PreviewBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/policies/preview",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PreviewResponse | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = PreviewResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PreviewResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: PreviewBody,
) -> Response[PreviewResponse | ProblemDetails]:
    r"""Live policy preview for the Move Funds widget.

     Fires on every keystroke in the dashboard's amount field (debounced
    300ms client-side). Always returns 200 with a `decision` of
    `\"allow\"` or `\"deny\"` plus a human reason — validation errors are
    expressed as denies rather than 4xx so the UI can show inline copy
    without a generic toast. The authoritative policy decision still
    runs server-side at `POST /v1/transfers` time.

    Args:
        body (PreviewBody): Inbound shape for `POST /v1/policies/preview`. Mirrors
            `web/src/app/_hooks/right/use-policy-preview.ts#PolicyPreviewIntent`
            — every field is camelCase coming from the dashboard's `api.post`.

            `source_id` is deserialized for parity with the wallet-id contract but
            not yet used — wallet org-membership is enforced server-side at
            `POST /v1/transfers` time. `#[allow(dead_code)]` keeps the field
            visible in the API surface without tripping the unused-field lint.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PreviewResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: PreviewBody,
) -> PreviewResponse | ProblemDetails | None:
    r"""Live policy preview for the Move Funds widget.

     Fires on every keystroke in the dashboard's amount field (debounced
    300ms client-side). Always returns 200 with a `decision` of
    `\"allow\"` or `\"deny\"` plus a human reason — validation errors are
    expressed as denies rather than 4xx so the UI can show inline copy
    without a generic toast. The authoritative policy decision still
    runs server-side at `POST /v1/transfers` time.

    Args:
        body (PreviewBody): Inbound shape for `POST /v1/policies/preview`. Mirrors
            `web/src/app/_hooks/right/use-policy-preview.ts#PolicyPreviewIntent`
            — every field is camelCase coming from the dashboard's `api.post`.

            `source_id` is deserialized for parity with the wallet-id contract but
            not yet used — wallet org-membership is enforced server-side at
            `POST /v1/transfers` time. `#[allow(dead_code)]` keeps the field
            visible in the API surface without tripping the unused-field lint.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PreviewResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: PreviewBody,
) -> Response[PreviewResponse | ProblemDetails]:
    r"""Live policy preview for the Move Funds widget.

     Fires on every keystroke in the dashboard's amount field (debounced
    300ms client-side). Always returns 200 with a `decision` of
    `\"allow\"` or `\"deny\"` plus a human reason — validation errors are
    expressed as denies rather than 4xx so the UI can show inline copy
    without a generic toast. The authoritative policy decision still
    runs server-side at `POST /v1/transfers` time.

    Args:
        body (PreviewBody): Inbound shape for `POST /v1/policies/preview`. Mirrors
            `web/src/app/_hooks/right/use-policy-preview.ts#PolicyPreviewIntent`
            — every field is camelCase coming from the dashboard's `api.post`.

            `source_id` is deserialized for parity with the wallet-id contract but
            not yet used — wallet org-membership is enforced server-side at
            `POST /v1/transfers` time. `#[allow(dead_code)]` keeps the field
            visible in the API surface without tripping the unused-field lint.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PreviewResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: PreviewBody,
) -> PreviewResponse | ProblemDetails | None:
    r"""Live policy preview for the Move Funds widget.

     Fires on every keystroke in the dashboard's amount field (debounced
    300ms client-side). Always returns 200 with a `decision` of
    `\"allow\"` or `\"deny\"` plus a human reason — validation errors are
    expressed as denies rather than 4xx so the UI can show inline copy
    without a generic toast. The authoritative policy decision still
    runs server-side at `POST /v1/transfers` time.

    Args:
        body (PreviewBody): Inbound shape for `POST /v1/policies/preview`. Mirrors
            `web/src/app/_hooks/right/use-policy-preview.ts#PolicyPreviewIntent`
            — every field is camelCase coming from the dashboard's `api.post`.

            `source_id` is deserialized for parity with the wallet-id contract but
            not yet used — wallet org-membership is enforced server-side at
            `POST /v1/transfers` time. `#[allow(dead_code)]` keeps the field
            visible in the API surface without tripping the unused-field lint.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PreviewResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
