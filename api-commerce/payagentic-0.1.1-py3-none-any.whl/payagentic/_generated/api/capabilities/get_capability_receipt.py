from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.capability_receipt_response import CapabilityReceiptResponse
from ...models.problem_details import ProblemDetails
from typing import cast
from uuid import UUID


def _get_kwargs(
    receipt_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/capability-receipts/{receipt_id}".format(
            receipt_id=quote(str(receipt_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CapabilityReceiptResponse | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = CapabilityReceiptResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CapabilityReceiptResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    receipt_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[CapabilityReceiptResponse | ProblemDetails]:
    """
    Args:
        receipt_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityReceiptResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        receipt_id=receipt_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    receipt_id: UUID,
    *,
    client: AuthenticatedClient,
) -> CapabilityReceiptResponse | ProblemDetails | None:
    """
    Args:
        receipt_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityReceiptResponse | ProblemDetails
    """

    return sync_detailed(
        receipt_id=receipt_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    receipt_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[CapabilityReceiptResponse | ProblemDetails]:
    """
    Args:
        receipt_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityReceiptResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        receipt_id=receipt_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    receipt_id: UUID,
    *,
    client: AuthenticatedClient,
) -> CapabilityReceiptResponse | ProblemDetails | None:
    """
    Args:
        receipt_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityReceiptResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            receipt_id=receipt_id,
            client=client,
        )
    ).parsed
