from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.capability_invocation_metadata import CapabilityInvocationMetadata
from ...models.problem_details import ProblemDetails
from typing import cast
from uuid import UUID


def _get_kwargs(
    invocation_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/capability-invocations/{invocation_id}".format(
            invocation_id=quote(str(invocation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CapabilityInvocationMetadata | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = CapabilityInvocationMetadata.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CapabilityInvocationMetadata | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    invocation_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[CapabilityInvocationMetadata | ProblemDetails]:
    """
    Args:
        invocation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityInvocationMetadata | ProblemDetails]
    """

    kwargs = _get_kwargs(
        invocation_id=invocation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    invocation_id: UUID,
    *,
    client: AuthenticatedClient,
) -> CapabilityInvocationMetadata | ProblemDetails | None:
    """
    Args:
        invocation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityInvocationMetadata | ProblemDetails
    """

    return sync_detailed(
        invocation_id=invocation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    invocation_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[CapabilityInvocationMetadata | ProblemDetails]:
    """
    Args:
        invocation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityInvocationMetadata | ProblemDetails]
    """

    kwargs = _get_kwargs(
        invocation_id=invocation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    invocation_id: UUID,
    *,
    client: AuthenticatedClient,
) -> CapabilityInvocationMetadata | ProblemDetails | None:
    """
    Args:
        invocation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityInvocationMetadata | ProblemDetails
    """

    return (
        await asyncio_detailed(
            invocation_id=invocation_id,
            client=client,
        )
    ).parsed
