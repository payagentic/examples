from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.capability_directory_item import CapabilityDirectoryItem
from ...models.problem_details import ProblemDetails
from typing import cast
from uuid import UUID


def _get_kwargs(
    capability_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/directory/capabilities/{capability_id}".format(
            capability_id=quote(str(capability_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CapabilityDirectoryItem | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = CapabilityDirectoryItem.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CapabilityDirectoryItem | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    capability_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[CapabilityDirectoryItem | ProblemDetails]:
    """
    Args:
        capability_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityDirectoryItem | ProblemDetails]
    """

    kwargs = _get_kwargs(
        capability_id=capability_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    capability_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> CapabilityDirectoryItem | ProblemDetails | None:
    """
    Args:
        capability_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityDirectoryItem | ProblemDetails
    """

    return sync_detailed(
        capability_id=capability_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    capability_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[CapabilityDirectoryItem | ProblemDetails]:
    """
    Args:
        capability_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityDirectoryItem | ProblemDetails]
    """

    kwargs = _get_kwargs(
        capability_id=capability_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    capability_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> CapabilityDirectoryItem | ProblemDetails | None:
    """
    Args:
        capability_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityDirectoryItem | ProblemDetails
    """

    return (
        await asyncio_detailed(
            capability_id=capability_id,
            client=client,
        )
    ).parsed
