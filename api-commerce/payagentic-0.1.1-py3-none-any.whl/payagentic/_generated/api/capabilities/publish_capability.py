from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.capability_version_response import CapabilityVersionResponse
from ...models.problem_details import ProblemDetails
from ...models.publish_capability_request import PublishCapabilityRequest
from typing import cast
from uuid import UUID


def _get_kwargs(
    capability_id: UUID,
    *,
    body: PublishCapabilityRequest,
    idempotency_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["Idempotency-Key"] = idempotency_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/capabilities/{capability_id}/publish".format(
            capability_id=quote(str(capability_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CapabilityVersionResponse | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = CapabilityVersionResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ProblemDetails.from_dict(response.json())

        return response_409

    if response.status_code == 429:
        response_429 = ProblemDetails.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ProblemDetails.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CapabilityVersionResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    capability_id: UUID,
    *,
    client: AuthenticatedClient,
    body: PublishCapabilityRequest,
    idempotency_key: str,
) -> Response[CapabilityVersionResponse | ProblemDetails]:
    """
    Args:
        capability_id (UUID):
        idempotency_key (str):
        body (PublishCapabilityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityVersionResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        capability_id=capability_id,
        body=body,
        idempotency_key=idempotency_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    capability_id: UUID,
    *,
    client: AuthenticatedClient,
    body: PublishCapabilityRequest,
    idempotency_key: str,
) -> CapabilityVersionResponse | ProblemDetails | None:
    """
    Args:
        capability_id (UUID):
        idempotency_key (str):
        body (PublishCapabilityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityVersionResponse | ProblemDetails
    """

    return sync_detailed(
        capability_id=capability_id,
        client=client,
        body=body,
        idempotency_key=idempotency_key,
    ).parsed


async def asyncio_detailed(
    capability_id: UUID,
    *,
    client: AuthenticatedClient,
    body: PublishCapabilityRequest,
    idempotency_key: str,
) -> Response[CapabilityVersionResponse | ProblemDetails]:
    """
    Args:
        capability_id (UUID):
        idempotency_key (str):
        body (PublishCapabilityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CapabilityVersionResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        capability_id=capability_id,
        body=body,
        idempotency_key=idempotency_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    capability_id: UUID,
    *,
    client: AuthenticatedClient,
    body: PublishCapabilityRequest,
    idempotency_key: str,
) -> CapabilityVersionResponse | ProblemDetails | None:
    """
    Args:
        capability_id (UUID):
        idempotency_key (str):
        body (PublishCapabilityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CapabilityVersionResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            capability_id=capability_id,
            client=client,
            body=body,
            idempotency_key=idempotency_key,
        )
    ).parsed
