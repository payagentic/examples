from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.refund_request import RefundRequest
from ...models.refund_response import RefundResponse
from typing import cast


def _get_kwargs(
    id: str,
    *,
    body: RefundRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/payments/{id}/refund".format(
            id=quote(str(id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | RefundResponse | None:
    if response.status_code == 200:
        response_200 = RefundResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ProblemDetails.from_dict(response.json())

        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | RefundResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: RefundRequest,
) -> Response[ProblemDetails | RefundResponse]:
    """Refund a custodial payment (full or partial).

     Merchant-key only. Idempotent via `Idempotency-Key` header (Stripe
    canonical) or `idempotency_key` body field. Writes the refund row
    and 3 double-entry ledger legs atomically in a single transaction.

    Args:
        id (str):
        body (RefundRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | RefundResponse]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient,
    body: RefundRequest,
) -> ProblemDetails | RefundResponse | None:
    """Refund a custodial payment (full or partial).

     Merchant-key only. Idempotent via `Idempotency-Key` header (Stripe
    canonical) or `idempotency_key` body field. Writes the refund row
    and 3 double-entry ledger legs atomically in a single transaction.

    Args:
        id (str):
        body (RefundRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | RefundResponse
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: RefundRequest,
) -> Response[ProblemDetails | RefundResponse]:
    """Refund a custodial payment (full or partial).

     Merchant-key only. Idempotent via `Idempotency-Key` header (Stripe
    canonical) or `idempotency_key` body field. Writes the refund row
    and 3 double-entry ledger legs atomically in a single transaction.

    Args:
        id (str):
        body (RefundRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | RefundResponse]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,
    body: RefundRequest,
) -> ProblemDetails | RefundResponse | None:
    """Refund a custodial payment (full or partial).

     Merchant-key only. Idempotent via `Idempotency-Key` header (Stripe
    canonical) or `idempotency_key` body field. Writes the refund row
    and 3 double-entry ledger legs atomically in a single transaction.

    Args:
        id (str):
        body (RefundRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | RefundResponse
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
