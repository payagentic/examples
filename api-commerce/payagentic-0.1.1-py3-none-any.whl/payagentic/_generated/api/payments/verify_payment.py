from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.verify_request import VerifyRequest
from ...models.verify_response import VerifyResponse
from typing import cast


def _get_kwargs(
    *,
    body: VerifyRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/payments/verify",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | VerifyResponse | None:
    if response.status_code == 200:
        response_200 = VerifyResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | VerifyResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: VerifyRequest,
) -> Response[ProblemDetails | VerifyResponse]:
    """Verify an x402 payment credential against the gateway's records.

     Called by vendor SDKs on every incoming x402 request. Decodes the
    base64(JSON) credential, extracts the EIP-3009 nonce, and returns the
    matching payment's metadata if it's valid and the caller (a merchant
    key) owns the payment. Gated by `APP_PAYMENTS_VERIFY_ENABLED`.

    Args:
        body (VerifyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | VerifyResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: VerifyRequest,
) -> ProblemDetails | VerifyResponse | None:
    """Verify an x402 payment credential against the gateway's records.

     Called by vendor SDKs on every incoming x402 request. Decodes the
    base64(JSON) credential, extracts the EIP-3009 nonce, and returns the
    matching payment's metadata if it's valid and the caller (a merchant
    key) owns the payment. Gated by `APP_PAYMENTS_VERIFY_ENABLED`.

    Args:
        body (VerifyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | VerifyResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: VerifyRequest,
) -> Response[ProblemDetails | VerifyResponse]:
    """Verify an x402 payment credential against the gateway's records.

     Called by vendor SDKs on every incoming x402 request. Decodes the
    base64(JSON) credential, extracts the EIP-3009 nonce, and returns the
    matching payment's metadata if it's valid and the caller (a merchant
    key) owns the payment. Gated by `APP_PAYMENTS_VERIFY_ENABLED`.

    Args:
        body (VerifyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | VerifyResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: VerifyRequest,
) -> ProblemDetails | VerifyResponse | None:
    """Verify an x402 payment credential against the gateway's records.

     Called by vendor SDKs on every incoming x402 request. Decodes the
    base64(JSON) credential, extracts the EIP-3009 nonce, and returns the
    matching payment's metadata if it's valid and the caller (a merchant
    key) owns the payment. Gated by `APP_PAYMENTS_VERIFY_ENABLED`.

    Args:
        body (VerifyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | VerifyResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
