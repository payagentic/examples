from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/payments/{id}/settlement".format(
            id=quote(str(id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = ProblemDetails.from_dict(response.json())

        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | ProblemDetails]:
    """Report seller settlement (x402 v2).

     Posts the seller's `PAYMENT-RESPONSE` base64 value to the payments
    orchestrator after a successful seller-settled x402 v2 payment. The
    body must carry `payment_response` (string): the raw base64 value from
    the seller's `PAYMENT-RESPONSE` response header.

    On success the transaction moves `authorized -> confirming` (the
    confirmation watcher verifies the `AuthorizationUsed` event on-chain
    before promoting to `settled`). On a well-formed seller-reported failure
    (`success: false`) the transaction moves to `failed`. Malformed input
    (bad base64, bad hash shape) returns 400 and leaves the row unchanged.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetails]
    """

    kwargs = _get_kwargs(
        id=id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient,
) -> Any | ProblemDetails | None:
    """Report seller settlement (x402 v2).

     Posts the seller's `PAYMENT-RESPONSE` base64 value to the payments
    orchestrator after a successful seller-settled x402 v2 payment. The
    body must carry `payment_response` (string): the raw base64 value from
    the seller's `PAYMENT-RESPONSE` response header.

    On success the transaction moves `authorized -> confirming` (the
    confirmation watcher verifies the `AuthorizationUsed` event on-chain
    before promoting to `settled`). On a well-formed seller-reported failure
    (`success: false`) the transaction moves to `failed`. Malformed input
    (bad base64, bad hash shape) returns 400 and leaves the row unchanged.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ProblemDetails
    """

    return sync_detailed(
        id=id,
        client=client,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | ProblemDetails]:
    """Report seller settlement (x402 v2).

     Posts the seller's `PAYMENT-RESPONSE` base64 value to the payments
    orchestrator after a successful seller-settled x402 v2 payment. The
    body must carry `payment_response` (string): the raw base64 value from
    the seller's `PAYMENT-RESPONSE` response header.

    On success the transaction moves `authorized -> confirming` (the
    confirmation watcher verifies the `AuthorizationUsed` event on-chain
    before promoting to `settled`). On a well-formed seller-reported failure
    (`success: false`) the transaction moves to `failed`. Malformed input
    (bad base64, bad hash shape) returns 400 and leaves the row unchanged.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetails]
    """

    kwargs = _get_kwargs(
        id=id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,
) -> Any | ProblemDetails | None:
    """Report seller settlement (x402 v2).

     Posts the seller's `PAYMENT-RESPONSE` base64 value to the payments
    orchestrator after a successful seller-settled x402 v2 payment. The
    body must carry `payment_response` (string): the raw base64 value from
    the seller's `PAYMENT-RESPONSE` response header.

    On success the transaction moves `authorized -> confirming` (the
    confirmation watcher verifies the `AuthorizationUsed` event on-chain
    before promoting to `settled`). On a well-formed seller-reported failure
    (`success: false`) the transaction moves to `failed`. Malformed input
    (bad base64, bad hash shape) returns 400 and leaves the row unchanged.

    Args:
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ProblemDetails
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
        )
    ).parsed
