from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.payment_decision_response import PaymentDecisionResponse
from ...models.payment_response import PaymentResponse
from ...models.problem_details import ProblemDetails
from ...models.propose_payment_request import ProposePaymentRequest
from typing import cast


def _get_kwargs(
    *,
    body: ProposePaymentRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/payments/propose",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaymentDecisionResponse | PaymentResponse | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = PaymentResponse.from_dict(response.json())

        return response_200

    if response.status_code == 202:
        response_202 = PaymentDecisionResponse.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = PaymentDecisionResponse.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaymentDecisionResponse | PaymentResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ProposePaymentRequest,
) -> Response[PaymentDecisionResponse | PaymentResponse | ProblemDetails]:
    """Propose an x402 payment.

     Accepts an x402 `PaymentRequirements` from an agent that received a 402
    response. The gateway evaluates spend policies, signs the payment, and
    returns a rail-specific credential in the `credential` field
    (`X-Payment` for x402 legacy, `Authorization: Payment` for MPP,
    `PAYMENT-SIGNATURE` for x402 v2). Target latency: <200ms p99.

    Args:
        body (ProposePaymentRequest): Request body for proposing an x402 payment.

            The agent sends this after receiving a 402 response from a resource
            server. The gateway forwards it to the payments orchestrator for
            policy evaluation, signing, and on-chain settlement.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaymentDecisionResponse | PaymentResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ProposePaymentRequest,
) -> PaymentDecisionResponse | PaymentResponse | ProblemDetails | None:
    """Propose an x402 payment.

     Accepts an x402 `PaymentRequirements` from an agent that received a 402
    response. The gateway evaluates spend policies, signs the payment, and
    returns a rail-specific credential in the `credential` field
    (`X-Payment` for x402 legacy, `Authorization: Payment` for MPP,
    `PAYMENT-SIGNATURE` for x402 v2). Target latency: <200ms p99.

    Args:
        body (ProposePaymentRequest): Request body for proposing an x402 payment.

            The agent sends this after receiving a 402 response from a resource
            server. The gateway forwards it to the payments orchestrator for
            policy evaluation, signing, and on-chain settlement.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaymentDecisionResponse | PaymentResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ProposePaymentRequest,
) -> Response[PaymentDecisionResponse | PaymentResponse | ProblemDetails]:
    """Propose an x402 payment.

     Accepts an x402 `PaymentRequirements` from an agent that received a 402
    response. The gateway evaluates spend policies, signs the payment, and
    returns a rail-specific credential in the `credential` field
    (`X-Payment` for x402 legacy, `Authorization: Payment` for MPP,
    `PAYMENT-SIGNATURE` for x402 v2). Target latency: <200ms p99.

    Args:
        body (ProposePaymentRequest): Request body for proposing an x402 payment.

            The agent sends this after receiving a 402 response from a resource
            server. The gateway forwards it to the payments orchestrator for
            policy evaluation, signing, and on-chain settlement.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaymentDecisionResponse | PaymentResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ProposePaymentRequest,
) -> PaymentDecisionResponse | PaymentResponse | ProblemDetails | None:
    """Propose an x402 payment.

     Accepts an x402 `PaymentRequirements` from an agent that received a 402
    response. The gateway evaluates spend policies, signs the payment, and
    returns a rail-specific credential in the `credential` field
    (`X-Payment` for x402 legacy, `Authorization: Payment` for MPP,
    `PAYMENT-SIGNATURE` for x402 v2). Target latency: <200ms p99.

    Args:
        body (ProposePaymentRequest): Request body for proposing an x402 payment.

            The agent sends this after receiving a 402 response from a resource
            server. The gateway forwards it to the payments orchestrator for
            policy evaluation, signing, and on-chain settlement.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaymentDecisionResponse | PaymentResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
