from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.voucher_products_response import VoucherProductsResponse
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    country: str,
    q: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["country"] = country

    params["q"] = q

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/checkout/vouchers/products",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | VoucherProductsResponse | None:
    if response.status_code == 200:
        response_200 = VoucherProductsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | VoucherProductsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    country: str,
    q: str | Unset = UNSET,
) -> Response[ProblemDetails | VoucherProductsResponse]:
    """Search cached/fake voucher products.

    Args:
        country (str):
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | VoucherProductsResponse]
    """

    kwargs = _get_kwargs(
        country=country,
        q=q,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    country: str,
    q: str | Unset = UNSET,
) -> ProblemDetails | VoucherProductsResponse | None:
    """Search cached/fake voucher products.

    Args:
        country (str):
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | VoucherProductsResponse
    """

    return sync_detailed(
        client=client,
        country=country,
        q=q,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    country: str,
    q: str | Unset = UNSET,
) -> Response[ProblemDetails | VoucherProductsResponse]:
    """Search cached/fake voucher products.

    Args:
        country (str):
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | VoucherProductsResponse]
    """

    kwargs = _get_kwargs(
        country=country,
        q=q,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    country: str,
    q: str | Unset = UNSET,
) -> ProblemDetails | VoucherProductsResponse | None:
    """Search cached/fake voucher products.

    Args:
        country (str):
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | VoucherProductsResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            country=country,
            q=q,
        )
    ).parsed
