from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.paginated_compliance_alerts import PaginatedComplianceAlerts
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/compliance/alerts",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedComplianceAlerts | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = PaginatedComplianceAlerts.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedComplianceAlerts | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[PaginatedComplianceAlerts | ProblemDetails]:
    """List compliance alerts for the authenticated organization.

     Placeholder -- returns an empty page until the AML/sanctions screening
    pipeline is wired in.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedComplianceAlerts | ProblemDetails]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> PaginatedComplianceAlerts | ProblemDetails | None:
    """List compliance alerts for the authenticated organization.

     Placeholder -- returns an empty page until the AML/sanctions screening
    pipeline is wired in.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedComplianceAlerts | ProblemDetails
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[PaginatedComplianceAlerts | ProblemDetails]:
    """List compliance alerts for the authenticated organization.

     Placeholder -- returns an empty page until the AML/sanctions screening
    pipeline is wired in.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedComplianceAlerts | ProblemDetails]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> PaginatedComplianceAlerts | ProblemDetails | None:
    """List compliance alerts for the authenticated organization.

     Placeholder -- returns an empty page until the AML/sanctions screening
    pipeline is wired in.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedComplianceAlerts | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
