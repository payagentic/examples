from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_transfer_body import CreateTransferBody
from ...models.create_transfer_response import CreateTransferResponse
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: CreateTransferBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/transfers",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateTransferResponse | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = CreateTransferResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateTransferResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateTransferBody,
) -> Response[CreateTransferResponse | ProblemDetails]:
    """Stage an internal wallet-to-wallet transfer.

     Records a pending transfer intent; the orchestrator's reconciliation
    loop picks it up for on-chain broadcast. The returned `transferId`
    is what the dashboard's in-flight tracker subscribes to. Both source
    and destination wallets must belong to the caller's `org_id`.

    Args:
        body (CreateTransferBody): Inbound shape — mirrors `web/src/app/_hooks/right/use-submit-
            transfer.ts`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateTransferResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: CreateTransferBody,
) -> CreateTransferResponse | ProblemDetails | None:
    """Stage an internal wallet-to-wallet transfer.

     Records a pending transfer intent; the orchestrator's reconciliation
    loop picks it up for on-chain broadcast. The returned `transferId`
    is what the dashboard's in-flight tracker subscribes to. Both source
    and destination wallets must belong to the caller's `org_id`.

    Args:
        body (CreateTransferBody): Inbound shape — mirrors `web/src/app/_hooks/right/use-submit-
            transfer.ts`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateTransferResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateTransferBody,
) -> Response[CreateTransferResponse | ProblemDetails]:
    """Stage an internal wallet-to-wallet transfer.

     Records a pending transfer intent; the orchestrator's reconciliation
    loop picks it up for on-chain broadcast. The returned `transferId`
    is what the dashboard's in-flight tracker subscribes to. Both source
    and destination wallets must belong to the caller's `org_id`.

    Args:
        body (CreateTransferBody): Inbound shape — mirrors `web/src/app/_hooks/right/use-submit-
            transfer.ts`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateTransferResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateTransferBody,
) -> CreateTransferResponse | ProblemDetails | None:
    """Stage an internal wallet-to-wallet transfer.

     Records a pending transfer intent; the orchestrator's reconciliation
    loop picks it up for on-chain broadcast. The returned `transferId`
    is what the dashboard's in-flight tracker subscribes to. Both source
    and destination wallets must belong to the caller's `org_id`.

    Args:
        body (CreateTransferBody): Inbound shape — mirrors `web/src/app/_hooks/right/use-submit-
            transfer.ts`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateTransferResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
