from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.activate_request import ActivateRequest
from ...models.activate_response import ActivateResponse
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: ActivateRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/merchants/activate",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ActivateResponse | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = ActivateResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ActivateResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ActivateRequest,
) -> Response[ActivateResponse | ProblemDetails]:
    """Activate a merchant account using a signup token.

     Open (no auth). Consumes the signup token, screens the payout wallet
    for sanctions, then atomically creates the org, payout wallet,
    merchant profile, KYB attestation, and merchant API key. The minted
    `api_key` is shown ONCE.

    Args:
        body (ActivateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActivateResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ActivateRequest,
) -> ActivateResponse | ProblemDetails | None:
    """Activate a merchant account using a signup token.

     Open (no auth). Consumes the signup token, screens the payout wallet
    for sanctions, then atomically creates the org, payout wallet,
    merchant profile, KYB attestation, and merchant API key. The minted
    `api_key` is shown ONCE.

    Args:
        body (ActivateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActivateResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ActivateRequest,
) -> Response[ActivateResponse | ProblemDetails]:
    """Activate a merchant account using a signup token.

     Open (no auth). Consumes the signup token, screens the payout wallet
    for sanctions, then atomically creates the org, payout wallet,
    merchant profile, KYB attestation, and merchant API key. The minted
    `api_key` is shown ONCE.

    Args:
        body (ActivateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActivateResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ActivateRequest,
) -> ActivateResponse | ProblemDetails | None:
    """Activate a merchant account using a signup token.

     Open (no auth). Consumes the signup token, screens the payout wallet
    for sanctions, then atomically creates the org, payout wallet,
    merchant profile, KYB attestation, and merchant API key. The minted
    `api_key` is shown ONCE.

    Args:
        body (ActivateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActivateResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
