from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.earnings_response import EarningsResponse
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["cursor"] = cursor

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/merchants/me/earnings",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EarningsResponse | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = EarningsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EarningsResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[EarningsResponse | ProblemDetails]:
    """List the calling merchant's settled earnings (cursor-paginated).

     Joins `transactions` to `merchant_endpoints` and filters by
    `merchant_endpoints.merchant_id = caller`. Cursor is the RFC3339
    `created_at` of the prior page's last row; default page size 50,
    max 200. Each row includes the originating endpoint, a redacted
    agent id, micro-unit amount, currency, settlement timestamp, and
    on-chain `tx_hash`.

    Args:
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EarningsResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        cursor=cursor,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> EarningsResponse | ProblemDetails | None:
    """List the calling merchant's settled earnings (cursor-paginated).

     Joins `transactions` to `merchant_endpoints` and filters by
    `merchant_endpoints.merchant_id = caller`. Cursor is the RFC3339
    `created_at` of the prior page's last row; default page size 50,
    max 200. Each row includes the originating endpoint, a redacted
    agent id, micro-unit amount, currency, settlement timestamp, and
    on-chain `tx_hash`.

    Args:
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EarningsResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        cursor=cursor,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[EarningsResponse | ProblemDetails]:
    """List the calling merchant's settled earnings (cursor-paginated).

     Joins `transactions` to `merchant_endpoints` and filters by
    `merchant_endpoints.merchant_id = caller`. Cursor is the RFC3339
    `created_at` of the prior page's last row; default page size 50,
    max 200. Each row includes the originating endpoint, a redacted
    agent id, micro-unit amount, currency, settlement timestamp, and
    on-chain `tx_hash`.

    Args:
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EarningsResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        cursor=cursor,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    cursor: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> EarningsResponse | ProblemDetails | None:
    """List the calling merchant's settled earnings (cursor-paginated).

     Joins `transactions` to `merchant_endpoints` and filters by
    `merchant_endpoints.merchant_id = caller`. Cursor is the RFC3339
    `created_at` of the prior page's last row; default page size 50,
    max 200. Each row includes the originating endpoint, a redacted
    agent id, micro-unit amount, currency, settlement timestamp, and
    on-chain `tx_hash`.

    Args:
        cursor (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EarningsResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            cursor=cursor,
            limit=limit,
        )
    ).parsed
