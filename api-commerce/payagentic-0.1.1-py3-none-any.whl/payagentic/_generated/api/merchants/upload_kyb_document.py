from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.document_response import DocumentResponse
from ...models.problem_details import ProblemDetails
from ...models.upload_kyb_document_form import UploadKybDocumentForm
from typing import cast


def _get_kwargs(
    *,
    body: UploadKybDocumentForm,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/merchants/me/kyb/documents",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DocumentResponse | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = DocumentResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DocumentResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: UploadKybDocumentForm,
) -> Response[DocumentResponse | ProblemDetails]:
    """Upload one KYB document (multipart/form-data).

     One document per request. Form fields: `document_type`
    (`incorporation` | `owner_id` | `proof_of_address`) and `file`
    (binary). Persists the bytes to the configured object store, records
    a row in `merchant_kyb_documents` with `reviewer_status = pending`,
    and returns the document id.

    Args:
        body (UploadKybDocumentForm): Multipart form body for `POST
            /v1/merchants/me/kyb/documents`.

            Documentation-only marker type — the actual handler streams the multipart
            payload directly via `axum::extract::Multipart`. Fields: `document_type`
            (one of `incorporation`, `owner_id`, `proof_of_address`) and `file`
            (binary upload).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocumentResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: UploadKybDocumentForm,
) -> DocumentResponse | ProblemDetails | None:
    """Upload one KYB document (multipart/form-data).

     One document per request. Form fields: `document_type`
    (`incorporation` | `owner_id` | `proof_of_address`) and `file`
    (binary). Persists the bytes to the configured object store, records
    a row in `merchant_kyb_documents` with `reviewer_status = pending`,
    and returns the document id.

    Args:
        body (UploadKybDocumentForm): Multipart form body for `POST
            /v1/merchants/me/kyb/documents`.

            Documentation-only marker type — the actual handler streams the multipart
            payload directly via `axum::extract::Multipart`. Fields: `document_type`
            (one of `incorporation`, `owner_id`, `proof_of_address`) and `file`
            (binary upload).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocumentResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: UploadKybDocumentForm,
) -> Response[DocumentResponse | ProblemDetails]:
    """Upload one KYB document (multipart/form-data).

     One document per request. Form fields: `document_type`
    (`incorporation` | `owner_id` | `proof_of_address`) and `file`
    (binary). Persists the bytes to the configured object store, records
    a row in `merchant_kyb_documents` with `reviewer_status = pending`,
    and returns the document id.

    Args:
        body (UploadKybDocumentForm): Multipart form body for `POST
            /v1/merchants/me/kyb/documents`.

            Documentation-only marker type — the actual handler streams the multipart
            payload directly via `axum::extract::Multipart`. Fields: `document_type`
            (one of `incorporation`, `owner_id`, `proof_of_address`) and `file`
            (binary upload).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocumentResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: UploadKybDocumentForm,
) -> DocumentResponse | ProblemDetails | None:
    """Upload one KYB document (multipart/form-data).

     One document per request. Form fields: `document_type`
    (`incorporation` | `owner_id` | `proof_of_address`) and `file`
    (binary). Persists the bytes to the configured object store, records
    a row in `merchant_kyb_documents` with `reviewer_status = pending`,
    and returns the document id.

    Args:
        body (UploadKybDocumentForm): Multipart form body for `POST
            /v1/merchants/me/kyb/documents`.

            Documentation-only marker type — the actual handler streams the multipart
            payload directly via `axum::extract::Multipart`. Fields: `document_type`
            (one of `incorporation`, `owner_id`, `proof_of_address`) and `file`
            (binary upload).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocumentResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
