from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...models.stats_response import StatsResponse
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    id: str,
    *,
    range_: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["range"] = range_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/merchants/endpoints/{id}/stats".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | StatsResponse | None:
    if response.status_code == 200:
        response_200 = StatsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | StatsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> Response[ProblemDetails | StatsResponse]:
    """Aggregate stats for a single merchant endpoint over a time range.

     `range` accepts `24h` (default), `7d`, or `30d`. Returns the call
    count plus total revenue in micro units (`amount * 1_000_000`). The
    endpoint id must belong to the calling merchant — 404 is returned
    otherwise (no existence leak).

    Args:
        id (str):
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | StatsResponse]
    """

    kwargs = _get_kwargs(
        id=id,
        range_=range_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> ProblemDetails | StatsResponse | None:
    """Aggregate stats for a single merchant endpoint over a time range.

     `range` accepts `24h` (default), `7d`, or `30d`. Returns the call
    count plus total revenue in micro units (`amount * 1_000_000`). The
    endpoint id must belong to the calling merchant — 404 is returned
    otherwise (no existence leak).

    Args:
        id (str):
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | StatsResponse
    """

    return sync_detailed(
        id=id,
        client=client,
        range_=range_,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> Response[ProblemDetails | StatsResponse]:
    """Aggregate stats for a single merchant endpoint over a time range.

     `range` accepts `24h` (default), `7d`, or `30d`. Returns the call
    count plus total revenue in micro units (`amount * 1_000_000`). The
    endpoint id must belong to the calling merchant — 404 is returned
    otherwise (no existence leak).

    Args:
        id (str):
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | StatsResponse]
    """

    kwargs = _get_kwargs(
        id=id,
        range_=range_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,
    range_: str | Unset = UNSET,
) -> ProblemDetails | StatsResponse | None:
    """Aggregate stats for a single merchant endpoint over a time range.

     `range` accepts `24h` (default), `7d`, or `30d`. Returns the call
    count plus total revenue in micro units (`amount * 1_000_000`). The
    endpoint id must belong to the calling merchant — 404 is returned
    otherwise (no existence leak).

    Args:
        id (str):
        range_ (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | StatsResponse
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            range_=range_,
        )
    ).parsed
