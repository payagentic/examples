from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.problem_details import ProblemDetails
from ...types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime


def _get_kwargs(
    *,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    bucket: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_from_: str | Unset = UNSET
    if not isinstance(from_, Unset):
        json_from_ = from_.isoformat()
    params["from"] = json_from_

    json_to: str | Unset = UNSET
    if not isinstance(to, Unset):
        json_to = to.isoformat()
    params["to"] = json_to

    params["bucket"] = bucket

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/merchants/me/earnings/export",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    bucket: str | Unset = UNSET,
) -> Response[ProblemDetails | str]:
    r"""Stream merchant earnings as a CSV attachment.

     Returns the same rows as `GET /v1/merchants/me/earnings` over
    `[from, to)` (defaults: last 30 days), serialized as `text/csv` with
    a `Content-Disposition: attachment; filename=\"earnings.csv\"`
    header. Used by the merchant dashboard's \"Export\" button.

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        bucket (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | str]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
        bucket=bucket,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    bucket: str | Unset = UNSET,
) -> ProblemDetails | str | None:
    r"""Stream merchant earnings as a CSV attachment.

     Returns the same rows as `GET /v1/merchants/me/earnings` over
    `[from, to)` (defaults: last 30 days), serialized as `text/csv` with
    a `Content-Disposition: attachment; filename=\"earnings.csv\"`
    header. Used by the merchant dashboard's \"Export\" button.

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        bucket (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | str
    """

    return sync_detailed(
        client=client,
        from_=from_,
        to=to,
        bucket=bucket,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    bucket: str | Unset = UNSET,
) -> Response[ProblemDetails | str]:
    r"""Stream merchant earnings as a CSV attachment.

     Returns the same rows as `GET /v1/merchants/me/earnings` over
    `[from, to)` (defaults: last 30 days), serialized as `text/csv` with
    a `Content-Disposition: attachment; filename=\"earnings.csv\"`
    header. Used by the merchant dashboard's \"Export\" button.

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        bucket (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | str]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
        bucket=bucket,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    bucket: str | Unset = UNSET,
) -> ProblemDetails | str | None:
    r"""Stream merchant earnings as a CSV attachment.

     Returns the same rows as `GET /v1/merchants/me/earnings` over
    `[from, to)` (defaults: last 30 days), serialized as `text/csv` with
    a `Content-Disposition: attachment; filename=\"earnings.csv\"`
    header. Used by the merchant dashboard's \"Export\" button.

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        bucket (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | str
    """

    return (
        await asyncio_detailed(
            client=client,
            from_=from_,
            to=to,
            bucket=bucket,
        )
    ).parsed
