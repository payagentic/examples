from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.merchant_signup_request import MerchantSignupRequest
from ...models.merchant_signup_response import MerchantSignupResponse
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: MerchantSignupRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/merchants/signup",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> MerchantSignupResponse | ProblemDetails | None:
    if response.status_code == 201:
        response_201 = MerchantSignupResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[MerchantSignupResponse | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MerchantSignupRequest,
) -> Response[MerchantSignupResponse | ProblemDetails]:
    """Self-service merchant signup — issues an activation token via email.

     Open (no auth). Accepts `email` + `business_name`, issues a short-lived
    activation token, and sends it to the email address. The token is
    returned in the response body only when `APP_RETURN_SIGNUP_TOKEN=true`
    (dev convenience).

    Args:
        body (MerchantSignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MerchantSignupResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: MerchantSignupRequest,
) -> MerchantSignupResponse | ProblemDetails | None:
    """Self-service merchant signup — issues an activation token via email.

     Open (no auth). Accepts `email` + `business_name`, issues a short-lived
    activation token, and sends it to the email address. The token is
    returned in the response body only when `APP_RETURN_SIGNUP_TOKEN=true`
    (dev convenience).

    Args:
        body (MerchantSignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MerchantSignupResponse | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MerchantSignupRequest,
) -> Response[MerchantSignupResponse | ProblemDetails]:
    """Self-service merchant signup — issues an activation token via email.

     Open (no auth). Accepts `email` + `business_name`, issues a short-lived
    activation token, and sends it to the email address. The token is
    returned in the response body only when `APP_RETURN_SIGNUP_TOKEN=true`
    (dev convenience).

    Args:
        body (MerchantSignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MerchantSignupResponse | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: MerchantSignupRequest,
) -> MerchantSignupResponse | ProblemDetails | None:
    """Self-service merchant signup — issues an activation token via email.

     Open (no auth). Accepts `email` + `business_name`, issues a short-lived
    activation token, and sends it to the email address. The token is
    returned in the response body only when `APP_RETURN_SIGNUP_TOKEN=true`
    (dev convenience).

    Args:
        body (MerchantSignupRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MerchantSignupResponse | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
