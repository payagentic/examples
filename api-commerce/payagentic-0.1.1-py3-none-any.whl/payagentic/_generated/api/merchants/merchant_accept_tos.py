from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.accept_tos_request import AcceptTosRequest
from ...models.merchant_profile_dto import MerchantProfileDto
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs(
    *,
    body: AcceptTosRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/merchants/me/tos",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> MerchantProfileDto | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = MerchantProfileDto.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[MerchantProfileDto | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: AcceptTosRequest,
) -> Response[MerchantProfileDto | ProblemDetails]:
    """Record the merchant's acceptance of a specific TOS version.

     Merchant-key only. Stamps `tos_accepted_at` + `tos_version` on the
    profile so downstream gates (payouts, withdrawals) can require an
    up-to-date acceptance.

    Args:
        body (AcceptTosRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MerchantProfileDto | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: AcceptTosRequest,
) -> MerchantProfileDto | ProblemDetails | None:
    """Record the merchant's acceptance of a specific TOS version.

     Merchant-key only. Stamps `tos_accepted_at` + `tos_version` on the
    profile so downstream gates (payouts, withdrawals) can require an
    up-to-date acceptance.

    Args:
        body (AcceptTosRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MerchantProfileDto | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: AcceptTosRequest,
) -> Response[MerchantProfileDto | ProblemDetails]:
    """Record the merchant's acceptance of a specific TOS version.

     Merchant-key only. Stamps `tos_accepted_at` + `tos_version` on the
    profile so downstream gates (payouts, withdrawals) can require an
    up-to-date acceptance.

    Args:
        body (AcceptTosRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[MerchantProfileDto | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: AcceptTosRequest,
) -> MerchantProfileDto | ProblemDetails | None:
    """Record the merchant's acceptance of a specific TOS version.

     Merchant-key only. Stamps `tos_accepted_at` + `tos_version` on the
    profile so downstream gates (payouts, withdrawals) can require an
    up-to-date acceptance.

    Args:
        body (AcceptTosRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        MerchantProfileDto | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
