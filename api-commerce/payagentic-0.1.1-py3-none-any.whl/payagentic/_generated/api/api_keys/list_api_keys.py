from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.paginated_api_keys import PaginatedApiKeys
from ...models.problem_details import ProblemDetails
from typing import cast


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/api-keys",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedApiKeys | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = PaginatedApiKeys.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedApiKeys | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[PaginatedApiKeys | ProblemDetails]:
    """List non-revoked agent API keys for the authenticated organization.

     The plaintext secret is never returned on list -- only the prefix is
    shown. Mint a fresh key via `POST /v1/api-keys` to see the secret.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedApiKeys | ProblemDetails]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> PaginatedApiKeys | ProblemDetails | None:
    """List non-revoked agent API keys for the authenticated organization.

     The plaintext secret is never returned on list -- only the prefix is
    shown. Mint a fresh key via `POST /v1/api-keys` to see the secret.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedApiKeys | ProblemDetails
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[PaginatedApiKeys | ProblemDetails]:
    """List non-revoked agent API keys for the authenticated organization.

     The plaintext secret is never returned on list -- only the prefix is
    shown. Mint a fresh key via `POST /v1/api-keys` to see the secret.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedApiKeys | ProblemDetails]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> PaginatedApiKeys | ProblemDetails | None:
    """List non-revoked agent API keys for the authenticated organization.

     The plaintext secret is never returned on list -- only the prefix is
    shown. Mint a fresh key via `POST /v1/api-keys` to see the secret.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedApiKeys | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
