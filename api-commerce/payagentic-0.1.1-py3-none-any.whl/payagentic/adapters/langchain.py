"""LangChain tool definitions for the PayAgentic API."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from payagentic.client import PayAgentic

__all__ = ["create_langchain_tools"]


def _make_tool_spec(
    name: str,
    description: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Build a tool specification dict."""
    return {
        "name": name,
        "description": description,
        "parameters": parameters,
    }


def create_langchain_tools(client: PayAgentic) -> list[dict[str, Any]]:
    """Create LangChain-compatible tool definitions for the PayAgentic API.

    Returns a list of dicts that can be used to construct LangChain
    ``StructuredTool`` instances.  Each dict contains ``name``,
    ``description``, and ``parameters`` keys.

    Args:
        client: An initialised :class:`PayAgentic` client.

    Returns:
        A list of tool specification dicts.
    """
    _ = client  # Interface consistency; tools reference the client at runtime.

    return [
        _make_tool_spec(
            name="payagentic_get_wallet",
            description="Get wallet details including stablecoin balance.",
            parameters={
                "type": "object",
                "properties": {
                    "wallet_id": {
                        "type": "string",
                        "description": "Wallet identifier",
                    },
                },
                "required": ["wallet_id"],
            },
        ),
        _make_tool_spec(
            name="payagentic_list_wallets",
            description="List all wallets for the current organisation.",
            parameters={
                "type": "object",
                "properties": {
                    "page": {
                        "type": "integer",
                        "description": "Page number",
                        "default": 1,
                    },
                    "per_page": {
                        "type": "integer",
                        "description": "Items per page",
                        "default": 20,
                    },
                },
            },
        ),
        _make_tool_spec(
            name="payagentic_propose_payment",
            description=(
                "Propose an EVM USDC checkout payment on Base, Polygon PoS, "
                "or Arbitrum One to a recipient address."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "recipient_address": {
                        "type": "string",
                        "description": "0x-prefixed Ethereum address",
                    },
                    "amount_usdc": {
                        "type": "string",
                        "description": "Amount in USDC for the EVM checkout rail (e.g. '5.00')",
                    },
                    "memo": {
                        "type": "string",
                        "description": "Human-readable memo",
                    },
                },
                "required": ["recipient_address", "amount_usdc"],
            },
        ),
        _make_tool_spec(
            name="payagentic_get_payment",
            description="Get payment status by ID.",
            parameters={
                "type": "object",
                "properties": {
                    "payment_id": {
                        "type": "string",
                        "description": "Payment identifier",
                    },
                },
                "required": ["payment_id"],
            },
        ),
        _make_tool_spec(
            name="payagentic_list_transactions",
            description="List recent transactions.",
            parameters={
                "type": "object",
                "properties": {
                    "page": {
                        "type": "integer",
                        "description": "Page number",
                        "default": 1,
                    },
                    "per_page": {
                        "type": "integer",
                        "description": "Items per page",
                        "default": 20,
                    },
                },
            },
        ),
    ]
