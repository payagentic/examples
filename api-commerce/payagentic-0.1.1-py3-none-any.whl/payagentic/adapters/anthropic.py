"""Anthropic tool definitions for the PayAgentic API."""

from __future__ import annotations

from typing import Any

__all__ = ["create_anthropic_tools"]


def create_anthropic_tools() -> list[dict[str, Any]]:
    """Create Anthropic-compatible tool definitions for the PayAgentic API.

    Returns a list of dicts conforming to the Anthropic Messages API
    ``tools`` parameter schema.

    Returns:
        A list of tool definitions.
    """
    return [
        {
            "name": "payagentic_get_wallet",
            "description": "Get wallet details including stablecoin balance.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "wallet_id": {"type": "string", "description": "Wallet identifier"},
                },
                "required": ["wallet_id"],
            },
        },
        {
            "name": "payagentic_propose_payment",
            "description": (
                "Propose an EVM USDC checkout payment on Base, Polygon PoS, "
                "or Arbitrum One to a recipient address."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "recipient_address": {
                        "type": "string",
                        "description": "0x-prefixed Ethereum address of the recipient",
                    },
                    "amount_usdc": {
                        "type": "string",
                        "description": "Amount in USDC for the EVM checkout rail (e.g. '5.00')",
                    },
                    "memo": {
                        "type": "string",
                        "description": "Human-readable memo for the payment",
                    },
                },
                "required": ["recipient_address", "amount_usdc"],
            },
        },
        {
            "name": "payagentic_get_payment",
            "description": "Get payment status by ID.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "payment_id": {"type": "string", "description": "Payment identifier"},
                },
                "required": ["payment_id"],
            },
        },
        {
            "name": "payagentic_list_transactions",
            "description": "List recent transactions for the current wallet.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "page": {"type": "integer", "description": "Page number", "default": 1},
                    "per_page": {"type": "integer", "description": "Items per page", "default": 20},
                },
            },
        },
    ]
