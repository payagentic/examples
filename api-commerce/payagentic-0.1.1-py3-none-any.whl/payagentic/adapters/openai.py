"""OpenAI function-calling definitions for the PayAgentic API."""

from __future__ import annotations

from typing import Any

__all__ = ["create_openai_functions"]


def create_openai_functions() -> list[dict[str, Any]]:
    """Create OpenAI-compatible function definitions for the PayAgentic API.

    Returns a list of dicts conforming to the OpenAI Chat Completions API
    ``tools`` parameter schema (``type: "function"``).

    Returns:
        A list of function tool definitions.
    """
    return [
        {
            "type": "function",
            "function": {
                "name": "payagentic_get_wallet",
                "description": "Get wallet details including stablecoin balance.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "wallet_id": {"type": "string", "description": "Wallet identifier"},
                    },
                    "required": ["wallet_id"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "payagentic_propose_payment",
                "description": (
                    "Propose an EVM USDC checkout payment on Base, Polygon PoS, "
                    "or Arbitrum One to a recipient address."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "recipient_address": {
                            "type": "string",
                            "description": "0x-prefixed Ethereum address of the recipient",
                        },
                        "amount_usdc": {
                            "type": "string",
                            "description": "Amount in USDC for the EVM checkout rail (e.g. '5.00')",
                        },
                        "memo": {
                            "type": "string",
                            "description": "Human-readable memo for the payment",
                        },
                    },
                    "required": ["recipient_address", "amount_usdc"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "payagentic_get_payment",
                "description": "Get payment status by ID.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "payment_id": {"type": "string", "description": "Payment identifier"},
                    },
                    "required": ["payment_id"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "payagentic_list_transactions",
                "description": "List recent transactions for the current wallet.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "page": {"type": "integer", "description": "Page number", "default": 1},
                        "per_page": {
                            "type": "integer",
                            "description": "Items per page",
                            "default": 20,
                        },
                    },
                },
            },
        },
    ]
