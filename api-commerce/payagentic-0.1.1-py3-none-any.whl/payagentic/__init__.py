"""PayAgentic Python SDK.

Programmatic access to the PayAgentic agent payments platform.
Designed for AI agent frameworks (Anthropic, OpenAI Agents SDK,
LangChain, CrewAI).

Example::

    from payagentic import PayAgentic

    client = PayAgentic(api_key="pa_test_…")
    wallets = client.wallets.list_wallets()
"""

from __future__ import annotations

__version__ = "0.1.1"

# Generated request/response models — re-exported under `models` namespace
from payagentic._generated import models
from payagentic.canonical_json import canonical_json_bytes

# Manifest-specific public capability invocation helper
from payagentic.capabilities import (
    CapabilityClient,
    CapabilityInvocationError,
    CapabilityInvocationReceipt,
    CapabilityInvocationResult,
    CapabilityTestAccounting,
    RetryDisposition,
    generate_capability_idempotency_key,
)

# Core façades
from payagentic.client import AsyncPayAgentic, PayAgentic

# Mandate envelope + signer
from payagentic.mandate import (
    BuildPresentationParams,
    LocalMandateSigner,
    MandateSigner,
    Money,
    PresentationClaim,
    present_mandate,
    sign_jws,
)

# Typed errors (RFC 7807 mapped)
from payagentic.middleware.errors import (
    ConflictError,
    ForbiddenError,
    InternalError,
    NotFoundError,
    PayAgenticError,
    ProblemDetails,
    RateLimitError,
    ServiceUnavailableError,
    UnauthorizedError,
    ValidationError,
    from_response,
    is_retryable,
)

# Idempotency
from payagentic.middleware.idempotency import generate_idempotency_key

# Retry / backoff
from payagentic.middleware.retry import (
    DEFAULT_RETRY_POLICY,
    RetryPolicy,
    async_with_retry,
    with_retry,
)

# Session keys
from payagentic.session_key import SessionKey

# Streaming (Server-Sent Events)
from payagentic.streaming import (
    AsyncEventStream,
    ServerSentEvent,
    subscribe_alerts,
    subscribe_approvals,
    subscribe_transactions,
)

# x402 paywall walker (also accessible as client.x402)
from payagentic.x402 import (
    AsyncX402Client,
    AsyncX402Walker,
    MandateRegistry,
    MandateRequiredError,
    PaymentsClient,
    PaymentStatus,
    PendingApprovalError,
    PolicyDeniedError,
    X402Client,
    X402Walker,
)

__all__ = [
    "DEFAULT_RETRY_POLICY",
    "AsyncEventStream",
    "AsyncPayAgentic",
    "AsyncX402Client",
    "AsyncX402Walker",
    "BuildPresentationParams",
    "CapabilityClient",
    "CapabilityInvocationError",
    "CapabilityInvocationReceipt",
    "CapabilityInvocationResult",
    "CapabilityTestAccounting",
    "ConflictError",
    "ForbiddenError",
    "InternalError",
    "LocalMandateSigner",
    "MandateRegistry",
    "MandateRequiredError",
    "MandateSigner",
    "Money",
    "NotFoundError",
    "PayAgentic",
    "PayAgenticError",
    "PaymentStatus",
    "PaymentsClient",
    "PendingApprovalError",
    "PolicyDeniedError",
    "PresentationClaim",
    "ProblemDetails",
    "RateLimitError",
    "RetryDisposition",
    "RetryPolicy",
    "ServerSentEvent",
    "ServiceUnavailableError",
    "SessionKey",
    "UnauthorizedError",
    "ValidationError",
    "X402Client",
    "X402Walker",
    "__version__",
    "async_with_retry",
    "canonical_json_bytes",
    "from_response",
    "generate_capability_idempotency_key",
    "generate_idempotency_key",
    "is_retryable",
    "models",
    "present_mandate",
    "sign_jws",
    "subscribe_alerts",
    "subscribe_approvals",
    "subscribe_transactions",
    "with_retry",
]
