"""Session key management for request signing.

This is a placeholder implementation that uses HMAC-SHA256.  The real
implementation will integrate Ed25519 keys issued by the platform.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import time
from dataclasses import dataclass

__all__ = ["SessionKey"]


@dataclass(frozen=True, slots=True)
class SessionKey:
    """An HMAC-based session key for request signing.

    In production this will be replaced by Ed25519 key-pairs managed via
    the platform's session-key API.  For now we use a shared secret for
    HMAC-SHA256 signing so the interface is stable.
    """

    secret: bytes

    @classmethod
    def from_environment(cls, *, env_var: str = "PAYAGENTIC_SESSION_SECRET") -> SessionKey:
        """Load session key material from an environment variable.

        The environment variable is expected to contain a hex-encoded secret.

        Raises:
            ValueError: If the environment variable is missing or empty.
        """
        raw = os.environ.get(env_var, "")
        if not raw:
            msg = f"Environment variable {env_var} is not set or empty"
            raise ValueError(msg)
        return cls(secret=bytes.fromhex(raw))

    def sign_request(self, method: str, url: str, body: bytes | None = None) -> str:
        """Produce an HMAC-SHA256 signature for a request.

        The canonical message is ``METHOD\\nURL\\nTIMESTAMP\\nBODY_HASH``.

        Returns:
            A hex-encoded HMAC-SHA256 digest.
        """
        timestamp = str(int(time.time()))
        body_hash = hashlib.sha256(body or b"").hexdigest()
        message = f"{method.upper()}\n{url}\n{timestamp}\n{body_hash}"
        signature = hmac.new(self.secret, message.encode(), hashlib.sha256).hexdigest()
        return f"{timestamp}.{signature}"
