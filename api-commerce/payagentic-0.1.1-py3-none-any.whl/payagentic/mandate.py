"""Mandate envelope, signer, and presentation helpers (M6).

Mirrors the TypeScript SDK surface and the Rust ``payagentic-mandate`` crate
byte-for-byte. The JWS protected header is
``{"alg":"EdDSA","kid":<kid>,"typ":"JWT"}`` and the payload is encoded with
RFC 8785 canonical JSON before signing so signatures verify identically
across SDKs.

This module is intentionally I/O-free; ``PaymentsClient.present_mandate``
combines it with the HTTP layer.
"""

from __future__ import annotations

import base64
import secrets
import time
import uuid
from dataclasses import dataclass
from typing import Any, Protocol

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
)

from payagentic.canonical_json import canonical_json_bytes

SUPPORTED_VERSION = 1
SUPPORTED_ALG = "EdDSA"
DEFAULT_MANDATE_AUDIENCE = "payagentic-mandate"
_ED25519_PRIVATE_KEY_SIZE = 32


# ---------------------------------------------------------------------------
# Signer
# ---------------------------------------------------------------------------


class MandateSigner(Protocol):
    """A signer capable of producing an Ed25519 signature for a mandate.

    ``kid`` is echoed in the JWS protected header so the verifier can look
    up the matching public key.
    """

    kid: str

    def sign(self, message: bytes) -> bytes:
        """Return the 64-byte Ed25519 signature over ``message``."""


@dataclass
class LocalMandateSigner:
    """Hold an Ed25519 private key in memory and sign locally.

    Use for development, tests, and short-lived agent processes. Production
    operator signers should wrap Vault or an HSM.
    """

    kid: str
    _private_key: Ed25519PrivateKey

    def __init__(self, kid: str, private_key_bytes: bytes) -> None:
        if len(private_key_bytes) != _ED25519_PRIVATE_KEY_SIZE:
            msg = (
                f"LocalMandateSigner: Ed25519 private key must be "
                f"{_ED25519_PRIVATE_KEY_SIZE} bytes, got {len(private_key_bytes)}"
            )
            raise ValueError(msg)
        self.kid = kid
        self._private_key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)

    @classmethod
    def generate(cls, kid: str) -> LocalMandateSigner:
        """Generate a new random Ed25519 key and return a signer."""
        sk = secrets.token_bytes(_ED25519_PRIVATE_KEY_SIZE)
        return cls(kid, sk)

    def sign(self, message: bytes) -> bytes:
        return self._private_key.sign(message)

    def public_key(self) -> bytes:
        return self._private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)


# ---------------------------------------------------------------------------
# Payloads
# ---------------------------------------------------------------------------


@dataclass
class Money:
    amount: str
    currency: str = "USDC"

    def to_dict(self) -> dict[str, Any]:
        return {"amount": self.amount, "currency": self.currency}


@dataclass
class PresentationClaim:
    """Per-charge claim asserted by the agent at presentation time."""

    amount: Money
    merchant_id: str
    mcc: str
    occurred_at: int
    geo: str
    resource_url: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "amount": self.amount.to_dict(),
            "merchant_id": self.merchant_id,
            "mcc": self.mcc,
            "occurred_at": self.occurred_at,
            "geo": self.geo,
            "resource_url": self.resource_url,
        }


@dataclass
class BuildPresentationParams:
    agent_spiffe_id: str
    audience: str
    grants: list[str]
    claim: PresentationClaim
    iat: int | None = None
    exp: int | None = None
    jti: str | None = None


# ---------------------------------------------------------------------------
# Base64url + JWS encoder
# ---------------------------------------------------------------------------


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def sign_jws(payload: Any, signer: MandateSigner, typ: str = "JWT") -> str:
    """Sign payload as a compact-form JWS with alg=EdDSA.

    The payload is encoded as canonical JSON (RFC 8785) before signing so
    cross-language verifiers reproduce the same signing input.
    """
    header = {"alg": SUPPORTED_ALG, "kid": signer.kid, "typ": typ}
    header_b64 = _b64url(canonical_json_bytes(header))
    payload_b64 = _b64url(canonical_json_bytes(payload))
    signing_input = f"{header_b64}.{payload_b64}"
    signature = signer.sign(signing_input.encode("ascii"))
    return f"{signing_input}.{_b64url(signature)}"


def _new_jti() -> str:
    return uuid.uuid4().hex


def present_mandate(params: BuildPresentationParams, signer: MandateSigner) -> str:
    """Build and sign a presentation JWS for the registered grant chain."""
    iat = params.iat if params.iat is not None else int(time.time())
    payload = {
        "v": SUPPORTED_VERSION,
        "typ": "presentation",
        "iss": params.agent_spiffe_id,
        "aud": params.audience,
        "jti": params.jti if params.jti is not None else _new_jti(),
        "iat": iat,
        "exp": params.exp if params.exp is not None else iat + 300,
        "grants": params.grants,
        "claim": params.claim.to_dict(),
    }
    return sign_jws(payload, signer)
