"""Bounded public invocation helper for manifest-specific capability routes."""

from __future__ import annotations

import json
import math
import secrets
import time
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Generic, Literal, TypeVar, cast
from urllib.parse import quote, urlsplit

import httpx

from payagentic._generated.capability_problem_contract import (
    CAPABILITY_PROBLEM_TUPLES,
    CAPABILITY_TEST_ACCOUNTING_LABEL,
)
from payagentic.canonical_json import canonical_json_bytes

MAX_INVOCATION_BYTES = 64 * 1024
MAX_SUCCESS_RESPONSE_BYTES = MAX_INVOCATION_BYTES + 16 * 1024
MAX_ERROR_RESPONSE_BYTES = 16 * 1024
MAX_IDEMPOTENCY_KEY_BYTES = 255
MAX_PATH_SEGMENT_BYTES = 255
MAX_RECOVERY_HINT_CHARACTERS = 256
DEFAULT_TIMEOUT_SECONDS = 30.0
MAX_TIMEOUT_SECONDS = 120.0
HTTP_PORT = 80
HTTPS_PORT = 443
ASCII_CONTROL_LIMIT = 0x20
ASCII_DELETE = 0x7F
SUCCESS_STATUS = 200

RetryDisposition = Literal["never", "state_change", "reconcile", "same_key"]
TOutput = TypeVar("TOutput", bound=Mapping[str, Any])


@dataclass(frozen=True)
class CapabilityInvocationReceipt:
    id: str


@dataclass(frozen=True)
class CapabilityTestAccounting:
    currency: Literal["USDC"]
    label: str


@dataclass(frozen=True)
class CapabilityInvocationResult(Generic[TOutput]):
    invocation_id: str
    status: Literal["settled"]
    output: TOutput
    receipt: CapabilityInvocationReceipt
    transport: Literal["rest", "mcp"]
    test_accounting: CapabilityTestAccounting
    deprecation_notice: str | None = None


@dataclass(frozen=True)
class _CapabilityProblem:
    code: str
    status: int
    correlation_id: str
    retry: RetryDisposition
    recovery_hint: str


class CapabilityInvocationError(Exception):
    """Bounded, sanitized public capability invocation failure."""

    def __init__(self, status_code: int, problem: _CapabilityProblem | None = None) -> None:
        suffix = f"HTTP {status_code}" if problem is None else f"{problem.code}, HTTP {status_code}"
        super().__init__(f"Capability invocation failed ({suffix})")
        self.status_code = status_code
        self.code = problem.code if problem is not None else None
        self.correlation_id = problem.correlation_id if problem is not None else None
        self.retry = problem.retry if problem is not None else None
        self.recovery_hint = problem.recovery_hint if problem is not None else None

    def __repr__(self) -> str:
        return (
            f"CapabilityInvocationError(status_code={self.status_code!r}, "
            f"code={self.code!r}, correlation_id={self.correlation_id!r}, "
            f"retry={self.retry!r})"
        )


def _contains_control(value: str) -> bool:
    return any(
        ord(character) < ASCII_CONTROL_LIMIT or ord(character) == ASCII_DELETE
        for character in value
    )


def _validate_base_url(value: str) -> str:
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as error:
        msg = "CapabilityClient base_url must be an absolute HTTP(S) origin"
        raise ValueError(msg) from error
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        msg = (
            "CapabilityClient base_url must be an HTTP(S) origin without credentials, "
            "a path, query, or fragment"
        )
        raise ValueError(msg)
    default_port = (parsed.scheme == "http" and port == HTTP_PORT) or (
        parsed.scheme == "https" and port == HTTPS_PORT
    )
    host = parsed.hostname
    if ":" in host:
        host = f"[{host}]"
    authority = host if port is None or default_port else f"{host}:{port}"
    return f"{parsed.scheme}://{authority}"


def _validate_credential(value: str) -> None:
    if not value.strip() or _contains_control(value):
        msg = "CapabilityClient requires a valid in-memory API key"
        raise ValueError(msg)


def _validate_segment(value: str, label: str) -> None:
    if (
        not value.strip()
        or _contains_control(value)
        or len(value.encode()) > MAX_PATH_SEGMENT_BYTES
    ):
        msg = f"{label} must be a nonblank path segment of at most 255 UTF-8 bytes"
        raise ValueError(msg)


def _validate_idempotency_key(value: str) -> None:
    if (
        not value.strip()
        or _contains_control(value)
        or len(value.encode()) > MAX_IDEMPOTENCY_KEY_BYTES
    ):
        msg = (
            "idempotency_key must be nonblank and at most 255 UTF-8 bytes "
            "without control characters"
        )
        raise ValueError(msg)


def _serialize_input(value: Mapping[str, object]) -> bytes:
    if not isinstance(value, Mapping) or not all(isinstance(key, str) for key in value):
        msg = "Capability invocation input must be a JSON object with string keys"
        raise TypeError(msg)
    try:
        body = canonical_json_bytes(dict(value))
    except (TypeError, ValueError) as error:
        msg = "Capability invocation input must be JSON serializable"
        raise TypeError(msg) from error
    if len(body) > MAX_INVOCATION_BYTES:
        msg = "Capability invocation input must not exceed 64 KiB of JSON"
        raise ValueError(msg)
    return body


def _media_type(response: httpx.Response) -> str:
    content_type = cast("str", response.headers.get("content-type", ""))
    return content_type.partition(";")[0].strip().lower()


def _read_bounded(response: httpx.Response, maximum: int) -> bytes | None:
    declared = response.headers.get("content-length")
    if declared is not None:
        try:
            length = int(declared)
        except ValueError:
            return None
        if length < 0 or length > maximum:
            return None
    chunks: list[bytes] = []
    total = 0
    try:
        for chunk in response.iter_bytes():
            total += len(chunk)
            if total > maximum:
                return None
            chunks.append(chunk)
    except httpx.HTTPError:
        return None
    return b"".join(chunks)


def _is_uuid(value: object) -> bool:
    if not isinstance(value, str):
        return False
    try:
        parsed = uuid.UUID(value)
    except ValueError:
        return False
    return str(parsed) == value.lower() and parsed.variant == uuid.RFC_4122


def _parse_problem(
    raw: bytes | None,
    response_status: int,
    api_key: str,
) -> _CapabilityProblem | None:
    if raw is None:
        return None
    try:
        value = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    required = {"code", "status", "title", "correlationId", "retry", "recoveryHint"}
    if (
        not isinstance(value, dict)
        or set(value) != required
        or not isinstance(value.get("code"), str)
        or api_key in value["code"]
        or value.get("status") != response_status
        or value.get("title") != "Capability invocation failed"
        or not _is_uuid(value.get("correlationId"))
        or not isinstance(value.get("retry"), str)
        or not isinstance(value.get("recoveryHint"), str)
        or len(value["recoveryHint"]) > MAX_RECOVERY_HINT_CHARACTERS
        or api_key in value["recoveryHint"]
    ):
        return None
    tuple_contract = (
        value["code"],
        response_status,
        value["retry"],
        value["recoveryHint"],
    )
    if tuple_contract not in CAPABILITY_PROBLEM_TUPLES:
        return None
    return _CapabilityProblem(
        code=value["code"],
        status=response_status,
        correlation_id=value["correlationId"],
        retry=cast("RetryDisposition", value["retry"]),
        recovery_hint=value["recoveryHint"],
    )


def _parse_success(raw: bytes | None) -> CapabilityInvocationResult[Mapping[str, Any]]:
    if raw is None:
        raise CapabilityInvocationError(200)
    try:
        value = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise CapabilityInvocationError(200) from None
    allowed = {
        "invocationId",
        "status",
        "output",
        "receipt",
        "transport",
        "testAccounting",
        "deprecationNotice",
    }
    if not isinstance(value, dict) or not set(value).issubset(allowed):
        raise CapabilityInvocationError(200)
    receipt = value.get("receipt")
    accounting = value.get("testAccounting")
    output = value.get("output")
    deprecation = value.get("deprecationNotice")
    try:
        output_size = len(
            json.dumps(output, allow_nan=False, ensure_ascii=False, separators=(",", ":")).encode(),
        )
    except (TypeError, ValueError):
        raise CapabilityInvocationError(200) from None
    if (
        not _is_uuid(value.get("invocationId"))
        or value.get("status") != "settled"
        or not isinstance(output, dict)
        or output_size > MAX_INVOCATION_BYTES
        or not isinstance(receipt, dict)
        or set(receipt) != {"id"}
        or not _is_uuid(receipt.get("id"))
        or value.get("transport") not in {"rest", "mcp"}
        or not isinstance(accounting, dict)
        or set(accounting) != {"currency", "label"}
        or accounting.get("currency") != "USDC"
        or accounting.get("label") != CAPABILITY_TEST_ACCOUNTING_LABEL
        or not (deprecation is None or isinstance(deprecation, str))
    ):
        raise CapabilityInvocationError(200)
    return CapabilityInvocationResult(
        invocation_id=value["invocationId"],
        status="settled",
        output=cast("Mapping[str, Any]", output),
        receipt=CapabilityInvocationReceipt(id=receipt["id"]),
        transport=cast("Literal['rest', 'mcp']", value["transport"]),
        test_accounting=CapabilityTestAccounting(
            currency="USDC",
            label=accounting["label"],
        ),
        deprecation_notice=deprecation,
    )


class CapabilityClient:
    """Invoke manifest-specific public capability routes with bounded JSON."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self._base_url = _validate_base_url(base_url)
        _validate_credential(api_key)
        if not math.isfinite(timeout) or timeout <= 0 or timeout > MAX_TIMEOUT_SECONDS:
            msg = "CapabilityClient timeout must be between 0 and 120 seconds"
            raise ValueError(msg)
        self._api_key = api_key
        self._timeout = timeout

    def invoke(
        self,
        provider_slug: str,
        capability_slug: str,
        input_data: Mapping[str, object],
        *,
        idempotency_key: str,
    ) -> CapabilityInvocationResult[Mapping[str, Any]]:
        """Invoke once; reuse the caller-owned key only when retrying this input."""
        _validate_segment(provider_slug, "provider_slug")
        _validate_segment(capability_slug, "capability_slug")
        _validate_idempotency_key(idempotency_key)
        body = _serialize_input(input_data)
        path = f"/c/{quote(provider_slug, safe='')}/{quote(capability_slug, safe='')}/invoke"
        headers = {
            "accept": "application/json",
            "authorization": f"Bearer {self._api_key}",
            "content-type": "application/json",
            "idempotency-key": idempotency_key,
        }

        try:
            with (
                httpx.Client(timeout=self._timeout, follow_redirects=False) as client,
                client.stream(
                    "POST",
                    self._base_url + path,
                    content=body,
                    headers=headers,
                ) as response,
            ):
                return _parse_response(response, self._api_key)
        except httpx.HTTPError:
            raise CapabilityInvocationError(0) from None


def _parse_response(
    response: httpx.Response,
    api_key: str,
) -> CapabilityInvocationResult[Mapping[str, Any]]:
    if response.status_code == SUCCESS_STATUS:
        if _media_type(response) != "application/json":
            raise CapabilityInvocationError(SUCCESS_STATUS)
        return _parse_success(_read_bounded(response, MAX_SUCCESS_RESPONSE_BYTES))

    media_type = _media_type(response)
    raw = (
        _read_bounded(response, MAX_ERROR_RESPONSE_BYTES)
        if media_type in {"application/json", "application/problem+json"}
        else None
    )
    problem = _parse_problem(raw, response.status_code, api_key)
    raise CapabilityInvocationError(response.status_code, problem)


def generate_capability_idempotency_key() -> str:
    """Generate a standards-correct RFC 9562 UUIDv7 for one logical invocation."""
    value = bytearray(secrets.token_bytes(16))
    timestamp_ms = time.time_ns() // 1_000_000
    value[0:6] = timestamp_ms.to_bytes(6, byteorder="big")
    value[6] = value[6] & 0x0F | 0x70
    value[8] = value[8] & 0x3F | 0x80
    return str(uuid.UUID(bytes=bytes(value)))


__all__ = [
    "CapabilityClient",
    "CapabilityInvocationError",
    "CapabilityInvocationReceipt",
    "CapabilityInvocationResult",
    "CapabilityTestAccounting",
    "RetryDisposition",
    "generate_capability_idempotency_key",
]
