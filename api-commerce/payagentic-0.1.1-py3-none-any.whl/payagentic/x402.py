"""x402 payment-flow walker.

Handles the HTTP 402 Payment Required retry loop: when a resource returns
402, the walker proposes a payment via the PayAgentic gateway, waits for
settlement, then retries the original request with a payment receipt.

The walker can be constructed two ways:

1. Façade-injected — ``X402Walker(payagentic=<PayAgentic>)``: shares the
   parent's resolved config and generated transport. Gateway-bound calls
   (``POST /v1/payments/propose``, ``GET /v1/payments/{id}``) delegate to
   :mod:`payagentic._generated.api.payments`.
2. Standalone — ``X402Walker(api_key=..., base_url=...)``: uses direct
   ``httpx`` against the gateway. Useful for tests and minimal callers.

``X402Client`` is kept as a backward-compat alias.

NOTE: ``/v1/mandates/issue`` and ``/v1/mandates/{jti}/revoke`` are owned
by the identity service and **not** in the gateway spec at
``api/openapi.json``. :class:`PaymentsClient` keeps its existing
direct-``httpx`` implementation for those endpoints until they are
surfaced in the spec.
"""

from __future__ import annotations

import base64
import contextlib
import json
import time
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Any, Self, cast

import httpx

from payagentic.mandate import (
    BuildPresentationParams,
    MandateSigner,
    PresentationClaim,
)
from payagentic.mandate import (
    present_mandate as _build_presentation,
)
from payagentic.middleware.errors import PayAgenticError
from payagentic.middleware.idempotency import generate_idempotency_key

if TYPE_CHECKING:
    from decimal import Decimal

    from payagentic._generated.client import AuthenticatedClient
    from payagentic.client import AsyncPayAgentic, PayAgentic


class PaymentStatus(StrEnum):
    """Local payment-status enum used by the x402 walker's polling loop."""

    PROPOSED = "proposed"
    POLICY_APPROVED = "policy_approved"
    POLICY_REJECTED = "policy_rejected"
    SIGNING = "signing"
    BROADCAST = "broadcast"
    SETTLED = "settled"
    FAILED = "failed"


__all__ = [
    "AsyncX402Client",
    "AsyncX402Walker",
    "MandateRegistry",
    "MandateRequiredError",
    "PaymentsClient",
    "PendingApprovalError",
    "PolicyDeniedError",
    "X402Client",
    "X402Walker",
]

DEFAULT_BASE_URL = "https://app.payagentic.ai"
DEFAULT_MANDATE_AUDIENCE = "payagentic-mandate"
_HTTP_BAD_REQUEST = 400
_HTTP_402 = 402
_HTTP_FORBIDDEN = 403
_MAX_POLL_ATTEMPTS = 30
_POLL_INTERVAL_SECONDS = 0.2
# Approval is operator-driven, so poll less aggressively than settlement.
_APPROVAL_POLL_INTERVAL_SECONDS = 1.0
# Payment statuses that terminally end an approval wait without a credential.
_APPROVAL_TERMINAL_STATUSES = frozenset({"denied", "rejected", "expired", "failed"})


class MandateRequiredError(PayAgenticError):
    """Raised when a 402 requires a mandate but no registry is configured."""

    def __init__(self, resource_url: str, detail: str | None = None) -> None:
        msg = f"MANDATE_REQUIRED: resource {resource_url} requires a mandate presentation"
        if detail:
            msg = f"{msg}: {detail}"
        super().__init__(msg)
        self.resource_url = resource_url


class PendingApprovalError(PayAgenticError):
    """Raised when a payment is parked for an operator decision."""

    def __init__(self, transaction_id: str | None, reason: str | None = None) -> None:
        super().__init__(reason or "Payment requires operator approval", status_code=202)
        self.transaction_id = transaction_id


class PolicyDeniedError(PayAgenticError):
    """Raised when policy or an operator terminally denies a payment."""

    def __init__(self, transaction_id: str | None, reason: str | None = None) -> None:
        super().__init__(reason or "Policy denied this payment", status_code=403)
        self.transaction_id = transaction_id


@dataclass
class MandateRegistry:
    """Mandate context bound to a payments client."""

    grants: list[str]
    signer: MandateSigner
    agent_spiffe_id: str
    audience: str = DEFAULT_MANDATE_AUDIENCE


def _propose_via_generated(
    auth_client: AuthenticatedClient,
    *,
    payment_requirements: str,
    resource_url: str,
    max_amount: str | None,
    idempotency_key: str,
) -> Any:
    """Delegate POST /v1/payments/propose to the generated operation."""
    from payagentic._generated.api.payments.propose_payment import (  # noqa: PLC0415
        sync as propose_sync,
    )
    from payagentic._generated.models import ProposePaymentRequest  # noqa: PLC0415
    from payagentic._generated.types import UNSET  # noqa: PLC0415

    body = ProposePaymentRequest(
        idempotency_key=idempotency_key,
        payment_requirements=payment_requirements,
        resource_url=resource_url,
        max_amount=max_amount if max_amount is not None else UNSET,
    )
    result = propose_sync(client=auth_client, body=body)
    if result is None:
        msg = "propose_payment returned no parsed body"
        raise PayAgenticError(msg)
    return result


def _get_payment_via_generated(
    auth_client: AuthenticatedClient,
    payment_id: str,
) -> Any:
    """Delegate GET /v1/payments/{id} to the generated operation."""
    from payagentic._generated.api.payments.get_payment import (  # noqa: PLC0415
        sync as get_sync,
    )

    result = get_sync(id=payment_id, client=auth_client)
    if result is None:
        msg = f"get_payment({payment_id}) returned no parsed body"
        raise PayAgenticError(msg)
    return result


async def _propose_via_generated_async(
    auth_client: AuthenticatedClient,
    *,
    payment_requirements: str,
    resource_url: str,
    max_amount: str | None,
    idempotency_key: str,
) -> Any:
    """Async delegate for POST /v1/payments/propose."""
    from payagentic._generated.api.payments.propose_payment import (  # noqa: PLC0415
        asyncio as propose_async,
    )
    from payagentic._generated.models import ProposePaymentRequest  # noqa: PLC0415
    from payagentic._generated.types import UNSET  # noqa: PLC0415

    body = ProposePaymentRequest(
        idempotency_key=idempotency_key,
        payment_requirements=payment_requirements,
        resource_url=resource_url,
        max_amount=max_amount if max_amount is not None else UNSET,
    )
    result = await propose_async(client=auth_client, body=body)
    if result is None:
        msg = "propose_payment returned no parsed body"
        raise PayAgenticError(msg)
    return result


async def _get_payment_via_generated_async(
    auth_client: AuthenticatedClient,
    payment_id: str,
) -> Any:
    """Async delegate for GET /v1/payments/{id}."""
    from payagentic._generated.api.payments.get_payment import (  # noqa: PLC0415
        asyncio as get_async,
    )

    result = await get_async(id=payment_id, client=auth_client)
    if result is None:
        msg = f"get_payment({payment_id}) returned no parsed body"
        raise PayAgenticError(msg)
    return result


class _DictResponse:
    """Minimal attribute view over a dict, for standalone-mode responses."""

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    def __getattr__(self, name: str) -> Any:
        if name in self._payload:
            return self._payload[name]
        msg = f"response has no field {name!r}"
        raise AttributeError(msg)


def _cap_str(cap: Decimal | None) -> str | None:
    """Render a client-side spend cap for the propose body, or ``None`` to omit
    it (no client cap — the org spend policy governs), matching TS/Go."""
    return None if cap is None else str(cap)


def _v2_credential(proposal: dict[str, Any]) -> tuple[str, str]:
    """Extract the ``(header_name, header_value)`` rail credential from a v2
    propose reply, raising when absent — the server is not on the x402 v2 rail,
    or the payment needs approval, so retrying without a credential is wrong."""
    credential = proposal.get("credential") or {}
    header_name = credential.get("header_name")
    header_value = credential.get("header_value")
    if not header_name or not header_value:
        msg = (
            "x402 v2: propose response did not include a rail credential "
            "(is the server on the x402 v2 rail, or does the payment need approval?)"
        )
        raise PayAgenticError(msg)
    return header_name, header_value


def _body_challenge(response: httpx.Response) -> str:
    """Return a flat JSON-body challenge in the gateway's string field."""
    try:
        challenge = response.json()
    except ValueError as error:
        msg = "x402: 402 response contained neither a challenge header nor valid JSON"
        raise PayAgenticError(msg) from error
    if not isinstance(challenge, dict):
        msg = "x402: JSON body challenge must be an object"
        raise PayAgenticError(msg)
    return json.dumps(challenge, ensure_ascii=False, separators=(",", ":"))


def _legacy_payment_header(proposal: dict[str, Any]) -> str | None:
    """Build the Authorization credential used by flat body challenges."""
    signature = proposal.get("payment_signature")
    if not isinstance(signature, str) or not signature:
        return None
    authorization = proposal.get("authorization")
    if isinstance(authorization, dict):
        payload: dict[str, Any] = {
            "scheme": "exact",
            "authorization": authorization,
            "signature": signature,
        }
    else:
        intent = proposal.get("intent")
        intent_id = intent.get("id") if isinstance(intent, dict) else None
        if not isinstance(intent_id, str) or not intent_id:
            return None
        payload = {"signature": signature, "intent_id": intent_id}
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
    return f"Payment {base64.b64encode(raw).decode()}"


class X402Walker:
    """Synchronous x402 payment-flow walker."""

    def __init__(
        self,
        payagentic: PayAgentic | None = None,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        wallet_id: str | None = None,
        http: httpx.Client | None = None,
    ) -> None:
        if payagentic is not None:
            self._api_key = payagentic._config.api_key  # noqa: SLF001
            self._base_url = payagentic._config.base_url  # noqa: SLF001
            self._wallet_id = wallet_id or payagentic._config.x402_wallet_id  # noqa: SLF001
            self._auth_client: AuthenticatedClient | None = payagentic._auth_client  # noqa: SLF001
            self._http = http or payagentic._auth_client.get_httpx_client()  # noqa: SLF001
            self._owns_http = http is not None
        else:
            if api_key is None:
                msg = "X402Walker requires either api_key= or payagentic="
                raise ValueError(msg)
            self._api_key = api_key
            self._base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
            self._wallet_id = wallet_id
            self._auth_client = None
            self._http = http or httpx.Client()
            self._owns_http = True
        # Seller fetches hit THIRD-PARTY resource URLs and must NOT carry the
        # gateway Bearer token. In facade mode self._http is the authenticated
        # gateway client (bakes Authorization into default headers), so use a
        # plain client for the seller. When a client is injected (tests) or in
        # standalone mode (plain client, per-call gateway auth only), reuse it.
        if http is not None or self._auth_client is None:
            self._seller_http = self._http
            self._owns_seller_http = False
        else:
            self._seller_http = httpx.Client()
            self._owns_seller_http = True

    def fetch(
        self,
        url: str,
        *,
        method: str = "GET",
        max_payment_usd: Decimal | None = None,
        wait_for_approval: float | None = None,
        idempotency_key: str | None = None,
    ) -> httpx.Response:
        """Fetch a URL, paying with x402 if a 402 is returned.

        ``max_payment_usd`` caps the amount the walker will authorize; when
        ``None`` (the default) no client-side cap is sent and the org's spend
        policy governs — matching the TS and Go SDKs.

        ``wait_for_approval`` (seconds) makes an x402 v2 payment that a spend
        policy parked for operator approval block until it is approved (then
        resume with the signed credential) or terminally denied, instead of
        raising. ``None`` (default) does not wait."""
        response = self._seller_http.request(method, url)
        if response.status_code != _HTTP_402:
            return response

        return self._handle_402(
            response,
            url=url,
            method=method,
            max_payment_usd=max_payment_usd,
            wait_for_approval=wait_for_approval,
            idempotency_key=idempotency_key,
        )

    def _handle_402(  # noqa: PLR0913
        self,
        response: httpx.Response,
        *,
        url: str,
        method: str,
        max_payment_usd: Decimal | None,
        wait_for_approval: float | None = None,
        idempotency_key: str | None = None,
    ) -> httpx.Response:
        """Process a 402 response by proposing payment and retrying."""
        # x402 v2 (canonical spec): the challenge rides in the Payment-Required
        # header and the seller (not us) settles. Handled distinctly from the
        # legacy body-derived / buyer-broadcasts path below.
        payment_required = response.headers.get("Payment-Required", "")
        if payment_required:
            return self._pay_v2(
                url=url,
                method=method,
                challenge=payment_required,
                max_payment_usd=max_payment_usd,
                wait_for_approval=wait_for_approval,
                idempotency_key=idempotency_key,
            )

        payment_requirements = response.headers.get(
            "X-PAYMENT-REQUIREMENTS",
            response.headers.get("X-Payment-Requirements", ""),
        )

        if not payment_requirements:
            return self._pay_body_challenge(
                url=url,
                method=method,
                challenge=_body_challenge(response),
                max_payment_usd=max_payment_usd,
                wait_for_approval=wait_for_approval,
                idempotency_key=idempotency_key,
            )

        payment = self._propose_payment(
            payment_requirements=payment_requirements,
            resource_url=url,
            max_amount=_cap_str(max_payment_usd),
            idempotency_key=idempotency_key,
        )

        payment_id = str(payment.id)

        for _ in range(_MAX_POLL_ATTEMPTS):
            current = self._get_payment(payment_id)
            if str(current.status) == PaymentStatus.SETTLED.value:
                break
            if str(current.status) == PaymentStatus.FAILED.value:
                msg = f"Payment {payment_id} failed"
                raise PayAgenticError(msg)
            time.sleep(_POLL_INTERVAL_SECONDS)
        else:
            msg = f"Payment {payment_id} did not settle in time"
            raise PayAgenticError(msg)

        headers = {"X-Payment-Receipt": payment_id}
        return self._seller_http.request(method, url, headers=headers)

    def _pay_body_challenge(  # noqa: PLR0913
        self,
        *,
        url: str,
        method: str,
        challenge: str,
        max_payment_usd: Decimal | None,
        wait_for_approval: float | None,
        idempotency_key: str | None,
    ) -> httpx.Response:
        """Pay a flat JSON-body challenge and retry with Authorization."""
        proposal = self._propose_v2(
            challenge=challenge,
            resource_url=url,
            max_amount=_cap_str(max_payment_usd),
            idempotency_key=idempotency_key,
        )
        txn_id = proposal.get("transaction_id") or proposal.get("id")
        payment_header = _legacy_payment_header(proposal)
        if payment_header is None:
            if wait_for_approval is not None and txn_id:
                return self._resume_after_approval(
                    url=url, method=method, txn_id=str(txn_id), timeout_s=wait_for_approval
                )
            raise PendingApprovalError(
                str(txn_id) if txn_id else None,
                str(proposal.get("reason") or "Payment requires operator approval"),
            )
        return self._retry_with_credential(
            url=url,
            method=method,
            header_name="Authorization",
            header_value=payment_header,
            txn_id=str(txn_id) if txn_id else None,
        )

    def _propose_payment(
        self,
        *,
        payment_requirements: str,
        resource_url: str,
        max_amount: str | None,
        idempotency_key: str | None,
    ) -> Any:
        """POST /v1/payments/propose.

        Uses the generated transport when the walker was created from a
        PayAgentic facade; standalone mode posts directly.
        """
        idempotency_key = idempotency_key or generate_idempotency_key()
        if self._auth_client is not None and self._wallet_id is None:
            return _propose_via_generated(
                self._auth_client,
                payment_requirements=payment_requirements,
                resource_url=resource_url,
                max_amount=max_amount,
                idempotency_key=idempotency_key,
            )
        body: dict[str, Any] = {
            "idempotency_key": idempotency_key,
            "payment_requirements": payment_requirements,
            "resource_url": resource_url,
        }
        if max_amount is not None:
            body["max_amount"] = max_amount
        if self._wallet_id is not None:
            body["wallet_id"] = self._wallet_id
        resp = self._http.post(
            f"{self._base_url}/v1/payments/propose",
            json=body,
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        resp.raise_for_status()
        return _DictResponse(resp.json())

    def _pay_v2(  # noqa: PLR0913
        self,
        *,
        url: str,
        method: str,
        challenge: str,
        max_payment_usd: Decimal | None,
        wait_for_approval: float | None = None,
        idempotency_key: str | None = None,
    ) -> httpx.Response:
        """x402 v2 walk: propose the raw challenge, retry with the gateway's rail
        credential header, then report the seller's Payment-Response receipt."""
        prop = self._propose_v2(
            challenge=challenge,
            resource_url=url,
            max_amount=_cap_str(max_payment_usd),
            idempotency_key=idempotency_key,
        )
        credential = cast("dict[str, Any]", prop.get("credential") or {})
        header_name = credential.get("header_name")
        header_value = credential.get("header_value")
        txn_id = prop.get("transaction_id") or prop.get("id")

        # No credential: parked for operator approval, or wrong rail. Resume once
        # approved when the caller opted in; otherwise raise a clear error.
        if not isinstance(header_name, str) or not isinstance(header_value, str):
            if wait_for_approval is not None and txn_id:
                return self._resume_after_approval(
                    url=url, method=method, txn_id=str(txn_id), timeout_s=wait_for_approval
                )
            raise PendingApprovalError(
                str(txn_id) if txn_id else None,
                str(prop.get("reason") or "Payment requires operator approval"),
            )

        return self._retry_with_credential(
            url=url,
            method=method,
            header_name=header_name,
            header_value=header_value,
            txn_id=str(txn_id) if txn_id else None,
        )

    def _retry_with_credential(
        self,
        *,
        url: str,
        method: str,
        header_name: str,
        header_value: str,
        txn_id: str | None,
    ) -> httpx.Response:
        """Retry the resource with the rail credential header, then report the
        seller's Payment-Response receipt (advisory) on success."""
        resp = self._seller_http.request(method, url, headers={header_name: header_value})
        if resp.is_success and txn_id:
            receipt = resp.headers.get("Payment-Response", "")
            if receipt:
                self._report_settlement(txn_id, receipt)
        return resp

    def _resume_after_approval(
        self, *, url: str, method: str, txn_id: str, timeout_s: float
    ) -> httpx.Response:
        """Poll the payment until a spend-policy approval resolves: once it is
        'authorized' with a credential we retry the seller; a terminal denial
        raises; the wait is bounded by ``timeout`` seconds. Re-proposing would
        just park a new payment behind the stateless approval rule, so we fetch
        the parked credential and resume instead."""
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            status, header_name, header_value = self._get_payment_status_v2(txn_id)
            if status == "authorized" and header_name and header_value:
                return self._retry_with_credential(
                    url=url,
                    method=method,
                    header_name=header_name,
                    header_value=header_value,
                    txn_id=txn_id,
                )
            if status in _APPROVAL_TERMINAL_STATUSES:
                raise PolicyDeniedError(
                    txn_id, f"x402 v2: payment {txn_id} was '{status}' during approval"
                )
            time.sleep(_APPROVAL_POLL_INTERVAL_SECONDS)
        msg = f"x402 v2: approval for payment {txn_id} timed out"
        raise PayAgenticError(msg)

    def _get_payment_status_v2(self, txn_id: str) -> tuple[str, str | None, str | None]:
        """GET /v1/payments/{id} -> (status, credential header name, value)."""
        resp = self._http.get(
            f"{self._base_url}/v1/payments/{txn_id}",
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        resp.raise_for_status()
        payment = resp.json()
        credential = payment.get("credential") or {}
        return (
            str(payment.get("status", "")),
            credential.get("header_name"),
            credential.get("header_value"),
        )

    def _propose_v2(
        self,
        *,
        challenge: str,
        resource_url: str,
        max_amount: str | None,
        idempotency_key: str | None,
    ) -> dict[str, Any]:
        """POST /v1/payments/propose for the v2 rail, returning the raw JSON so
        the rail credential is visible (the generated model predates it)."""
        body: dict[str, Any] = {
            "idempotency_key": idempotency_key or generate_idempotency_key(),
            "payment_requirements": challenge,
            "resource_url": resource_url,
        }
        if max_amount is not None:
            body["max_amount"] = max_amount
        if self._wallet_id is not None:
            body["wallet_id"] = self._wallet_id
        resp = self._http.post(
            f"{self._base_url}/v1/payments/propose",
            json=body,
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        if resp.status_code == _HTTP_FORBIDDEN:
            problem = resp.json()
            raise PolicyDeniedError(
                str(problem.get("transaction_id")) if problem.get("transaction_id") else None,
                str(problem.get("reason") or problem.get("detail") or "Policy denied this payment"),
            )
        resp.raise_for_status()
        return cast("dict[str, Any]", resp.json())

    def _report_settlement(self, transaction_id: str, payment_response: str) -> None:
        """Forward the seller's Payment-Response to the settlement endpoint.

        Advisory only: the payments watcher verifies settlement on-chain, so a
        failure here must not fail the (successful) fetch."""
        with contextlib.suppress(httpx.HTTPError):
            self._http.post(
                f"{self._base_url}/v1/payments/{transaction_id}/settlement",
                json={"payment_response": payment_response},
                headers={"Authorization": f"Bearer {self._api_key}"},
            )

    def _get_payment(self, payment_id: str) -> Any:
        """GET /v1/payments/{id}. Uses generated transport when injected."""
        if self._auth_client is not None:
            return _get_payment_via_generated(self._auth_client, payment_id)
        resp = self._http.get(
            f"{self._base_url}/v1/payments/{payment_id}",
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        resp.raise_for_status()
        return _DictResponse(resp.json())

    def close(self) -> None:
        """Close the underlying HTTP client(s) owned by this walker."""
        if self._owns_http:
            self._http.close()
        if self._owns_seller_http:
            self._seller_http.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


X402Client = X402Walker


class AsyncX402Walker:
    """Asynchronous x402 payment-flow walker."""

    def __init__(
        self,
        payagentic: AsyncPayAgentic | None = None,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        wallet_id: str | None = None,
        http: httpx.AsyncClient | None = None,
    ) -> None:
        if payagentic is not None:
            self._api_key = payagentic._config.api_key  # noqa: SLF001
            self._base_url = payagentic._config.base_url  # noqa: SLF001
            self._wallet_id = wallet_id or payagentic._config.x402_wallet_id  # noqa: SLF001
            self._auth_client: AuthenticatedClient | None = payagentic._auth_client  # noqa: SLF001
            self._http = http or payagentic._auth_client.get_async_httpx_client()  # noqa: SLF001
            self._owns_http = http is not None
        else:
            if api_key is None:
                msg = "AsyncX402Walker requires either api_key= or payagentic="
                raise ValueError(msg)
            self._api_key = api_key
            self._base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
            self._wallet_id = wallet_id
            self._auth_client = None
            self._http = http or httpx.AsyncClient()
            self._owns_http = True
        # Seller fetches must not carry the gateway Bearer token (see the sync
        # walker). Plain client for third-party seller URLs in facade mode.
        if http is not None or self._auth_client is None:
            self._seller_http = self._http
            self._owns_seller_http = False
        else:
            self._seller_http = httpx.AsyncClient()
            self._owns_seller_http = True

    async def fetch(
        self,
        url: str,
        *,
        method: str = "GET",
        max_payment_usd: Decimal | None = None,
        wait_for_approval: float | None = None,
        idempotency_key: str | None = None,
    ) -> httpx.Response:
        """Async fetch (see X402Walker.fetch)."""
        response = await self._seller_http.request(method, url)
        if response.status_code != _HTTP_402:
            return response

        return await self._handle_402(
            response,
            url=url,
            method=method,
            max_payment_usd=max_payment_usd,
            wait_for_approval=wait_for_approval,
            idempotency_key=idempotency_key,
        )

    async def _handle_402(  # noqa: PLR0913
        self,
        response: httpx.Response,
        *,
        url: str,
        method: str,
        max_payment_usd: Decimal | None,
        wait_for_approval: float | None = None,
        idempotency_key: str | None = None,
    ) -> httpx.Response:
        import asyncio  # noqa: PLC0415

        # x402 v2 (canonical spec): challenge in the Payment-Required header,
        # seller settles. See the sync walker for the rationale.
        payment_required = response.headers.get("Payment-Required", "")
        if payment_required:
            return await self._pay_v2(
                url=url,
                method=method,
                challenge=payment_required,
                max_payment_usd=max_payment_usd,
                wait_for_approval=wait_for_approval,
                idempotency_key=idempotency_key,
            )

        payment_requirements = response.headers.get(
            "X-PAYMENT-REQUIREMENTS",
            response.headers.get("X-Payment-Requirements", ""),
        )

        if not payment_requirements:
            return await self._pay_body_challenge(
                url=url,
                method=method,
                challenge=_body_challenge(response),
                max_payment_usd=max_payment_usd,
                wait_for_approval=wait_for_approval,
                idempotency_key=idempotency_key,
            )

        payment = await self._propose_payment(
            payment_requirements=payment_requirements,
            resource_url=url,
            max_amount=_cap_str(max_payment_usd),
            idempotency_key=idempotency_key,
        )

        payment_id = str(payment.id)

        for _ in range(_MAX_POLL_ATTEMPTS):
            current = await self._get_payment(payment_id)
            if str(current.status) == PaymentStatus.SETTLED.value:
                break
            if str(current.status) == PaymentStatus.FAILED.value:
                msg = f"Payment {payment_id} failed"
                raise PayAgenticError(msg)
            await asyncio.sleep(_POLL_INTERVAL_SECONDS)
        else:
            msg = f"Payment {payment_id} did not settle in time"
            raise PayAgenticError(msg)

        headers = {"X-Payment-Receipt": payment_id}
        return await self._seller_http.request(method, url, headers=headers)

    async def _pay_body_challenge(  # noqa: PLR0913
        self,
        *,
        url: str,
        method: str,
        challenge: str,
        max_payment_usd: Decimal | None,
        wait_for_approval: float | None,
        idempotency_key: str | None,
    ) -> httpx.Response:
        proposal = await self._propose_v2(
            challenge=challenge,
            resource_url=url,
            max_amount=_cap_str(max_payment_usd),
            idempotency_key=idempotency_key,
        )
        txn_id = proposal.get("transaction_id") or proposal.get("id")
        payment_header = _legacy_payment_header(proposal)
        if payment_header is None:
            if wait_for_approval is not None and txn_id:
                return await self._resume_after_approval(
                    url=url, method=method, txn_id=str(txn_id), timeout_s=wait_for_approval
                )
            raise PendingApprovalError(
                str(txn_id) if txn_id else None,
                str(proposal.get("reason") or "Payment requires operator approval"),
            )
        return await self._retry_with_credential(
            url=url,
            method=method,
            header_name="Authorization",
            header_value=payment_header,
            txn_id=str(txn_id) if txn_id else None,
        )

    async def _propose_payment(
        self,
        *,
        payment_requirements: str,
        resource_url: str,
        max_amount: str | None,
        idempotency_key: str | None,
    ) -> Any:
        idempotency_key = idempotency_key or generate_idempotency_key()
        if self._auth_client is not None and self._wallet_id is None:
            return await _propose_via_generated_async(
                self._auth_client,
                payment_requirements=payment_requirements,
                resource_url=resource_url,
                max_amount=max_amount,
                idempotency_key=idempotency_key,
            )
        body: dict[str, Any] = {
            "idempotency_key": idempotency_key,
            "payment_requirements": payment_requirements,
            "resource_url": resource_url,
        }
        if max_amount is not None:
            body["max_amount"] = max_amount
        if self._wallet_id is not None:
            body["wallet_id"] = self._wallet_id
        resp = await self._http.post(
            f"{self._base_url}/v1/payments/propose",
            json=body,
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        resp.raise_for_status()
        return _DictResponse(resp.json())

    async def _pay_v2(  # noqa: PLR0913
        self,
        *,
        url: str,
        method: str,
        challenge: str,
        max_payment_usd: Decimal | None,
        wait_for_approval: float | None = None,
        idempotency_key: str | None = None,
    ) -> httpx.Response:
        """Async x402 v2 walk (mirror of the sync walker's ``_pay_v2``)."""
        prop = await self._propose_v2(
            challenge=challenge,
            resource_url=url,
            max_amount=_cap_str(max_payment_usd),
            idempotency_key=idempotency_key,
        )
        credential = cast("dict[str, Any]", prop.get("credential") or {})
        header_name = credential.get("header_name")
        header_value = credential.get("header_value")
        txn_id = prop.get("transaction_id") or prop.get("id")

        if not isinstance(header_name, str) or not isinstance(header_value, str):
            if wait_for_approval is not None and txn_id:
                return await self._resume_after_approval(
                    url=url, method=method, txn_id=str(txn_id), timeout_s=wait_for_approval
                )
            raise PendingApprovalError(
                str(txn_id) if txn_id else None,
                str(prop.get("reason") or "Payment requires operator approval"),
            )

        return await self._retry_with_credential(
            url=url,
            method=method,
            header_name=header_name,
            header_value=header_value,
            txn_id=str(txn_id) if txn_id else None,
        )

    async def _retry_with_credential(
        self,
        *,
        url: str,
        method: str,
        header_name: str,
        header_value: str,
        txn_id: str | None,
    ) -> httpx.Response:
        resp = await self._seller_http.request(method, url, headers={header_name: header_value})
        if resp.is_success and txn_id:
            receipt = resp.headers.get("Payment-Response", "")
            if receipt:
                await self._report_settlement(txn_id, receipt)
        return resp

    async def _resume_after_approval(
        self, *, url: str, method: str, txn_id: str, timeout_s: float
    ) -> httpx.Response:
        """Async mirror of the sync walker's ``_resume_after_approval``."""
        import asyncio  # noqa: PLC0415

        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            status, header_name, header_value = await self._get_payment_status_v2(txn_id)
            if status == "authorized" and header_name and header_value:
                return await self._retry_with_credential(
                    url=url,
                    method=method,
                    header_name=header_name,
                    header_value=header_value,
                    txn_id=txn_id,
                )
            if status in _APPROVAL_TERMINAL_STATUSES:
                raise PolicyDeniedError(
                    txn_id, f"x402 v2: payment {txn_id} was '{status}' during approval"
                )
            await asyncio.sleep(_APPROVAL_POLL_INTERVAL_SECONDS)
        msg = f"x402 v2: approval for payment {txn_id} timed out"
        raise PayAgenticError(msg)

    async def _get_payment_status_v2(self, txn_id: str) -> tuple[str, str | None, str | None]:
        resp = await self._http.get(
            f"{self._base_url}/v1/payments/{txn_id}",
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        resp.raise_for_status()
        payment = resp.json()
        credential = payment.get("credential") or {}
        return (
            str(payment.get("status", "")),
            credential.get("header_name"),
            credential.get("header_value"),
        )

    async def _propose_v2(
        self,
        *,
        challenge: str,
        resource_url: str,
        max_amount: str | None,
        idempotency_key: str | None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "idempotency_key": idempotency_key or generate_idempotency_key(),
            "payment_requirements": challenge,
            "resource_url": resource_url,
        }
        if max_amount is not None:
            body["max_amount"] = max_amount
        if self._wallet_id is not None:
            body["wallet_id"] = self._wallet_id
        resp = await self._http.post(
            f"{self._base_url}/v1/payments/propose",
            json=body,
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        if resp.status_code == _HTTP_FORBIDDEN:
            problem = resp.json()
            raise PolicyDeniedError(
                str(problem.get("transaction_id")) if problem.get("transaction_id") else None,
                str(problem.get("reason") or problem.get("detail") or "Policy denied this payment"),
            )
        resp.raise_for_status()
        return cast("dict[str, Any]", resp.json())

    async def _report_settlement(self, transaction_id: str, payment_response: str) -> None:
        with contextlib.suppress(httpx.HTTPError):
            await self._http.post(
                f"{self._base_url}/v1/payments/{transaction_id}/settlement",
                json={"payment_response": payment_response},
                headers={"Authorization": f"Bearer {self._api_key}"},
            )

    async def _get_payment(self, payment_id: str) -> Any:
        if self._auth_client is not None:
            return await _get_payment_via_generated_async(self._auth_client, payment_id)
        resp = await self._http.get(
            f"{self._base_url}/v1/payments/{payment_id}",
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        resp.raise_for_status()
        return _DictResponse(resp.json())

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()
        if self._owns_seller_http:
            await self._seller_http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_args: object) -> None:
        await self.aclose()


AsyncX402Client = AsyncX402Walker


class PaymentsClient:
    """Payment-aware HTTP client with mandate-presentation support (M6).

    The mandate-issuance and mandate-revocation endpoints
    (``/v1/mandates/issue`` and ``/v1/mandates/{jti}/revoke``) are owned
    by the identity service and **not** exposed in the gateway OpenAPI
    spec at ``api/openapi.json``. Until they are surfaced there, this
    client keeps a direct-``httpx`` implementation for both.
    """

    def __init__(
        self,
        *,
        api_key: str,
        wallet_id: str | None = None,
        base_url: str = "https://api.payagentic.com",
        http: httpx.Client | None = None,
        mandate: MandateRegistry | None = None,
    ) -> None:
        self._api_key = api_key
        self._wallet_id = wallet_id
        self._base_url = base_url.rstrip("/")
        self._http = http or httpx.Client()
        self._mandate = mandate

    def present_mandate(  # noqa: PLR0913
        self,
        grants: list[str],
        claim: PresentationClaim,
        signer: MandateSigner,
        *,
        agent_spiffe_id: str | None = None,
        audience: str | None = None,
        iat: int | None = None,
        exp: int | None = None,
        jti: str | None = None,
    ) -> str:
        """Sign and return a presentation JWS for claim."""
        spiffe_id = (
            agent_spiffe_id
            if agent_spiffe_id is not None
            else (self._mandate.agent_spiffe_id if self._mandate else "")
        )
        if not spiffe_id:
            msg = (
                "present_mandate: agent_spiffe_id is required "
                "(pass directly or configure mandate registry)"
            )
            raise ValueError(msg)
        aud = (
            audience
            if audience is not None
            else (self._mandate.audience if self._mandate else DEFAULT_MANDATE_AUDIENCE)
        )
        params = BuildPresentationParams(
            agent_spiffe_id=spiffe_id,
            audience=aud,
            grants=grants,
            claim=claim,
            iat=iat,
            exp=exp,
            jti=jti,
        )
        return _build_presentation(params, signer)

    def issue_grant(  # noqa: PLR0913
        self,
        *,
        subject_agent_id: str,
        scope: dict[str, Any],
        exp: int,
        max_depth: int,
        issuer_kid: str,
        parent_jti: str | None = None,
        nbf: int | None = None,
    ) -> dict[str, Any]:
        """POST /v1/mandates/issue. Identity-service-owned; not in gateway spec."""
        body: dict[str, Any] = {
            "subject_agent_id": subject_agent_id,
            "scope": scope,
            "exp": exp,
            "max_depth": max_depth,
            "issuer_kid": issuer_kid,
        }
        if nbf is not None:
            body["nbf"] = nbf
        if parent_jti is not None:
            body["parent_jti"] = parent_jti
        resp = self._http.post(
            f"{self._base_url}/v1/mandates/issue",
            json=body,
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        if resp.status_code >= _HTTP_BAD_REQUEST:
            msg = f"issue_grant failed with HTTP {resp.status_code}: {resp.text}"
            raise PayAgenticError(msg)
        return cast("dict[str, Any]", resp.json())

    def revoke_mandate(self, jti: str, reason: str | None = None) -> dict[str, Any]:
        """POST /v1/mandates/{jti}/revoke. Identity-service-owned; not in gateway spec."""
        body: dict[str, Any] = {"reason": reason} if reason is not None else {}
        resp = self._http.post(
            f"{self._base_url}/v1/mandates/{jti}/revoke",
            json=body,
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        if resp.status_code >= _HTTP_BAD_REQUEST:
            msg = f"revoke_mandate failed with HTTP {resp.status_code}: {resp.text}"
            raise PayAgenticError(msg)
        return cast("dict[str, Any]", resp.json())

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()
