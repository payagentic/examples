"""PayAgentic SDK client façades.

``PayAgentic`` (sync) and ``AsyncPayAgentic`` (async) construct
middleware-wrapped httpx clients, hand them to the generated
``AuthenticatedClient``, and expose per-tag operation namespaces plus
the agent kit.

Usage::

    from payagentic import PayAgentic

    client = PayAgentic(api_key="pa_test_…")
    wallets = client.wallets.list_wallets()        # generated operation
    res = client.x402.fetch("https://vendor.example.com/data")

The previous hand-written 1045-line client with 14 resource classes has
been replaced by these thin façades; types come from
``payagentic._generated.models``.
"""

from __future__ import annotations

import importlib
import os
from dataclasses import dataclass, field
from typing import Any, Self

from payagentic._generated.client import AuthenticatedClient
from payagentic.middleware.retry import DEFAULT_RETRY_POLICY, RetryPolicy
from payagentic.middleware.transport import build_async_client, build_sync_client

__all__ = ["AsyncPayAgentic", "PayAgentic"]

DEFAULT_BASE_URL = "https://app.payagentic.ai"


@dataclass
class _Config:
    api_key: str
    agent_id: str | None
    base_url: str
    x402_wallet_id: str | None = None
    retry_policy: RetryPolicy = field(default_factory=lambda: DEFAULT_RETRY_POLICY)


def _resolve_config(
    *,
    api_key: str | None,
    agent_id: str | None,
    base_url: str | None,
    retry_policy: RetryPolicy | None,
    x402_wallet_id: str | None = None,
) -> _Config:
    resolved_key = api_key or os.environ.get("PAYAGENTIC_API_KEY")
    if not resolved_key:
        msg = (
            "PayAgentic requires an API key. "
            "Pass api_key=... or set PAYAGENTIC_API_KEY in the environment."
        )
        raise ValueError(msg)
    return _Config(
        api_key=resolved_key,
        agent_id=agent_id or os.environ.get("PAYAGENTIC_AGENT_ID"),
        base_url=base_url or os.environ.get("PAYAGENTIC_BASE_URL") or DEFAULT_BASE_URL,
        x402_wallet_id=x402_wallet_id or os.environ.get("PAYAGENTIC_WALLET_ID"),
        retry_policy=retry_policy or DEFAULT_RETRY_POLICY,
    )


# Namespace names — must match the actual _generated/api/<dir>/ names.
_TAG_NAMESPACES = [
    "agents",
    "api_keys",
    "approvals",
    "audit",
    "capabilities",
    "compliance",
    "dashboard",
    "fx",
    "identity",
    "mandates",
    "merchants",
    "organizations",
    "payments",
    "payouts",
    "policies",
    "refunds",
    "system",
    "transactions",
    "transfers",
    "wallets",
    "webhooks",
    "x402",
]


class _SyncNamespace:
    """Lazy adapter exposing a generated tag module's ``sync`` functions.

    Example: ``client.wallets.list_wallets(...)`` routes to
    ``_generated.api.wallets.list_wallets.sync(client=auth_client, ...)``.
    """

    def __init__(
        self,
        tag_module_name: str,
        auth_client: AuthenticatedClient,
    ) -> None:
        self._module_name = tag_module_name
        self._auth_client = auth_client

    def __getattr__(self, name: str) -> Any:
        try:
            op_module = importlib.import_module(f"{self._module_name}.{name}")
        except ImportError as e:
            msg = f"{self._module_name} has no operation '{name}'"
            raise AttributeError(msg) from e
        sync_fn = op_module.sync

        def call(**kwargs: Any) -> Any:
            return sync_fn(client=self._auth_client, **kwargs)

        return call


class _AsyncNamespace:
    """Lazy adapter exposing a generated tag module's ``asyncio`` functions."""

    def __init__(
        self,
        tag_module_name: str,
        auth_client: AuthenticatedClient,
    ) -> None:
        self._module_name = tag_module_name
        self._auth_client = auth_client

    def __getattr__(self, name: str) -> Any:
        try:
            op_module = importlib.import_module(f"{self._module_name}.{name}")
        except ImportError as e:
            msg = f"{self._module_name} has no operation '{name}'"
            raise AttributeError(msg) from e
        async_fn = op_module.asyncio

        async def call(**kwargs: Any) -> Any:
            return await async_fn(client=self._auth_client, **kwargs)

        return call


class PayAgentic:
    """Synchronous PayAgentic API façade.

    Exposes one attribute per OpenAPI tag (``wallets``, ``payments``, …)
    backed by the generated transport, plus the agent kit at ``.x402``.
    """

    agents: _SyncNamespace
    api_keys: _SyncNamespace
    approvals: _SyncNamespace
    audit: _SyncNamespace
    capabilities: _SyncNamespace
    compliance: _SyncNamespace
    dashboard: _SyncNamespace
    fx: _SyncNamespace
    identity: _SyncNamespace
    mandates: _SyncNamespace
    merchants: _SyncNamespace
    organizations: _SyncNamespace
    payments: _SyncNamespace
    payouts: _SyncNamespace
    policies: _SyncNamespace
    refunds: _SyncNamespace
    system: _SyncNamespace
    transactions: _SyncNamespace
    transfers: _SyncNamespace
    wallets: _SyncNamespace
    webhooks: _SyncNamespace

    def __init__(
        self,
        *,
        api_key: str | None = None,
        agent_id: str | None = None,
        base_url: str | None = None,
        x402_wallet_id: str | None = None,
        retry_policy: RetryPolicy | None = None,
    ) -> None:
        self._config = _resolve_config(
            api_key=api_key,
            agent_id=agent_id,
            base_url=base_url,
            x402_wallet_id=x402_wallet_id,
            retry_policy=retry_policy,
        )

        httpx_client = build_sync_client(
            api_key=self._config.api_key,
            agent_id=self._config.agent_id,
            base_url=self._config.base_url,
            retry_policy=self._config.retry_policy,
        )

        self._auth_client = AuthenticatedClient(
            base_url=self._config.base_url,
            token=self._config.api_key,
        )
        # Hand our fully wired httpx client to the generated AuthenticatedClient
        # so it skips constructing its own.
        self._auth_client.set_httpx_client(httpx_client)

        for tag in _TAG_NAMESPACES:
            setattr(
                self,
                tag,
                _SyncNamespace(
                    f"payagentic._generated.api.{tag}",
                    self._auth_client,
                ),
            )

        # Agent kit — wrap construction so we cope with Task 9's legacy
        # x402 surface still being mid-rework.
        self.x402: Any = None
        try:
            from payagentic.x402 import X402Client  # noqa: PLC0415

            self.x402 = X402Client(self)
        except (ImportError, TypeError):
            pass

    def close(self) -> None:
        client = self._auth_client.get_httpx_client()
        client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncPayAgentic:
    """Asynchronous PayAgentic API façade.

    Same surface as :class:`PayAgentic`, end-to-end async.
    """

    agents: _AsyncNamespace
    api_keys: _AsyncNamespace
    approvals: _AsyncNamespace
    audit: _AsyncNamespace
    capabilities: _AsyncNamespace
    compliance: _AsyncNamespace
    dashboard: _AsyncNamespace
    fx: _AsyncNamespace
    identity: _AsyncNamespace
    mandates: _AsyncNamespace
    merchants: _AsyncNamespace
    organizations: _AsyncNamespace
    payments: _AsyncNamespace
    payouts: _AsyncNamespace
    policies: _AsyncNamespace
    refunds: _AsyncNamespace
    system: _AsyncNamespace
    transactions: _AsyncNamespace
    transfers: _AsyncNamespace
    wallets: _AsyncNamespace
    webhooks: _AsyncNamespace

    def __init__(
        self,
        *,
        api_key: str | None = None,
        agent_id: str | None = None,
        base_url: str | None = None,
        x402_wallet_id: str | None = None,
        retry_policy: RetryPolicy | None = None,
    ) -> None:
        self._config = _resolve_config(
            api_key=api_key,
            agent_id=agent_id,
            base_url=base_url,
            x402_wallet_id=x402_wallet_id,
            retry_policy=retry_policy,
        )

        httpx_client = build_async_client(
            api_key=self._config.api_key,
            agent_id=self._config.agent_id,
            base_url=self._config.base_url,
            retry_policy=self._config.retry_policy,
        )

        self._auth_client = AuthenticatedClient(
            base_url=self._config.base_url,
            token=self._config.api_key,
        )
        self._auth_client.set_async_httpx_client(httpx_client)

        for tag in _TAG_NAMESPACES:
            setattr(
                self,
                tag,
                _AsyncNamespace(
                    f"payagentic._generated.api.{tag}",
                    self._auth_client,
                ),
            )

        self.x402: Any = None
        try:
            from payagentic.x402 import AsyncX402Client  # noqa: PLC0415

            self.x402 = AsyncX402Client(self)
        except (ImportError, TypeError):
            pass

    async def aclose(self) -> None:
        client = self._auth_client.get_async_httpx_client()
        await client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
