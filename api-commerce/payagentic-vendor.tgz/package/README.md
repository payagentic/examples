# `@payagentic.ai/vendor`

Accept paid API access from AI agents with Express middleware, x402 challenges and gateway verification.

[Run the buyer + merchant demo](https://payagentic.ai/docs/examples) · [SDKs](https://payagentic.ai/sdks) · [Pricing](https://payagentic.ai/pricing) · [Support](mailto:developers@payagentic.ai)

**Distribution status:** this pre-1.0 package is not yet published on npm. The complete local demo includes a compiled package built from source. Run `npm run build` and `npm pack` in this directory for a local package; Node.js 22+ consumers import compiled JavaScript, including `@payagentic.ai/vendor/express`. Publication is a separate release step.



Accept PayAgentic x402 payments without giving the SDK a payout-wallet private
key. Registered endpoints use two payout-wallet-signed EIP-191 messages:

- a renewable origin proof delegates one exact HTTPS API base path for 30 days;
- a fresh, five-minute-or-shorter seller binding authorizes one endpoint payment.

The SDK accepts only an async `signMessage(message)` callback. Back that callback
with the same payout wallet configured on the merchant profile, using your HSM,
MPC provider, or wallet service. Do not put a private key in SDK options.

## Verify the delegated API origin

Create the merchant API in PayAgentic first, including its exact public base URL.
Start an ownership challenge with the merchant key:

```ts
const challenge = await fetch(
  `${gateway}/v1/merchants/apis/${apiId}/ownership-challenge`,
  {
    method: "POST",
    headers: { Authorization: `Bearer ${merchantApiKey}` },
  },
).then((response) => response.json());
```

The wrapper uses snake_case fields such as `proof_url`; `challenge.proof` uses
the camelCase `OriginProofFields` shape. Sign its exact message and publish the
returned JSON at the exact path supplied by PayAgentic:

```ts
import express from "express";
import {
  createOriginProof,
  type OriginProofFields,
} from "@payagentic.ai/vendor";
import { merchantOwnershipProof } from "@payagentic.ai/vendor/express";

const signMessage = (message: string) => payoutWalletSigner.signMessage(message);
const proof = await createOriginProof(challenge.proof as OriginProofFields, signMessage);
const proofPath = new URL(challenge.proof_url).pathname;

const app = express();
app.get(proofPath, merchantOwnershipProof(proof));
```

The proof handler returns exact JSON with `Cache-Control: no-store`. It must be
reachable over public HTTPS at the complete delegated base path; redirects,
non-JSON responses, oversized bodies, local/private hosts, or a different
payout-wallet signature are rejected. Once the handler is reachable, finish
verification:

```ts
await fetch(`${gateway}/v1/merchants/apis/${apiId}/ownership-verify`, {
  method: "POST",
  headers: { Authorization: `Bearer ${merchantApiKey}` },
});
```

Repeat this challenge, publish, and verify flow before the 30-day scope expires
or after changing the API base URL or payout wallet.

## Issue a fresh binding on every 402

Configure middleware with the verified public base, merchant ID, deployment
mode, payout recipient, and signer callback. Every protected route also needs
its catalog endpoint ID:

```ts
import { payagentic } from "@payagentic.ai/vendor/express";

const pay = payagentic({
  apiKey: merchantApiKey,
  baseUrl: gateway,
  recipient: payoutWalletAddress,
  sellerBinding: {
    merchantId,
    mode: "test", // use "live" with live merchant keys and catalog APIs
    publicBaseUrl: "https://merchant.example/delegated/api",
    network: "eip155:84532",
    asset: "0x036CbD53842c5426634e7929541eC2318f3dCF7e", // Base Sepolia USDC
    signMessage,
  },
});

app.get(
  "/delegated/api/search",
  pay({ price: "1.25", currency: "USDC", endpointId }),
  (req, res) => res.json({ paidBy: req.payment!.agent_id }),
);
```

The middleware derives the canonical request URL (including its query) below
`publicBaseUrl`, converts the decimal USDC price to minor units, generates a
cryptographically random 32-byte nonce, uses a four-minute expiry by default,
and awaits `signMessage`. Registered endpoints return the exact x402-v2 envelope
accepted by PayAgentic as base64 in `PAYMENT-REQUIRED`, including the camelCase
`sellerBinding`, canonical `resource.url`, CAIP-2 network, token asset, minor-unit
amount, and payout recipient. The buyer SDK forwards that header unchanged with
the actual request URL. The middleware also forwards `endpoint_id` and
`expected_url` during credential verification.

Bindings are one-use. A KYA denial consumes the nonce, so the buyer must use the
fresh 402 returned by the seller, a new payment idempotency key, and a current
passport. Do not cache 402 bodies or reuse a binding across requests.

For custom frameworks, use `buildOriginProofMessage`, `createOriginProof`,
`buildSellerBindingMessage`, `createSellerBinding`, and
`buildPaymentRequiredHeader` from the package root.
